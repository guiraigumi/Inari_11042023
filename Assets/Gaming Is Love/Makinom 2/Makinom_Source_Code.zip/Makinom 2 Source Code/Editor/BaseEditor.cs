
using UnityEditor;
using UnityEngine;
using GamingIsLove.Makinom.Schematics;
using System.Collections.Generic;
using System;

namespace GamingIsLove.Makinom.Editor
{
	public class BaseEditor
	{
		protected Notify repaint;

		protected bool blockScroll = false;

		public bool isInspector = false;

		public bool inspectorHideNextName = false;

		public string searchSettings = "";

		protected string[] searchSplit = null;

		protected bool searchScrollToFirst = false;

		protected List<float> searchScrollPositions = new List<float>();

		protected int searchScrollIndex = -1;

		protected int searchScrollLastCount = -1;


		// check groups
		public Stack<bool> checkGroupStack = new Stack<bool>();


		// foldouts
		protected Dictionary<string, EditorFoldout> foldoutLookup = new Dictionary<string, EditorFoldout>();

		protected List<EditorFoldout> foldout = new List<EditorFoldout>();

		protected int currentFoldout = -1;

		protected List<EditorFoldout> openFoldouts = new List<EditorFoldout>();

		protected string foldoutLimit = "";


		// text area controls
		protected List<EditorTextAreaControl> textAreaControl = new List<EditorTextAreaControl>();

		protected int currentTextArea = -1;


		// variable fields
		protected List<EditorVariableField> variableField = new List<EditorVariableField>();

		protected int currentVariableField = -1;

		protected VariableHandlerEditor variableEditor;


		// reflection fields
		protected List<EditorReflectionField> reflectionField = new List<EditorReflectionField>();

		protected int currentReflectionField = -1;


		// asset selection fields
		protected List<EditorAssetSelectionPopupField> assetSelectionField = new List<EditorAssetSelectionPopupField>();

		protected int currentAssetSelectionField = -1;


		// general popup fields
		protected List<GeneralSelectionPopupField> popupSelectionField = new List<GeneralSelectionPopupField>();

		protected int currentPopupSelectionField = -1;

		public BaseEditor()
		{

		}

		public BaseEditor(bool isInspector, Notify repaint)
		{
			this.isInspector = isInspector;
			this.repaint = repaint;
		}

		public virtual void ClearShow()
		{
			this.checkGroupStack.Clear();
			this.openFoldouts.Clear();
			this.currentTextArea = -1;
			this.currentVariableField = -1;
			this.currentReflectionField = -1;
			this.currentAssetSelectionField = -1;
			this.currentPopupSelectionField = -1;
			this.currentFoldout = -1;
			EditorAutomation.ClearSearchMark();

			if(Event.current.type == EventType.Repaint)
			{
				this.searchScrollPositions.Clear();
			}
			else if(Event.current.type == EventType.Layout)
			{
				this.searchScrollLastCount = this.searchScrollPositions.Count;
			}
		}

		public virtual void Repaint()
		{
			if(this.repaint != null)
			{
				this.repaint();
			}
		}

		public virtual bool BlockScroll
		{
			get { return this.blockScroll; }
			set { this.blockScroll = value; }
		}


		/*
		============================================================================
		Search functions
		============================================================================
		*/
		public virtual void UpdateSearch()
		{
			if(this.searchSettings.Length >= 3)
			{
				this.searchSplit = this.searchSettings.Split(new char[] { ' ' }, StringSplitOptions.RemoveEmptyEntries);
			}
			else
			{
				this.searchSplit = null;
			}

			this.searchScrollPositions.Clear();
			this.searchScrollIndex = -1;
			for(int i = 0; i < this.foldout.Count; i++)
			{
				this.foldout[i].SearchMark = false;
			}
			if(Maki.EditorSettings.searchAutoScroll)
			{
				this.searchScrollToFirst = true;
			}
		}

		public virtual bool CheckSearch(string text)
		{
			if(this.searchSettings.Length >= 3)
			{
				if(text.IndexOf(this.searchSettings, System.StringComparison.OrdinalIgnoreCase) >= 0)
				{
					return true;
				}
				/*else if(this.searchSplit != null)
				{
					for(int i = 0; i < this.searchSplit.Length; i++)
					{
						if(text.IndexOf(this.searchSplit[i], System.StringComparison.OrdinalIgnoreCase) >= 0)
						{
							return true;
						}
					}
				}*/
			}
			return false;
		}

		public virtual void SearchMarkFoldout()
		{
			if(this.openFoldouts.Count > 0)
			{
				for(int i = this.openFoldouts.Count - 1; i >= 0; i--)
				{
					this.openFoldouts[i].SearchMark = true;
					if(this.openFoldouts[i].Depth < Maki.EditorSettings.maxJumpListDepth)
					{
						break;
					}
				}
			}
		}

		public virtual void AddSearchScrollPosition(float position)
		{
			this.searchScrollPositions.Add(position);
			this.searchScrollLastCount = this.searchScrollPositions.Count;
		}


		/*
		============================================================================
		Special popups functions
		============================================================================
		*/
		public virtual string[] GetPopupList(int id)
		{
			return new string[0];
		}


		/*
		============================================================================
		Special field functions
		============================================================================
		*/
		public virtual int TextAreaType
		{
			get { return 0; }
		}

		public virtual void TextArea(GUIContent content, ref TextContent text, string helpInfo)
		{
			this.currentTextArea++;
			while(this.currentTextArea >= this.textAreaControl.Count)
			{
				this.textAreaControl.Add(new EditorTextAreaControl(this));
			}
			EditorTextAreaControl tac = this.textAreaControl[this.currentTextArea];
			EditorTool.TextArea(content, ref text, ref tac, this.TextAreaType, helpInfo, this);
			this.textAreaControl[this.currentTextArea] = tac;
		}

		public virtual void CancelTextEditing()
		{
			for(int i = 0; i < this.currentTextArea; i++)
			{
				this.textAreaControl[i].CancelEditing();
			}
		}

		public virtual void AcceptTextEditing()
		{
			for(int i = 0; i < this.currentTextArea; i++)
			{
				this.textAreaControl[i].AcceptEditing();
			}
		}

		public virtual VariableHandlerEditor VariableEditor
		{
			get
			{
				if(this.variableEditor == null)
				{
					this.variableEditor = new VariableHandlerEditor(this);
				}
				return this.variableEditor;
			}
		}

		public virtual void VariableField(GUIContent content, ref string text, string helpInfo,
			AttributeHelper attributes)
		{
			this.currentVariableField++;
			while(this.currentVariableField >= this.variableField.Count)
			{
				this.variableField.Add(new EditorVariableField());
			}
			this.variableField[this.currentVariableField].Edit(
				content, ref text, helpInfo, attributes, this);
		}

		public virtual void ReflectionField(GUIContent content, ref string text, string helpInfo,
			AttributeHelper attributes, string className, EditorReflectionField.Type reflectionType, System.Type fieldType)
		{
			this.currentReflectionField++;
			while(this.currentReflectionField >= this.reflectionField.Count)
			{
				this.reflectionField.Add(new EditorReflectionField());
			}
			this.reflectionField[this.currentReflectionField].Edit(content, ref text, helpInfo,
				attributes, this, className, reflectionType, fieldType);
		}

		public virtual void AssetSelectionField(GUIContent content, ref AssetSource selection, string helpInfo, AttributeHelper attributes)
		{
			this.currentAssetSelectionField++;
			while(this.currentAssetSelectionField >= this.assetSelectionField.Count)
			{
				this.assetSelectionField.Add(new EditorAssetSelectionPopupField());
			}
			this.assetSelectionField[this.currentAssetSelectionField].Edit(
				content, ref selection, helpInfo, attributes, this);
		}

		public virtual void PopupSelectionField(GUIContent content, ref int index, string[] items, string[] descriptions,
			string helpInfo, AttributeHelper attributes)
		{
			this.currentPopupSelectionField++;
			while(this.currentPopupSelectionField >= this.popupSelectionField.Count)
			{
				this.popupSelectionField.Add(new GeneralSelectionPopupField());
			}
			this.popupSelectionField[this.currentPopupSelectionField].Edit(
				content, ref index, items, descriptions, helpInfo, attributes, this);
		}

		public virtual void PopupSelectionFieldSimple(string name, ref int index, string[] items, string[] descriptions,
			string helpText, string helpInfo, bool hideName, bool expandWidth)
		{
			this.currentPopupSelectionField++;
			while(this.currentPopupSelectionField >= this.popupSelectionField.Count)
			{
				this.popupSelectionField.Add(new GeneralSelectionPopupField());
			}
			this.popupSelectionField[this.currentPopupSelectionField].EditSimple(
				name, ref index, items, descriptions, helpText, helpInfo, this, hideName, expandWidth);
		}


		/*
		============================================================================
		Foldout functions
		============================================================================
		*/
		public virtual string FoldoutLimit
		{
			get { return this.foldoutLimit; }
			set { this.foldoutLimit = value; }
		}

		public virtual void ExpandFoldouts(bool expand)
		{
			foreach(KeyValuePair<string, EditorFoldout> pair in this.foldoutLookup)
			{
				pair.Value.Expanded = expand;
			}
		}

		protected virtual string GetOpenFoldoutNames()
		{
			return "";
		}

		protected virtual string GetOpenFoldoutPath()
		{
			string path = "";
			for(int i = 0; i < this.openFoldouts.Count; i++)
			{
				path += this.openFoldouts[i].Name + ":";
			}
			return path;
		}

		public virtual bool BeginFoldout(string name, string helpText, string helpInfo, bool expanded)
		{
			return this.BeginFoldout(new GUIContent(name, helpText), helpInfo, expanded);
		}

		public virtual bool BeginFoldout(GUIContent content, string helpInfo, bool expanded)
		{
			string path = this.GetOpenFoldoutPath() + content.text;
			EditorFoldout foldout = null;
			if(!this.foldoutLookup.TryGetValue(path, out foldout))
			{
				foldout = new EditorFoldout(path, content, helpInfo, expanded, this.GetOpenFoldoutNames());
				this.foldoutLookup.Add(path, foldout);
			}

			this.currentFoldout++;
			if(this.currentFoldout < this.foldout.Count)
			{
				this.foldout[this.currentFoldout] = foldout;
			}
			else
			{
				this.foldout.Add(foldout);
			}

			foldout.Depth = this.openFoldouts.Count;
			if(this.GetFoldout(true))
			{
				this.openFoldouts.Add(foldout);
				foldout.Displayed = true;

				bool clearSearch = false;
				if(this.CheckSearch(content.text))
				{
					clearSearch = true;
					EditorAutomation.MarkSearch(true, this, true);
				}

				foldout.Open(this.isInspector);

				if(clearSearch)
				{
					clearSearch = false;
					EditorAutomation.MarkSearch(false, this, false);
				}
				return foldout.Expanded;
			}
			else
			{
				this.openFoldouts.Add(foldout);
				foldout.Displayed = false;
				return false;
			}
		}

		public virtual void EndFoldout()
		{
			if(this.openFoldouts.Count > 0)
			{
				EditorFoldout tmp = this.openFoldouts[this.openFoldouts.Count - 1];
				if(tmp.Displayed)
				{
					tmp.Close();
				}
				this.openFoldouts.RemoveAt(this.openFoldouts.Count - 1);
			}
		}

		public virtual bool GetFoldout(bool isInit)
		{
			if(isInit || this.openFoldouts.Count > 0)
			{
				if(this.foldoutLimit != "" &&
					this.currentFoldout < this.foldout.Count)
				{
					for(int i = this.currentFoldout; i >= 0; i--)
					{
						if(this.foldout[i].Depth == 0)
						{
							if(this.foldout[i].Name == this.foldoutLimit)
							{
								break;
							}
							else
							{
								return false;
							}
						}
					}
				}

				for(int i = 0; i < this.openFoldouts.Count; i++)
				{
					if(!this.openFoldouts[i].Expanded)
					{
						return false;
					}
				}
			}
			return true;
		}

		public virtual void CloseAllFoldouts()
		{
			if(this.openFoldouts.Count > 0)
			{
				EditorFoldout tmp = this.openFoldouts[this.openFoldouts.Count - 1];
				if(tmp.Displayed)
				{
					tmp.Close();
				}
				this.openFoldouts.RemoveAt(this.openFoldouts.Count - 1);
			}
		}

		public virtual void RemoveCurrentFoldout()
		{
			this.foldoutLookup.Remove(this.foldout[this.currentFoldout].Path);
			this.foldout.RemoveAt(this.currentFoldout--);
			this.openFoldouts.RemoveAt(this.openFoldouts.Count - 1);
		}

		public virtual EditorFoldout GetFoldout(string name)
		{
			for(int i = 0; i < this.foldout.Count; i++)
			{
				if(this.foldout[i].Name == name)
				{
					return this.foldout[i];
				}
			}
			return null;
		}


		/*
		============================================================================
		Settings display
		============================================================================
		*/
		public virtual void AutomationCallback(string info)
		{
			if(info != "textcodes:name" &&
				info != "textcodes:shortname" &&
				info != "textcodes:description" &&
				info != "textcodes:customcontent")
			{
				// extensions
				bool found = false;
				for(int i = 0; i < EditorContent.Extensions.Count; i++)
				{
					if(EditorContent.Extensions[i].AutomationCallback(this, info))
					{
						found = true;
						break;
					}
				}
				if(!found)
				{
					EditorGUILayout.HelpBox("Editor automation callback: " + info, MessageType.Error);
				}
			}
		}

		public virtual void AutomationCallback(int arrayIndex, string info)
		{
			// extensions
			bool found = false;
			for(int i = 0; i < EditorContent.Extensions.Count; i++)
			{
				if(EditorContent.Extensions[i].AutomationCallback(this, arrayIndex, info))
				{
					found = true;
					break;
				}
			}
			if(!found)
			{
				EditorGUILayout.HelpBox("Editor automation callback(" + arrayIndex + "): " + info, MessageType.Error);
			}
		}

		public virtual bool AutomationCheck(string info)
		{
			for(int i = 0; i < EditorContent.Extensions.Count; i++)
			{
				if(EditorContent.Extensions[i].AutomationCheck(this, info))
				{
					return true;
				}
			}
			return false;
		}

		public virtual bool AutomationCheck(int arrayIndex, string info)
		{
			for(int i = 0; i < EditorContent.Extensions.Count; i++)
			{
				if(EditorContent.Extensions[i].AutomationCheck(this, arrayIndex, info))
				{
					return true;
				}
			}
			return false;
		}

		public virtual void InstanceCallback(string info, System.Object instance)
		{
			if(info == "button:fadeswap")
			{
				if(instance is FadeColorSettings)
				{
					FadeColorSettings settings = (FadeColorSettings)instance;
					if(!settings.fromCurrent && EditorTool.Button("Swap Colors", "Swap the start and end colors.", ""))
					{
						Color tmp = settings.startColor;
						settings.startColor = settings.endColor;
						settings.endColor = tmp;
					}
				}
				else if(instance is BaseFadeFloatSettings)
				{
					BaseFadeFloatSettings settings = (BaseFadeFloatSettings)instance;
					if(!settings.FromCurrent && EditorTool.Button("Swap Values", "Swap the start and end values.", ""))
					{
						settings.SwapValues();
					}
				}
			}
			else if(info == "button:findicontextcode" &&
				instance is IconContent)
			{
				IconContent content = (IconContent)instance;
				List<IEditorFunctions> editorFunctions = EditorReflection.Instance.GetEditorFunctions();
				for(int i = 0; i < editorFunctions.Count; i++)
				{
					if(editorFunctions[i] != null)
					{
						editorFunctions[i].IconTextCodeButton(content);
					}
				}
			}
			else if(info == "button:ObjectID" &&
				instance is ObjectVariableSetting)
			{
				ObjectVariableSetting setting = (ObjectVariableSetting)instance;
				if(EditorTool.Button("New Object ID", "Generates a new object ID.", ""))
				{
					setting.objectID = System.Guid.NewGuid().ToString();
				}
			}
			else
			{
				// extensions
				bool found = false;
				for(int i = 0; i < EditorContent.Extensions.Count; i++)
				{
					if(EditorContent.Extensions[i].InstanceCallback(this, info, instance))
					{
						found = true;
						break;
					}
				}
				if(!found)
				{
					EditorGUILayout.HelpBox("Editor automation instance callback: " + info, MessageType.Error);
				}
			}
		}

		public virtual void AutomationAddCallback(string info)
		{
			// extensions
			bool found = false;
			for(int i = 0; i < EditorContent.Extensions.Count; i++)
			{
				if(EditorContent.Extensions[i].AutomationAddCallback(this, info))
				{
					found = true;
					break;
				}
			}
			if(!found)
			{
				EditorGUILayout.HelpBox("Editor automation add callback: " + info, MessageType.Error);
			}
		}

		public virtual void AutomationRemoveCallback(int arrayIndex, string info)
		{
			// extensions
			bool found = false;
			for(int i = 0; i < EditorContent.Extensions.Count; i++)
			{
				if(EditorContent.Extensions[i].AutomationRemoveCallback(this, arrayIndex, info))
				{
					found = true;
					break;
				}
			}
			if(!found)
			{
				EditorGUILayout.HelpBox("Editor automation remove callback(" + arrayIndex + "): " + info, MessageType.Error);
			}
		}


		/*
		============================================================================
		Name/description help labels
		============================================================================
		*/
		public virtual void ShowNameLabel(bool horizontal)
		{

		}

		public virtual void ShowDescriptionLabel(bool horizontal)
		{

		}
	}
}
