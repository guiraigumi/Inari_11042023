﻿
using UnityEngine;
using UnityEditor;
using GamingIsLove.Makinom.Schematics;
using System.Collections.Generic;
using System.Reflection;

namespace GamingIsLove.Makinom.Editor
{
	public static class AssetSourceEditor
	{
		public static void Edit(ref AssetSource asset, AttributeHelper attributes, BaseEditor baseEditor)
		{
			asset.Source.EditorBefore();
			bool assetChanged = false;
			string assetPath = "";
			UnityEngine.Object saveAsset = null;

			if(asset.Source.EditorHasAssetField)
			{
				System.Type assetType = asset.GetAssetType();

				// asset bundle
				IAssetBundleAssetSource bundleSource = asset.Source as IAssetBundleAssetSource;
				if(bundleSource != null &&
					asset.Source.EditorAsset == null)
				{
					string[] paths = AssetDatabase.GetAssetPathsFromAssetBundleAndAssetName(
						bundleSource.AssetBundle.Name, bundleSource.AssetName);
					for(int i = 0; i < paths.Length; i++)
					{
						asset.Source.EditorAsset = AssetDatabase.LoadAssetAtPath(paths[i], assetType);
						if(asset.Source.EditorAsset != null)
						{
							break;
						}
					}
				}

				UnityEngine.Object checkAsset = asset.Source.EditorAsset;
				string checkType = asset.SettingsType;

				if(typeof(IMakinomGenericAsset).IsAssignableFrom(assetType))
				{
					baseEditor.AssetSelectionField(attributes.help.content, ref asset, attributes.help.info, attributes);
				}
				else
				{
					attributes.CombinedField(asset, baseEditor, false);
				}

				if(checkAsset != asset.Source.EditorAsset ||
					checkType != asset.SettingsType)
				{
					assetChanged = true;
					if(asset.Source.EditorAsset != null)
					{
						saveAsset = asset.Source.EditorAsset;

						if(checkType != asset.SettingsType)
						{
							bundleSource = asset.Source as IAssetBundleAssetSource;
						}
						assetPath = AssetDatabase.GetAssetPath(asset.Source.EditorAsset);
						if(bundleSource != null &&
							assetPath.StartsWith("Assets/"))
						{
							string bundleName = AssetDatabase.GetImplicitAssetBundleName(assetPath);
							if(string.IsNullOrEmpty(bundleName))
							{
								assetPath = "";
							}
							else
							{
								string variant = AssetDatabase.GetImplicitAssetBundleVariantName(assetPath);
								if(string.IsNullOrEmpty(variant))
								{
									assetPath = bundleName;
								}
								else
								{
									assetPath = bundleName + "." + variant;
								}
							}
						}
					}
				}
			}
			else
			{
				attributes.CombinedField(asset, baseEditor, false);
			}

			if(asset.Source.EditorAfter(assetChanged, assetPath) &&
				saveAsset != null &&
				asset.Source.EditorAsset == null &&
				!asset.Source.GetType().Equals(typeof(ReferenceAssetSource<>)))
			{
				asset.SettingsType = ReflectionTypeHandler.GetGenericTypeName(typeof(ReferenceAssetSource<>));
				asset.Source.EditorAsset = saveAsset;
				asset.ResetStoredAsset();
			}

			EditorAutomation.Automate(asset.Source, baseEditor);
		}

		public static void DataLoaded(AssetSource asset)
		{
			asset.Source.EditorBefore();
			if(asset.Source.EditorHasAssetField)
			{
				// asset bundle
				IAssetBundleAssetSource bundleSource = asset.Source as IAssetBundleAssetSource;
				if(bundleSource != null &&
					asset.Source.EditorAsset == null)
				{
					string[] paths = AssetDatabase.GetAssetPathsFromAssetBundleAndAssetName(
						bundleSource.AssetBundle.Name, bundleSource.AssetName);
					for(int i = 0; i < paths.Length; i++)
					{
						asset.Source.EditorAsset = AssetDatabase.LoadAssetAtPath(paths[i], asset.GetAssetType());
						if(asset.Source.EditorAsset != null)
						{
							break;
						}
					}
				}
			}
		}

		public static string GetResourcePath(UnityEngine.Object asset)
		{
			string assetPath = "";
			if(asset != null)
			{
				assetPath = AssetDatabase.GetAssetPath(asset);
				int index = assetPath.IndexOf("/Resources/", System.StringComparison.Ordinal);
				if(index > 0)
				{
					index += 11;
					assetPath = assetPath.Substring(index,
						assetPath.LastIndexOf('.') - index);
				}
				else
				{
					assetPath = "";
				}
			}
			return assetPath;
		}


		/*
		============================================================================
		Change functions
		============================================================================
		*/
		public static void UpdateSource(System.Type type, ApplicationPath path, BaseEditorTab baseEditor)
		{
			BaseSettings[] setting = Maki.Data.All;
			for(int i = 0; i < setting.Length; i++)
			{
				AssetSourceEditor.UpdateSource(setting[i], type, path);
			}

			List<IMakinomGenericAsset> assets = EditorDataHandler.Instance.GetAllAssets();
			for(int i = 0; i < assets.Count; i++)
			{
				AssetSourceEditor.UpdateSource(assets[i].EditorSettings, type, path);
			}
		}

		public static void UpdateSchematicsSource(string folder, System.Type type, ApplicationPath path)
		{
			bool encrypted = false;
			DataFile.SaveFormatType format = DataFile.SaveFormatType.ByteArray;
			MakinomAssetHelper.GetSaveSettings(ref encrypted, ref format);

			AssetDatabase.StartAssetEditing();
			List<MakinomSchematicAsset> list = MakinomAssetHelper.GetAllAssets<MakinomSchematicAsset>(folder);
			foreach(MakinomSchematicAsset asset in list)
			{
				if(asset != null)
				{
					AssetSourceEditor.UpdateSource(asset.Settings, type, path);
					asset.SaveData(encrypted, format);
					EditorUtility.SetDirty(asset);
				}
			}

			AssetDatabase.StopAssetEditing();
			AssetDatabase.SaveAssets();
			AssetDatabase.Refresh();
		}

		public static void UpdateSource<T>(T instance, System.Type type, ApplicationPath path) where T : IBaseData
		{
			if(instance != null)
			{
				FieldInfo[] field = ReflectionTypeHandler.Instance.GetFields(instance.GetType());

				for(int i = 0; i < field.Length; i++)
				{
					object value = field[i].GetValue(instance);

					if(value is AssetSource)
					{
						AssetSourceEditor.UpdateSource((AssetSource)value, type, path);
					}
					else if(value is AssetSource[])
					{
						AssetSource[] resource = (AssetSource[])(System.Array)value;
						for(int j = 0; j < resource.Length; j++)
						{
							AssetSourceEditor.UpdateSource(resource[j], type, path);
						}
					}
					// other IBaseData classes
					else if(value is IBaseData)
					{
						AssetSourceEditor.UpdateSource((IBaseData)value, type, path);
					}
					else if(value is IBaseData[])
					{
						IBaseData[] tmp = (IBaseData[])(System.Array)value;
						for(int j = 0; j < tmp.Length; j++)
						{
							if(tmp[j] != null)
							{
								AssetSourceEditor.UpdateSource(tmp[j], type, path);
							}
						}
					}
				}
			}
		}

		public static void UpdateSource(AssetSource asset, System.Type type, ApplicationPath path)
		{
			try
			{
				if(asset != null &&
					asset.Source.EditorHasAssetField &&
					!asset.Source.GetType().GetGenericTypeDefinition().Equals(type))
				{
					if(asset.Source.EditorAsset == null)
					{
						// asset bundle
						IAssetBundleAssetSource bundleSource = asset.Source as IAssetBundleAssetSource;
						if(bundleSource != null)
						{
							string[] paths = AssetDatabase.GetAssetPathsFromAssetBundleAndAssetName(
								bundleSource.AssetBundle.Name, bundleSource.AssetName);
							for(int i = 0; i < paths.Length; i++)
							{
								asset.Source.EditorAsset = AssetDatabase.LoadAssetAtPath(paths[i], asset.GetAssetType());
								if(asset.Source.EditorAsset != null)
								{
									break;
								}
							}
						}
						else
						{
							asset.Source.EditorBefore();
						}
					}

					if(asset.Source.EditorAsset != null)
					{
						// reference
						if(type.Equals(typeof(ReferenceAssetSource<>)))
						{
							asset.SettingsType = ReflectionTypeHandler.GetGenericTypeName(typeof(ReferenceAssetSource<>));
						}
						// resources
						else if(type.Equals(typeof(ResourcesAssetSource<>)))
						{
							string assetPath = AssetDatabase.GetAssetPath(asset.Source.EditorAsset);
							if(assetPath.IndexOf("/Resources/", System.StringComparison.Ordinal) != -1)
							{
								asset.SettingsType = ReflectionTypeHandler.GetGenericTypeName(typeof(ResourcesAssetSource<>));
								asset.Source.EditorAfter(true, assetPath);
							}
						}
						// asset bundle
						else if(type.Equals(typeof(AssetBundleAssetSource<>)))
						{
							string assetPath = AssetDatabase.GetAssetPath(asset.Source.EditorAsset);
							if(assetPath.StartsWith("Assets/"))
							{
								string bundleName = AssetDatabase.GetImplicitAssetBundleName(assetPath);
								if(!string.IsNullOrEmpty(bundleName))
								{
									asset.SettingsType = ReflectionTypeHandler.GetGenericTypeName(typeof(AssetBundleAssetSource<>));
									IAssetBundleAssetSource bundleSource = asset.Source as IAssetBundleAssetSource;
									if(bundleSource != null)
									{
										string variant = AssetDatabase.GetImplicitAssetBundleVariantName(assetPath);
										if(!string.IsNullOrEmpty(variant))
										{
											bundleName = bundleName + "." + variant;
										}
										asset.Source.EditorAfter(true, bundleName);

										if(path != null)
										{
											bundleSource.AssetBundle.OwnPath = true;
											bundleSource.AssetBundle.Path.pathOrigin = path.pathOrigin;
											bundleSource.AssetBundle.Path.path = path.path;
										}
									}
								}
							}
						}
					}
				}
			}
			catch(System.Exception ex)
			{
				Debug.LogWarning("Something happened while trying to update an asset source: " +
					asset.Source.EditorAsset + "\n" + ex.StackTrace);
			}
		}

		public static void UpdateAssetBundlePath(ApplicationPath path, BaseEditorTab baseEditor)
		{
			BaseSettings[] setting = Maki.Data.All;
			for(int i = 0; i < setting.Length; i++)
			{
				AssetSourceEditor.UpdateAssetBundlePath(setting[i], path);
			}

			List<IMakinomGenericAsset> assets = EditorDataHandler.Instance.GetAllAssets();
			for(int i = 0; i < assets.Count; i++)
			{
				AssetSourceEditor.UpdateAssetBundlePath(assets[i].EditorSettings, path);
			}
		}

		public static void UpdateSchematicsAssetBundlePath(string folder, ApplicationPath path)
		{
			bool encrypted = false;
			DataFile.SaveFormatType format = DataFile.SaveFormatType.ByteArray;
			MakinomAssetHelper.GetSaveSettings(ref encrypted, ref format);

			AssetDatabase.StartAssetEditing();
			List<MakinomSchematicAsset> list = MakinomAssetHelper.GetAllAssets<MakinomSchematicAsset>(folder);
			foreach(MakinomSchematicAsset asset in list)
			{
				if(asset != null)
				{
					AssetSourceEditor.UpdateAssetBundlePath(asset.Settings, path);
					asset.SaveData(encrypted, format);
					EditorUtility.SetDirty(asset);
				}
			}

			AssetDatabase.StopAssetEditing();
			AssetDatabase.SaveAssets();
			AssetDatabase.Refresh();
		}

		public static void UpdateAssetBundlePath<T>(T instance, ApplicationPath path) where T : IBaseData
		{
			if(instance != null)
			{
				FieldInfo[] field = ReflectionTypeHandler.Instance.GetFields(instance.GetType());

				for(int i = 0; i < field.Length; i++)
				{
					object value = field[i].GetValue(instance);

					if(value is AssetSource)
					{
						AssetSourceEditor.UpdateAssetBundlePath((AssetSource)value, path);
					}
					else if(value is AssetSource[])
					{
						AssetSource[] resource = (AssetSource[])(System.Array)value;
						for(int j = 0; j < resource.Length; j++)
						{
							AssetSourceEditor.UpdateAssetBundlePath(resource[j], path);
						}
					}
					// other IBaseData classes
					else if(value is IBaseData)
					{
						AssetSourceEditor.UpdateAssetBundlePath((IBaseData)value, path);
					}
					else if(value is IBaseData[])
					{
						IBaseData[] tmp = (IBaseData[])(System.Array)value;
						for(int j = 0; j < tmp.Length; j++)
						{
							if(tmp[j] != null)
							{
								AssetSourceEditor.UpdateAssetBundlePath(tmp[j], path);
							}
						}
					}
				}
			}
		}

		public static void UpdateAssetBundlePath(AssetSource asset, ApplicationPath path)
		{
			try
			{
				if(asset != null &&
					asset.Source.EditorHasAssetField &&
					asset.Source.GetType().GetGenericTypeDefinition().Equals(typeof(AssetBundleAssetSource<>)))
				{
					IAssetBundleAssetSource bundleSource = asset.Source as IAssetBundleAssetSource;
					if(bundleSource != null &&
						bundleSource.AssetBundle.OwnPath &&
						!string.IsNullOrEmpty(bundleSource.AssetBundle.Name))
					{
						bundleSource.AssetBundle.Path.pathOrigin = path.pathOrigin;
						bundleSource.AssetBundle.Path.path = path.path;
					}
				}
			}
			catch(System.Exception ex)
			{
				Debug.LogWarning("Something happened while trying to update an asset bundle's path: " +
					asset.Source.EditorAsset + "\n" + ex.StackTrace);
			}
		}
	}
}
