
using UnityEngine;
using UnityEditor;
using System.Collections.Generic;

namespace GamingIsLove.Makinom.Editor
{
	public static class GLTool
	{
		private static Material material = null;
		
		public static Material Material
		{
			get
			{
				if(material == null)
				{
					material = new Material(Shader.Find("Hidden/Internal-Colored"));
					material.hideFlags = HideFlags.HideAndDontSave;
					material.shader.hideFlags = HideFlags.HideAndDontSave;
				}
				return material;
			}
			set{ material = value;}
		}
		
		
		/*
		============================================================================
		Box functions
		============================================================================
		*/
		public static void Box(Rect bounds, Color color)
		{
			if(GLTool.Material != null)
			{
				GLTool.Material.SetPass(0);
				
				GL.Begin(GL.LINES);
				GL.Color(color);
				
				// top line
				GL.Vertex(new Vector3(bounds.x, bounds.y, 0));
				GL.Vertex(new Vector3(bounds.x + bounds.width, bounds.y, 0));
				
				// bottom line
				GL.Vertex(new Vector3(bounds.x, bounds.y + bounds.height, 0));
				GL.Vertex(new Vector3(bounds.x + bounds.width, bounds.y + bounds.height, 0));
				
				// left line
				GL.Vertex(new Vector3(bounds.x, bounds.y, 0));
				GL.Vertex(new Vector3(bounds.x, bounds.y + bounds.height, 0));
				
				// right line
				GL.Vertex(new Vector3(bounds.x + bounds.width, bounds.y, 0));
				GL.Vertex(new Vector3(bounds.x + bounds.width, bounds.y + bounds.height, 0));
				
				GL.End();
			}
		}
	}
}
