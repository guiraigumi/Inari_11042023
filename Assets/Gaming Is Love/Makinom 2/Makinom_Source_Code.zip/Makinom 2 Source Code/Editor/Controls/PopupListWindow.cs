﻿
using UnityEngine;
using UnityEditor;
using System.Collections.Generic;
using System;

namespace GamingIsLove.Makinom.Editor
{
	public delegate List<string> UpdatePopupListData(string value);

	public class PopupListWindow : PopupWindowContent
	{
		private BaseEditor baseEditor;

		private string controlName;

		public string value = "";

		public List<string> data;


		// input
		private bool firstFocus = true;

		private int index = -1;

		private bool mouseMoved = false;

		private bool holdingArrowKey = false;

		private float holdTimeout = 0;

		private Vector2 scroll = Vector2.zero;

		private int textCursor = -1;

		private int textSelection = -1;


		// position/size
		private bool topMode = false;

		private Rect windowPosition;

		private Vector2 callPosition;

		private Vector2 windowSize;

		private float textFieldHeight;

		private float listLabelHeight;


		// callbacks
		private NotifyString selectCallback;

		private Notify cancelCallback;

		private Notify closeCallback;

		private UpdatePopupListData updateCallback;

		public PopupListWindow(string value, List<string> data, float width, Vector2 callPosition,
			int textCursor, int textSelection,
			NotifyString selectCallback, Notify cancelCallback, Notify closeCallback,
			UpdatePopupListData updateCallback, BaseEditor baseEditor)
		{
			this.controlName = Guid.NewGuid().ToString();
			this.value = value;
			this.data = data;
			this.selectCallback = selectCallback;
			this.cancelCallback = cancelCallback;
			this.closeCallback = closeCallback;
			this.updateCallback = updateCallback;
			this.baseEditor = baseEditor;

			this.windowSize.x = width;
			this.callPosition = callPosition;
			this.textCursor = textCursor;
			this.textSelection = textSelection;

			GUIContent content = new GUIContent("Y");
			this.textFieldHeight = EditorContent.Instance.PopupTextFieldStyle.CalcHeight(content, this.windowSize.x);
			this.listLabelHeight = EditorContent.Instance.PopupListStyle.CalcHeight(content, this.windowSize.x);
			this.UpdateHeight();
		}

		public override void OnOpen()
		{
			if(this.baseEditor != null)
			{
				this.baseEditor.BlockScroll = true;
			}
		}

		public void Close()
		{
			this.editorWindow.Close();
		}

		public override void OnClose()
		{
			if(this.baseEditor != null)
			{
				this.baseEditor.BlockScroll = false;
			}
			if(this.closeCallback != null)
			{
				this.closeCallback();
			}
		}


		/*
		============================================================================
		Bound functions
		============================================================================
		*/
		private void UpdateHeight()
		{
			this.topMode = false;
			this.windowSize.y = this.textFieldHeight +
				this.listLabelHeight * (this.data != null ? this.data.Count : 0);

			if((Screen.currentResolution.height / EditorContent.UIScale) - 100 - this.callPosition.y < this.windowSize.y)
			{
				if(this.callPosition.y > (Screen.currentResolution.height / EditorContent.UIScale) * 0.8f - 100)
				{
					this.topMode = true;
					if(this.callPosition.y < this.windowSize.y)
					{
						this.windowSize.y = this.callPosition.y + this.textFieldHeight;
					}
				}
				else
				{
					this.windowSize.y = (Screen.currentResolution.height / EditorContent.UIScale) - 100 - this.callPosition.y;
				}
			}

			this.windowPosition.x = this.callPosition.x;
			if(this.topMode)
			{
				this.windowPosition.y = this.callPosition.y + this.textFieldHeight - this.windowSize.y;
			}
			else
			{
				this.windowPosition.y = this.callPosition.y;
			}
			this.windowPosition.width = this.windowSize.x;
			this.windowPosition.height = this.windowSize.y;

			if(this.editorWindow != null)
			{
				this.StoreTextCursor();
				this.firstFocus = true;
				GUI.FocusControl(null);
			}
		}

		public override Vector2 GetWindowSize()
		{
			return this.windowSize;
		}

		public virtual bool CursorInList()
		{
			float y = Event.current.mousePosition.y - this.scroll.y;
			return y >= 0 && y < this.editorWindow.position.height - this.textFieldHeight;
		}


		/*
		============================================================================
		GUI functions
		============================================================================
		*/
		public override void OnGUI(Rect rect)
		{
			this.editorWindow.position = this.windowPosition;

			EditorGUILayout.BeginVertical();
			if(this.topMode)
			{
				this.ShowDataList();
				if(this.ShowTextField())
				{
					return;
				}
			}
			else
			{
				if(this.ShowTextField())
				{
					return;
				}
				this.ShowDataList();
			}
			EditorGUILayout.EndVertical();


			// input
			if(Event.current.type == EventType.MouseMove)
			{
				this.mouseMoved = true;
				this.editorWindow.Repaint();
			}
			// list navigation
			if(this.data != null &&
				this.data.Count > 0)
			{
				if(Event.current.keyCode == KeyCode.UpArrow)
				{
					if(Event.current.type == EventType.KeyUp)
					{
						this.holdingArrowKey = false;
						this.holdTimeout = 0;
					}
					else if(this.holdTimeout < Time.realtimeSinceStartup)
					{
						bool started = false;
						if(this.holdingArrowKey)
						{
							this.holdTimeout = Time.realtimeSinceStartup + 0.025f;
						}
						else
						{
							started = true;
							this.holdTimeout = Time.realtimeSinceStartup + 0.5f;
							this.holdingArrowKey = true;
						}

						this.index--;
						if(index == 0 &&
							!started)
						{
							this.holdTimeout += 0.5f;
						}
						else if(this.index < 0)
						{
							this.index = this.data.Count - 1;
						}
						if(this.index >= 0 && this.index < this.data.Count)
						{
							this.value = this.data[this.index];
							this.editorWindow.Repaint();
						}
						this.UpdateScrollPosition();
					}
				}
				else if(Event.current.keyCode == KeyCode.DownArrow)
				{
					if(Event.current.type == EventType.KeyUp)
					{
						this.holdingArrowKey = false;
						this.holdTimeout = 0;
					}
					else if(this.holdTimeout < Time.realtimeSinceStartup)
					{
						bool started = false;
						if(this.holdingArrowKey)
						{
							this.holdTimeout = Time.realtimeSinceStartup + 0.025f;
						}
						else
						{
							started = true;
							this.holdTimeout = Time.realtimeSinceStartup + 0.5f;
							this.holdingArrowKey = true;
						}

						if(this.index == -1)
						{
							this.index = 0;
						}
						else
						{
							this.index++;
							if(this.index == this.data.Count - 1 &&
								!started)
							{
								this.holdTimeout += 0.5f;
							}
							else if(this.index >= this.data.Count)
							{
								this.index = 0;
							}
						}
						if(this.index >= 0 && this.index < this.data.Count)
						{
							this.value = this.data[this.index];
							this.editorWindow.Repaint();
						}
						this.UpdateScrollPosition();
					}
				}
			}
			// accept/cancel
			if(Event.current.type == EventType.KeyUp)
			{
				if(Event.current.keyCode == KeyCode.Escape)
				{
					if(this.cancelCallback != null)
					{
						this.cancelCallback();
					}
					this.Close();
				}
				else if(this.selectCallback != null &&
					(Event.current.keyCode == KeyCode.Return ||
					Event.current.keyCode == KeyCode.KeypadEnter))
				{
					this.selectCallback(this.value);
					this.Close();
				}
			}
		}

		private bool ShowTextField()
		{
			bool update = false;
			GUI.SetNextControlName(this.controlName);
			string tmpValue = this.value;
			this.value = EditorGUILayout.TextField(this.value, EditorContent.Instance.PopupTextFieldStyle, GUILayout.ExpandWidth(true));

			// update data list
			if(this.updateCallback != null &&
				this.value != tmpValue)
			{
				update = true;
				this.data = this.updateCallback(this.value);
				this.UpdateHeight();
				this.index = -1;
			}

			// select text end when opening
			if(this.firstFocus)
			{
				if(GUI.GetNameOfFocusedControl() == this.controlName)
				{
					TextEditor editor = EditorReflection.Instance.GetTextEditor();
					if(editor != null)
					{
						if(this.textCursor == -1)
						{
							editor.cursorIndex = this.value.Length;
							editor.selectIndex = editor.cursorIndex;
						}
						else
						{
							editor.cursorIndex = this.textCursor;
							editor.selectIndex = this.textSelection;
						}

						this.editorWindow.Repaint();
						this.firstFocus = false;
					}
				}
				else
				{
					EditorGUI.FocusTextInControl(this.controlName);
				}
			}
			if(this.selectCallback != null)
			{
				this.selectCallback(this.value);
			}
			return update;
		}

		private void StoreTextCursor()
		{
			if(!this.firstFocus &&
				GUI.GetNameOfFocusedControl() == this.controlName)
			{
				TextEditor editor = EditorReflection.Instance.GetTextEditor();
				if(editor != null)
				{
					this.textCursor = editor.cursorIndex;
					this.textSelection = editor.selectIndex;
				}
			}
		}

		private void ShowDataList()
		{
			if(this.data != null && this.data.Count > 0)
			{
				this.scroll = EditorGUILayout.BeginScrollView(this.scroll);
				EditorGUILayout.BeginVertical();
				for(int i = 0; i < this.data.Count; i++)
				{
					if(GUILayout.Button(this.data[i], this.index == i ?
						EditorContent.Instance.SelectedPopupListStyle :
						EditorContent.Instance.PopupListStyle))
					{
						this.value = this.data[i];
						if(this.selectCallback != null)
						{
							this.selectCallback(this.value);
						}
						this.Close();
					}
					else if(this.mouseMoved && Event.current.type == EventType.Repaint &&
						GUILayoutUtility.GetLastRect().Contains(Event.current.mousePosition) &&
						this.CursorInList())
					{
						this.mouseMoved = false;
						this.index = i;
						this.editorWindow.Repaint();
					}

				}
				EditorGUILayout.EndVertical();
				EditorGUILayout.EndScrollView();
			}
		}

		private void UpdateScrollPosition()
		{
			float indexPos = this.index * this.listLabelHeight;
			if(this.index == 0)
			{
				this.scroll.y = 0;
			}
			else if(indexPos < this.scroll.y)
			{
				this.scroll.y = indexPos;
			}
			else if((this.scroll.y + this.editorWindow.position.height - this.textFieldHeight) <
				indexPos + this.listLabelHeight)
			{
				this.scroll.y += (indexPos + this.listLabelHeight) -
					(this.scroll.y + this.editorWindow.position.height - this.textFieldHeight);
			}
		}
	}
}
