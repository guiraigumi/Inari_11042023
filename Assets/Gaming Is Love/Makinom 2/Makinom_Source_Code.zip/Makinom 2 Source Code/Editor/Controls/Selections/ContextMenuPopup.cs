﻿
using UnityEngine;
using UnityEditor;
using UnityEditor.AnimatedValues;
using UnityEditor.IMGUI.Controls;
using System.Collections.Generic;
using System;

namespace GamingIsLove.Makinom.Editor
{
	public class ContextMenuPopup : BaseSelectionPopup
	{
		public ContextMenuPopup(string name, List<Element> tree,
			Vector2 callPosition, Notify closeCallback, BaseEditor baseEditor)
		{
			this.Init(BaseSelectionPopup.WIDTH, 0, name, tree, callPosition, new Rect(), closeCallback, baseEditor);
		}


		/*
		============================================================================
		Element classes
		============================================================================
		*/
		public class MenuElement : Element
		{
			private Notify notify;

			public MenuElement(string name, string description,
				Notify notify) : this(name, description, notify, null)
			{

			}

			public MenuElement(string name, string description,
				Notify notify, Element parent) : base(name, description, parent)
			{
				this.notify = notify;
			}

			public override void Accepted()
			{
				if(this.notify != null)
				{
					this.notify();
				}
				this.popup.Close();
			}
		}

		public class ObjectMenuElement : Element
		{
			private NotifyObject notify;

			private object value;

			public ObjectMenuElement(string name, string description,
				NotifyObject notify, object value) : this(name, description, notify, value, null)
			{

			}

			public ObjectMenuElement(string name, string description,
				NotifyObject notify, object value, Element parent) : base(name, description, parent)
			{
				this.notify = notify;
				this.value = value;
			}

			public override void Accepted()
			{
				if(this.notify != null)
				{
					this.notify(this.value);
				}
				this.popup.Close();
			}

			public override object Value
			{
				get { return this.value; }
			}

			public override bool CheckValue(object value)
			{
				return this.value == value;
			}
		}
	}
}
