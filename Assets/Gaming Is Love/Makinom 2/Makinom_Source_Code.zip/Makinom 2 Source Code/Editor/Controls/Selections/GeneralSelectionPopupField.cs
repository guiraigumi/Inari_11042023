﻿
using UnityEngine;
using UnityEditor;
using UnityEditor.IMGUI.Controls;
using System.Collections.Generic;

namespace GamingIsLove.Makinom.Editor
{
	public class GeneralSelectionPopupField
	{
		private MakinomEditorWindow parent;

		private Rect lastBounds;

		private bool isOpen = false;

		private bool changed = false;


		// next value
		private bool setNextIndex = false;

		private int nextIndex = -1;

		public GeneralSelectionPopupField()
		{

		}

		protected string GetItemName(string item)
		{
			int index = item.LastIndexOf("/");
			if(index >= 0 && index < item.Length - 1)
			{
				return item.Substring(index + 1, item.Length - index - 1);
			}
			return item;
		}

		public bool IsOpen
		{
			get { return this.isOpen; }
		}

		public void Edit(GUIContent content, ref int index, string[] items, string[] descriptions,
			string helpInfo, AttributeHelper attributes, BaseEditor baseEditor)
		{
			if(this.setNextIndex)
			{
				this.setNextIndex = false;
				index = this.nextIndex;
				this.nextIndex = -1;
				GUI.FocusControl("");
			}
			if(this.changed)
			{
				GUI.changed = true;
				this.changed = false;
			}

			if(baseEditor != null && !baseEditor.isInspector)
			{
				if(this.parent == null)
				{
					this.parent = baseEditor is BaseEditorTab ?
						((BaseEditorTab)baseEditor).Editor :
						MakinomEditorWindow.Instance;
				}
				EditorGUILayout.BeginHorizontal();
			}

			GUILayoutOption layout = EditorTool.WIDTH_150;
			if(baseEditor != null && baseEditor.isInspector)
			{
				layout = EditorTool.W_EXPAND;
			}
			else if(attributes != null && attributes.width != null)
			{
				layout = attributes.width.GetWidth();
			}
			else if(Maki.EditorSettings.popupLonger)
			{
				layout = EditorTool.WIDTH_LONG;
			}

			EditorTool.BeginSetting(content.text, false);
			EditorGUILayout.BeginHorizontal();

			bool showName = attributes == null ||
				attributes.width == null ||
				!attributes.width.hideName ||
				baseEditor.isInspector;

			if(baseEditor.inspectorHideNextName)
			{
				showName = false;
				baseEditor.inspectorHideNextName = false;
			}

			// name label
			if(showName)
			{
				EditorGUILayout.PrefixLabel(content);
			}

			// popup button
			if(EditorGUILayout.DropdownButton(
				new GUIContent(index >= 0 && index < items.Length ? this.GetItemName(items[index]) : "-",
					showName ? "" : content.tooltip),
				FocusType.Keyboard, layout))
			{
				GUI.FocusControl(content.text);
				this.isOpen = true;
				PopupWindow.Show(this.lastBounds,
					new GeneralSelectionPopup(content.text, index, items, descriptions, this.lastBounds.height,
						EditorGUIUtility.GUIToScreenPoint(
							new Vector2(this.lastBounds.x, this.lastBounds.y + this.lastBounds.height)),
						this.lastBounds, this.SelectIndex, this.PopupClosed, baseEditor));
			}
			else if(Event.current.type == EventType.Repaint)
			{
				this.lastBounds = GUILayoutUtility.GetLastRect();
			}

			EditorGUILayout.EndHorizontal();
			EditorTool.EndSetting(content.text, content.tooltip, helpInfo, false);


			if(this.parent != null)
			{
				EditorGUILayout.EndHorizontal();
			}
		}

		public void EditSimple(string name, ref int index, string[] items, string[] descriptions,
			string helpText, string helpInfo, BaseEditor baseEditor, bool hideName, bool expandWidth)
		{
			if(this.setNextIndex)
			{
				this.setNextIndex = false;
				index = this.nextIndex;
				this.nextIndex = -1;
				GUI.FocusControl("");
			}
			if(this.changed)
			{
				GUI.changed = true;
				this.changed = false;
			}

			if(baseEditor != null && !baseEditor.isInspector)
			{
				if(this.parent == null)
				{
					this.parent = baseEditor is BaseEditorTab ?
						((BaseEditorTab)baseEditor).Editor :
						MakinomEditorWindow.Instance;
				}
			}

			GUILayoutOption layout = EditorTool.WIDTH_150;
			if(expandWidth || (baseEditor != null && baseEditor.isInspector))
			{
				layout = EditorTool.W_EXPAND;
			}

			EditorTool.BeginSetting(name, false);
			EditorGUILayout.BeginHorizontal();

			// name label
			if(!hideName)
			{
				EditorGUILayout.PrefixLabel(new GUIContent(name, helpText));
			}

			// popup button
			if(EditorGUILayout.DropdownButton(
				new GUIContent(index >= 0 && index < items.Length ? this.GetItemName(items[index]) : "-",
					hideName ? helpText : ""),
				FocusType.Keyboard, layout))
			{
				GUI.FocusControl(name);
				this.isOpen = true;
				PopupWindow.Show(this.lastBounds,
					new GeneralSelectionPopup(name, index, items, descriptions, this.lastBounds.height,
						EditorGUIUtility.GUIToScreenPoint(
							new Vector2(this.lastBounds.x, this.lastBounds.y + this.lastBounds.height)),
						this.lastBounds, this.SelectIndex, this.PopupClosed, baseEditor));
			}
			else if(Event.current.type == EventType.Repaint)
			{
				this.lastBounds = GUILayoutUtility.GetLastRect();
			}

			EditorGUILayout.EndHorizontal();
			EditorTool.EndSetting(name, helpText, helpInfo, false);
		}

		private void SelectIndex(int index)
		{
			this.setNextIndex = true;
			this.nextIndex = index;
		}

		private void PopupClosed()
		{
			this.changed = true;
			this.isOpen = false;
			if(this.parent != null)
			{
				this.parent.Focus();
			}
		}
	}
}
