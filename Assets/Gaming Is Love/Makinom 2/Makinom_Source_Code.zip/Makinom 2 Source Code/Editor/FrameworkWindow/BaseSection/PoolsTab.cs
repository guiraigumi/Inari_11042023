
using GamingIsLove.Makinom;
using UnityEditor;
using UnityEngine;

namespace GamingIsLove.Makinom.Editor
{
	public class PoolsTab : GenericAssetListTab<PoolAsset, PoolSetting>
	{
		public PoolsTab(MakinomEditorWindow parent) : base(parent)
		{

		}


		/*
		============================================================================
		Properties
		============================================================================
		*/
		public override string Name
		{
			get { return "Game Object Pools"; }
		}

		public override string HelpText
		{
			get
			{
				return "Set up prefabs that should be pooled.\n" +
					"Pooling can be used to improve the performance of your game and " +
					"is best used for prefabs that are spawned and destroyed often, e.g. projectiles.";
			}
		}

		public override string HelpInfo
		{
			get { return "https://makinom.com/guide/documentation/features/pooling/"; }
		}
	}
}
