
using GamingIsLove.Makinom;
using UnityEditor;
using UnityEngine;

namespace GamingIsLove.Makinom.Editor
{
	public class FormulaTypesTab : GenericAssetListTab<FormulaTypeAsset, FormulaType>
	{
		public FormulaTypesTab(MakinomEditorWindow parent) : base(parent)
		{

		}


		/*
		============================================================================
		Properties
		============================================================================
		*/
		public override string Name
		{
			get { return "Formula Types"; }
		}

		public override string HelpText
		{
			get
			{
				return "Formula types are only used to filter formulas in the editor.\n" +
					"Use them if you're setting up many different formulas.";
			}
		}

		public override string HelpInfo
		{
			get { return ""; }
		}
	}
}

