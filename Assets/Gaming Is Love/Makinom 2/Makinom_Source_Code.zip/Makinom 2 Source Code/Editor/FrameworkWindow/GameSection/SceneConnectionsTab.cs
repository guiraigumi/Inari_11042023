﻿
using GamingIsLove.Makinom;
using GamingIsLove.Makinom.Components;
using UnityEngine;
using UnityEngine.SceneManagement;
using UnityEditor;
using UnityEditor.SceneManagement;
using System.Collections.Generic;

namespace GamingIsLove.Makinom.Editor
{
	public sealed class SceneConnectionsTab : BaseEditorTab
	{
		public SceneConnectionsTab(MakinomEditorWindow parent)
		{
			this.parent = parent;
		}


		/*
		============================================================================
		Properties
		============================================================================
		*/
		public override string Name
		{
			get { return "Scene Connections"; }
		}

		public override string HelpText
		{
			get
			{
				return "Scan the game's scenes for connections and add custom connections.\n" +
					"Scene connections are used to find navigation markers in other scenes and mark connections to them.";
			}
		}

		public override string HelpInfo
		{
			get { return ""; }
		}

		protected override BaseSettings Settings
		{
			get { return Maki.SceneConnections; }
		}

		protected override IBaseData DisplayedSettings
		{
			get { return Maki.SceneConnections; }
		}


		/*
		============================================================================
		Display functions
		============================================================================
		*/
		public override void ShowSettings()
		{
			if(this.BeginFoldout("Information", "Information on scene connection data", "", true))
			{
				EditorGUILayout.HelpBox("Scene connection information is used by navigation HUDs " +
					"to calculate the path from the player's current position to the marker.\n" +
					"If a path is found, a marker will be displayed at the scene changers " +
					"that will ultimately lead the player to the marker.\n" +
					"You can define connection data yourself, but it's faster to " +
					"simply let the editor scan all scenes added to the Unity build settings.\n" +
					"Keep in mind, that you need to re-scan the scenes when you change something or add new scenes.",
					MessageType.Info);
			}
			this.EndFoldout();

			EditorAutomation.Automate(Maki.SceneConnections, this);

			if(this.BeginFoldout("Scanned Scene Connections", "Displays automatically scanned scene connections.", "", true))
			{
				EditorGUILayout.BeginHorizontal();
				if(EditorTool.Button(new GUIContent("Scan All Scenes", EditorContent.Instance.AddIcon), "Scans all scenes added to Unity's build settings.\n" +
					"This will delete all previously scanned data and replace it with the new data.\n" +
					"Please save your current scene before scanning, or the changes you made without saving will be lost.", ""))
				{
					if(EditorUtility.DisplayDialog("Scan All Scenes", "Scans all scenes added to Unity's build settings.\n" +
						"This will delete all previously scanned data and replace it with the new data.\n" +
						"Please save your current scene before scanning, or the changes you made without saving will be lost.",
						"Scan", "Cancel"))
					{
						// remember current scene
						string path = EditorSceneManager.GetActiveScene().path;

						List<SceneConnection> list = new List<SceneConnection>();
						for(int i = 0; i < EditorBuildSettings.scenes.Length; i++)
						{
							if(EditorBuildSettings.scenes[i].enabled)
							{
								list.Add(this.ScanScene(EditorBuildSettings.scenes[i].path));
							}
						}
						Maki.SceneConnections.scannedConnections = list.ToArray();

						// open remembered scene
						EditorSceneManager.OpenScene(path, OpenSceneMode.Single);
					}
					this.parent.Focus();
				}
				if(EditorTool.Button(new GUIContent("Remove Data", EditorContent.Instance.RemoveIcon), "Remove all scanned data.", ""))
				{
					if(EditorUtility.DisplayDialog("Remove Data", "All previously scanned scene connection data will be removed.",
						"Remove", "Cancel"))
					{
						Maki.SceneConnections.scannedConnections = null;
					}
					this.parent.Focus();
				}
				GUILayout.FlexibleSpace();
				EditorGUILayout.EndHorizontal();

				EditorAutomation.Automate("scannedConnections", Maki.SceneConnections, this, true);
			}
			this.EndFoldout();
		}

		private SceneConnection ScanScene(string path)
		{
			EditorSceneManager.OpenScene(path, OpenSceneMode.Single);
			path = path.Substring(path.LastIndexOf("/") + 1);
			path = path.Substring(0, path.LastIndexOf("."));

			// find all scene changers
			List<SceneConnectionSceneChanger> sceneChangers = new List<SceneConnectionSceneChanger>();

			Object[] objects = Object.FindObjectsOfType(typeof(SceneChanger));
			if(objects != null)
			{
				for(int j = 0; j < objects.Length; j++)
				{
					if(objects[j] != null && objects[j] is SceneChanger)
					{
						sceneChangers.Add(new SceneConnectionSceneChanger(objects[j] as SceneChanger));
					}
				}
			}

			return new SceneConnection(path, sceneChangers.ToArray());
		}
	}
}
