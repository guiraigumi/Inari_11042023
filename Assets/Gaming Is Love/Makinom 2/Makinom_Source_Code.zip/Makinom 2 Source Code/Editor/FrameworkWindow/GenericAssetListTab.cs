﻿
using GamingIsLove.Makinom;
using UnityEditor;
using UnityEditorInternal;
using UnityEditor.IMGUI.Controls;
using UnityEngine;
using System.Collections.Generic;

namespace GamingIsLove.Makinom.Editor
{
	public abstract class GenericAssetListTab<T, V> : BaseEditorTab where T : MakinomGenericAsset<V> where V : BaseIndexData, new()
	{
		protected GenericAssetList<T> assetList;


		// data filtering and searching
		protected FilteredList filter;

		protected SearchField listSearchField;

		protected bool isType = false;


		// limited licence
		protected int noRemoveCount = 1;

		public GenericAssetListTab(MakinomEditorWindow parent)
		{
			this.parent = parent;

			this.assetList = EditorDataHandler.Instance.GetAssets<T>();
			this.DefaultSetup();

			if(typeof(IHasTypeAsset).IsAssignableFrom(typeof(T)))
			{
				this.isType = true;
			}
		}

		public override void Reloaded()
		{
			base.Reloaded();
			if(this.filter != null)
			{
				this.filter.created = false;
			}
		}

		public override void DefaultSetup()
		{
			if(this.assetList.Assets.Count == 0)
			{
				T asset = ScriptableObject.CreateInstance<T>();
				asset.Settings = new V();
				asset.Settings.EditorName = "Default";
				this.assetList.Add(asset);
			}
		}


		/*
		============================================================================
		Properties
		============================================================================
		*/
		protected override BaseSettings Settings
		{
			get { return null; }
		}

		protected override IBaseData DisplayedSettings
		{
			get
			{
				if(this.assetList.AssetExists(this.index))
				{
					return this.assetList.Assets[this.index].Settings;
				}
				return null;
			}
		}

		protected virtual V CurrentSettings
		{
			get
			{
				if(this.assetList.AssetExists(this.index))
				{
					return this.assetList.Assets[this.index].Settings;
				}
				return null;
			}
		}

		public override int Count
		{
			get { return this.assetList.Count; }
		}

		public override System.Type InstanceType
		{
			get { return typeof(T); }
		}


		/*
		============================================================================
		Settings display
		============================================================================
		*/
		public override void ShowTab()
		{
			this.ClearShow();

			EditorGUILayout.BeginHorizontal();

			this.ShowList();
			this.Editor.TabListDrag();

			this.BeforeSettings();

			EditorGUILayout.BeginVertical();
			this.ShowSearchSettings();
			this.BeforeScrollView();
			try
			{
				this.SettingsScroll = EditorGUILayout.BeginScrollView(this.SettingsScroll);
			}
			catch
			{
				this.Editor.Repaint();
			}
			EditorGUI.BeginDisabledGroup(!this.editable);
			this.ShowSettings();
			this.CloseAllFoldouts();
			EditorGUI.EndDisabledGroup();
			GUILayout.FlexibleSpace();
			EditorGUILayout.EndScrollView();
			this.AfterScrollView();
			EditorGUILayout.EndVertical();

			this.AfterSettings();

			EditorGUILayout.EndHorizontal();
		}


		/*
		============================================================================
		List data functions
		============================================================================
		*/
		protected virtual void AddData()
		{
			this.assetList.Add();
			this.Index = this.Count - 1;
			this.Filter.Deactivate();
		}

		protected virtual void CopyData()
		{
			this.assetList.Copy(this.index);
			this.Index = this.Count - 1;
			this.Filter.Deactivate();
		}

		protected virtual void RemoveData()
		{
			this.assetList.Remove(this.index);
			this.Filter.Deactivate();
		}

		protected virtual void MoveDataUp()
		{
			if(this.index > 0)
			{
				this.assetList.Move(this.index, -1);
				this.index--;
				this.Filter.created = false;
			}
		}

		protected virtual void MoveDataDown()
		{
			if(this.index < this.Count - 1)
			{
				this.assetList.Move(this.index, 1);
				this.index++;
				this.Filter.created = false;
			}
		}


		/*
		============================================================================
		List display
		============================================================================
		*/
		protected virtual bool CanAdd
		{
			get { return true; }
		}

		protected virtual bool CanSort
		{
			get { return true; }
		}

		protected virtual bool CanEdit(int index)
		{
			return true;
		}

		protected virtual FilteredList Filter
		{
			get
			{
				if(this.filter == null)
				{
					this.filter = new FilteredList(this);
				}
				return this.filter;
			}
		}

		public override void ListReordered(int oldIndex, int newIndex)
		{
			this.assetList.Move(oldIndex, newIndex - oldIndex);
		}

		protected virtual void ShowList()
		{
			EditorGUILayout.BeginVertical(EditorContent.Instance.BoxSlimStyle,
				GUILayout.Width(EditorDataHandler.Instance.EditorAsset.TabListDrag));

			// add, copy and remove
			this.ShowListButtons();

			if(this.Count != this.lastCount)
			{
				this.lastCount = this.Count;
				this.Filter.Deactivate();
			}

			// filter and search
			bool showFilter = EditorTool.BeginFoldoutSearchFilter(ref this.filterFoldout, EditorContent.Instance.SearchFilterSortContent, "");
			if(this.ShowSearchList())
			{
				this.Filter.CreateFilterList(this.assetList.Assets);
			}
			if(showFilter)
			{
				this.ShowFilter();

				EditorGUI.BeginDisabledGroup(!this.CanSort);
				// move buttons
				// move up
				EditorGUILayout.BeginHorizontal();
				EditorGUI.BeginDisabledGroup(this.index <= 0);
				GUI.SetNextControlName("UpList");
				if(EditorTool.Button(EditorContent.Instance.MoveUpContent))
				{
					GUI.FocusControl("UpList");
					this.MoveDataUp();
				}
				EditorGUI.EndDisabledGroup();
				// move down
				EditorGUI.BeginDisabledGroup(this.index < 0 ||
					this.index >= this.Count - 1);
				GUI.SetNextControlName("DownList");
				if(EditorTool.Button(EditorContent.Instance.MoveDownContent))
				{
					GUI.FocusControl("DownList");
					this.MoveDataDown();
				}
				EditorGUI.EndDisabledGroup();
				EditorGUILayout.EndHorizontal();

				EditorGUILayout.BeginHorizontal();
				GUILayout.Label("Sort by Name", EditorStyles.boldLabel, EditorTool.W_SMALL_BUTTON);
				// name sort
				GUI.SetNextControlName("SortAZ");
				if(EditorTool.Button(new GUIContent("A-Z", "Sort by name ascending"), EditorTool.WIDTH_45))
				{
					GUI.FocusControl("SortAZ");
					this.assetList.SortByName(false);
					this.Filter.created = false;
				}
				GUI.SetNextControlName("SortZA");
				if(EditorTool.Button(new GUIContent("Z-A", "Sort by name descending"), EditorTool.WIDTH_45))
				{
					GUI.FocusControl("SortZA");
					this.assetList.SortByName(true);
					this.Filter.created = false;
				}
				GUILayout.FlexibleSpace();
				EditorGUILayout.EndHorizontal();
				// type name sort
				if(this.isType)
				{
					EditorGUILayout.BeginHorizontal();
					GUILayout.Label("Sort by Type", EditorStyles.boldLabel, EditorTool.W_SMALL_BUTTON);
					GUI.SetNextControlName("SortTypeAZ");
					if(EditorTool.Button(new GUIContent("A-Z", "Sort by type name ascending"), EditorTool.WIDTH_45))
					{
						GUI.FocusControl("SortTypeAZ");
						this.assetList.SortByTypeName(false);
						this.Filter.created = false;
					}
					GUI.SetNextControlName("SortTypeZA");
					if(EditorTool.Button(new GUIContent("Z-A", "Sort by type name descending"), EditorTool.WIDTH_45))
					{
						GUI.FocusControl("SortTypeZA");
						this.assetList.SortByTypeName(true);
						this.Filter.created = false;
					}
					GUILayout.FlexibleSpace();
					EditorGUILayout.EndHorizontal();
				}
				EditorGUI.EndDisabledGroup();
				EditorGUILayout.Separator();
			}
			EditorTool.EndFoldout();

			if(this.index >= 0 &&
				this.index < this.assetList.Count &&
				this.assetList.Assets[this.index].Settings.EditorName != this.Filter.GetName(this.index))
			{
				this.Filter.created = false;
			}
			if(!this.Filter.created)
			{
				this.Filter.CreateFilterList(this.assetList.Assets);
			}


			// data list
			this.listScroll = EditorGUILayout.BeginScrollView(this.listScroll);

			if(this.HasGeneralSettings)
			{
				EditorGUILayout.Separator();
				if(EditorTool.SelectionGridButton(
					new GUIContent(this.GeneralSettingsName, EditorContent.Instance.ListIcon),
					this.GeneralSettingsHelpText, this.GeneralSettingsHelpInfo,
					this.index == -1))
				{
					this.Index = -1;
				}
				EditorGUILayout.Separator();
			}
			else if(this.index < 0)
			{
				this.Index = 0;
			}
			if(this.index >= this.Count)
			{
				this.Index = this.Count - 1;
			}

			int tmpIndex = this.index;
			this.editable = this.Filter.ShowList(ref tmpIndex);
			this.Index = tmpIndex;
			if(!this.CanEdit(this.index))
			{
				this.editable = false;
			}

			GUILayout.FlexibleSpace();
			EditorGUILayout.EndScrollView();

			EditorGUILayout.EndVertical();
		}

		public virtual void ShowFilter()
		{
			this.Filter.Show(this);
		}

		protected virtual void ShowListButtons()
		{
			EditorGUILayout.BeginVertical();
			GUILayout.Space(2);

			EditorGUI.BeginDisabledGroup(!this.CanAdd);
			GUI.SetNextControlName("AddList");
			if(EditorTool.Button(EditorContent.Instance.AddContent))
			{
				GUI.FocusControl("AddList");
				this.AddData();
			}

			EditorGUI.BeginDisabledGroup(this.Count == 0 ||
				this.index < 0 || this.index >= this.Count);
			GUI.SetNextControlName("CopyList");
			if(EditorTool.Button(EditorContent.Instance.CopyContent))
			{
				GUI.FocusControl("CopyList");
				this.CopyData();
			}
			EditorGUI.EndDisabledGroup();
			EditorGUI.EndDisabledGroup();

			EditorGUI.BeginDisabledGroup(this.index < 0 || this.Count <= this.noRemoveCount);
			GUI.SetNextControlName("RemoveList");
			if(EditorTool.Button(EditorContent.Instance.RemoveContent))
			{
				GUI.FocusControl("RemoveList");
				this.RemoveData();
			}
			EditorGUI.EndDisabledGroup();

			GUILayout.Space(2);
			EditorGUILayout.EndVertical();
		}


		/*
		============================================================================
		Search and filters
		============================================================================
		*/
		public virtual bool ShowSearchList()
		{
			if(this.listSearchField == null)
			{
				this.listSearchField = new SearchField();
			}
			string tmp = this.Filter.search;
			EditorTool.SearchField("Search List", ref this.Filter.search,
				"Search the data list in this tab.", "", this.listSearchField);
			return tmp != this.Filter.search;
		}

		protected virtual bool CheckFilterCondition(int index)
		{
			return true;
		}

		public override bool FocusSearchField()
		{
			if(Event.current.mousePosition.x < EditorDataHandler.Instance.EditorAsset.SubSectionDrag +
				EditorDataHandler.Instance.EditorAsset.TabListDrag)
			{
				if(this.listSearchField != null)
				{
					this.listSearchField.SetFocus();
					return true;
				}
			}
			else if(this.settingsSearchField != null)
			{
				this.settingsSearchField.SetFocus();
				return true;
			}
			return false;
		}


		/*
		============================================================================
		Data filter
		============================================================================
		*/
		protected interface IFilteredListAssetSelection
		{
			bool UseFilter
			{
				get;
			}

			BaseIndexData Selection
			{
				get;
			}

			bool Show(BaseEditor baseEditor);

			bool Check(UnityEngine.Object other);

			void Deactivate();
		}

		protected class FilteredListAssetSelection<T2, V2> : IFilteredListAssetSelection where T2 : MakinomGenericAsset<V2> where V2 : BaseIndexData, new()
		{
			public string[] helpText = new string[0];

			public bool useFilter = false;

			public AssetSource<T2> asset = new AssetSource<T2>();

			private EditorAssetSelectionPopupField assetField = new EditorAssetSelectionPopupField();

			private bool opened = false;

			public FilteredListAssetSelection(string[] helpText)
			{
				this.helpText = helpText;
			}

			public bool UseFilter
			{
				get { return this.useFilter; }
			}

			public BaseIndexData Selection
			{
				get { return this.asset.StoredAsset != null ? this.asset.StoredAsset.Settings : null; }
			}

			public bool Show(BaseEditor baseEditor)
			{
				bool changed = false;
				bool tmpUse = this.useFilter;
				this.useFilter = EditorGUILayout.ToggleLeft(this.helpText[0], this.useFilter, EditorTool.WIDTH_LABEL);
				EditorTool.CheckHelpText(this.helpText[0], this.helpText[1], this.helpText[2]);
				if(tmpUse != this.useFilter)
				{
					changed = true;
				}

				if(this.useFilter)
				{
					AssetSource selection = (AssetSource)this.asset;
					this.assetField.EditSimple(this.helpText[0],
						ref selection, this.helpText[1], this.helpText[2],
						baseEditor, true, true);
					if(this.assetField.IsOpen)
					{
						this.opened = true;
					}
					if(this.opened != this.assetField.IsOpen)
					{
						changed = true;
						this.opened = false;
					}
				}
				return changed;
			}

			public bool Check(UnityEngine.Object other)
			{
				return !this.useFilter || this.asset.Source.EditorAsset == other;
			}

			public void Deactivate()
			{
				this.useFilter = false;
			}
		}

		protected class FilteredList
		{
			private GenericAssetListTab<T, V> parent;

			public string search = "";

			public bool created = false;


			// type id filtering
			public IFilteredListAssetSelection[] assetFilterSelection = new IFilteredListAssetSelection[0];


			// data list
			private List<string> nameList = new List<string>();

			private List<int> indexList = new List<int>();

			private ReorderableList reorderableList;

			public FilteredList(GenericAssetListTab<T, V> parent)
			{
				this.parent = parent;

				this.reorderableList = new ReorderableList(this.nameList, typeof(string), true, false, false, false);
				this.reorderableList.onReorderCallbackWithDetails = this.Reorder;
				this.reorderableList.drawElementCallback = this.DrawElement;
				this.reorderableList.headerHeight = 3;
				this.reorderableList.draggable = this.parent.CanSort;
			}

			public FilteredList(GenericAssetListTab<T, V> parent, params IFilteredListAssetSelection[] assetFilterSelection)
			{
				this.parent = parent;
				this.assetFilterSelection = assetFilterSelection;

				this.reorderableList = new ReorderableList(this.nameList, typeof(string), true, false, false, false);
				this.reorderableList.onReorderCallbackWithDetails = this.Reorder;
				this.reorderableList.drawElementCallback = this.DrawElement;
				this.reorderableList.headerHeight = 3;
				this.reorderableList.draggable = this.parent.CanSort;
			}

			public string GetName(int index)
			{
				if(index >= 0 &&
					index < this.nameList.Count)
				{
					return this.nameList[index];
				}
				return "";
			}

			public void Reorder(ReorderableList list, int oldIndex, int newIndex)
			{
				this.parent.ListReordered(this.indexList[oldIndex], this.indexList[newIndex]);
				this.created = false;
			}

			public void DrawElement(Rect rect, int index, bool isActive, bool isFocused)
			{
				rect.y -= 1;
				GUI.Label(rect, this.nameList[index],
					isActive ?
						EditorContent.Instance.SelectionGridSelectedStyle :
						EditorContent.Instance.SelectionGridStyle);
			}

			public virtual void Show(BaseEditor baseEditor)
			{
				for(int i = 0; i < this.assetFilterSelection.Length; i++)
				{
					if(this.assetFilterSelection[i].Show(baseEditor))
					{
						this.created = false;
					}
				}
				EditorGUILayout.Separator();
			}

			public virtual void Deactivate()
			{
				for(int i = 0; i < this.assetFilterSelection.Length; i++)
				{
					this.assetFilterSelection[i].Deactivate();
				}
				this.created = false;
			}

			public virtual void CreateFilterList(List<T> data)
			{
				this.nameList.Clear();
				this.indexList.Clear();

				for(int i = 0; i < data.Count; i++)
				{
					if((this.search == "" ||
							data[i].Settings.EditorName.IndexOf(this.search, System.StringComparison.OrdinalIgnoreCase) >= 0) &&
						this.parent.CheckFilterCondition(i))
					{
						this.nameList.Add(data[i].Index + ": " + data[i].Settings.EditorName);
						this.indexList.Add(i);
					}
				}
				this.created = true;
			}

			public virtual bool ShowList(ref int index)
			{
				bool edit = index == -1;
				if(this.nameList.Count > 0)
				{
					int prev = index;

					// get fake ID
					int fakeID = -1;
					for(int i = 0; i < this.indexList.Count; i++)
					{
						if(this.indexList[i] == index)
						{
							fakeID = i;
							edit = true;
							break;
						}
					}

					this.reorderableList.index = fakeID;
					this.reorderableList.DoLayoutList();
					fakeID = this.reorderableList.index;

					if(fakeID >= 0 &&
						fakeID < this.indexList.Count)
					{
						index = this.indexList[fakeID];
						edit = true;
					}

					if(prev != index)
					{
						if(GUI.GetNameOfFocusedControl() != "Search List")
						{
							GUI.FocusControl("ListID");
						}
					}
				}
				return edit;
			}
		}
	}
}
