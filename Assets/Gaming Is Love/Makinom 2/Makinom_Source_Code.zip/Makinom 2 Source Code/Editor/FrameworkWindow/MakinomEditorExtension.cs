﻿
using UnityEngine;
using System.Collections.Generic;

namespace GamingIsLove.Makinom.Editor
{
	public abstract class MakinomEditorExtension
	{
		/// <summary>
		/// Used to sort the order of editor extensions, defaults to 0.
		/// Extensions are sorted in ascending order, i.e. from lowest to highest sorting value.
		/// ORK Framework uses a sorting value of 100.
		/// </summary>
		public virtual int Sorting
		{
			get { return 0; }
		}


		/*
		============================================================================
		Editor window functions
		============================================================================
		*/
		public abstract void GetSections(MakinomEditorWindow parent, List<GUIContent> sectionHeaderList,
			List<BaseEditorSection> sectionList, Dictionary<string, BaseEditorSection> sectionLookup);

		public abstract void ShowAbout(AboutTab aboutTab);


		/*
		============================================================================
		Setting extensions (display only)
		============================================================================
		*/
		public abstract IBaseData GameControls
		{
			get;
		}

		public abstract IBaseData GameSettings
		{
			get;
		}

		public abstract IBaseData UISettings
		{
			get;
		}

		public abstract IBaseData SaveGameDataSettings
		{
			get;
		}


		/*
		============================================================================
		Additional functions
		============================================================================
		*/
		public abstract void ShowSaveGameFileInfo();

		public abstract void ShowFormulaTest(FormulasTab tab, FormulaAsset formula);


		/*
		============================================================================
		Scene wizard functions
		============================================================================
		*/
		public abstract void ShowSceneWizard(SceneWizard wizard);


		/*
		============================================================================
		Extension manager functions
		============================================================================
		*/
		public virtual void GetExtensionManagerFile(List<System.Uri> downloads, List<string> path)
		{

		}


		/*
		============================================================================
		Editor general settings display
		Return true if found/used.
		============================================================================
		*/
		public virtual bool AutomationCallback(BaseEditor editor, string info)
		{
			return false;
		}

		public virtual bool AutomationCallback(BaseEditor editor, int arrayIndex, string info)
		{
			return false;
		}

		public virtual bool AutomationCheck(BaseEditor editor, string info)
		{
			return false;
		}

		public virtual bool AutomationCheck(BaseEditor editor, int arrayIndex, string info)
		{
			return false;
		}

		public virtual bool InstanceCallback(BaseEditor editor, string info, System.Object instance)
		{
			return false;
		}

		public virtual bool AutomationAddCallback(BaseEditor editor, string info)
		{
			return false;
		}

		public virtual bool AutomationRemoveCallback(BaseEditor editor, int arrayIndex, string info)
		{
			return false;
		}


		/*
		============================================================================
		Sorter class
		============================================================================
		*/
		public class Sorter : IComparer<MakinomEditorExtension>
		{
			public Sorter()
			{

			}

			public int Compare(MakinomEditorExtension x, MakinomEditorExtension y)
			{
				return x.Sorting.CompareTo(y.Sorting);
			}
		}
	}
}
