
using GamingIsLove.Makinom;
using GamingIsLove.Makinom.Editor;
using GamingIsLove.Makinom.Components;
using UnityEditor;
using UnityEngine;

[CustomEditor(typeof(SceneChanger))]
public class SceneChangerInspector : BaseInspector
{
	public override void OnInspectorGUI()
	{
		this.ComponentSetup(target as SceneChanger);
	}

	private void ComponentSetup(SceneChanger target)
	{
		Undo.RecordObject(target, "Change to 'Scene Changer' on " + target.name);
		this.BaseInit(true);

		if(this.baseEditor.BeginFoldout("Scene Change Settings", "", "", true))
		{
			EditorAutomation.Automate(target.settings, this.baseEditor);
			EditorGUILayout.Separator();
		}
		this.baseEditor.EndFoldout();

		this.ShowBaseInteraction(target);

		this.EndSetup();
	}
}