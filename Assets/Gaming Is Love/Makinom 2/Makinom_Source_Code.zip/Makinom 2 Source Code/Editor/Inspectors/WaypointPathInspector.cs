
using GamingIsLove.Makinom;
using GamingIsLove.Makinom.Editor;
using GamingIsLove.Makinom.Components;
using UnityEditor;
using UnityEngine;

[CustomEditor(typeof(WaypointPathComponent))]
public class WaypointPathInspector : BaseInspector
{
	private WaypointPathComponent path;

	private int editCurve = -1;

	private float test = 0;


	/*
	============================================================================
	Enable/disable functions
	============================================================================
	*/
	void OnEnable()
	{
		this.editCurve = -1;
		this.path = this.target as WaypointPathComponent;
	}

	void OnDisable()
	{
		this.editCurve = -1;
	}


	/*
	============================================================================
	Inspector functions
	============================================================================
	*/
	public override void OnInspectorGUI()
	{
		Undo.RecordObject(target, "Change to 'Waypoint Path' on " + target.name);
		this.BaseInit(true);

		// base settings
		if(this.baseEditor.BeginFoldout("Base Settings", "", "", true))
		{
			EditorGUILayout.LabelField("Total Length", this.path.Length.ToString());
			if(EditorTool.Button("Update Length"))
			{
				this.path.UpdatePath();
			}
			EditorGUILayout.Separator();


			// flatten curve
			EditorGUILayout.BeginHorizontal();
			if(EditorTool.Button("Flatten X"))
			{
				Undo.RecordObject(this.path, "Flatten X");
				for(int i = 0; i < this.path.pathPoint.Length; i++)
				{
					this.path.pathPoint[i].position.x = 0;
					this.path.pathPoint[i].outTangent.x = 0;
					this.path.pathPoint[i].inTangent.x = 0;
				}
			}
			if(EditorTool.Button("Flatten Y"))
			{
				Undo.RecordObject(this.path, "Flatten Y");
				for(int i = 0; i < this.path.pathPoint.Length; i++)
				{
					this.path.pathPoint[i].position.y = 0;
					this.path.pathPoint[i].outTangent.y = 0;
					this.path.pathPoint[i].inTangent.y = 0;
				}
			}
			if(EditorTool.Button("Flatten Z"))
			{
				Undo.RecordObject(this.path, "Flatten Z");
				for(int i = 0; i < this.path.pathPoint.Length; i++)
				{
					this.path.pathPoint[i].position.z = 0;
					this.path.pathPoint[i].outTangent.z = 0;
					this.path.pathPoint[i].inTangent.z = 0;
				}
			}
			EditorGUILayout.EndHorizontal();
			EditorGUILayout.Separator();


			// editor settings
			EditorTool.BoldLabel("Editor Settings");
			this.path.pathColor = EditorGUILayout.ColorField("Path Color",
				this.path.pathColor);
			this.path.pathWidth = EditorGUILayout.FloatField("Path Width",
				this.path.pathWidth);
			EditorGUILayout.Separator();


			// loop settings
			EditorTool.BoldLabel("Loop Settings");
			this.path.loopPath = EditorGUILayout.Toggle("Loop Path",
				this.path.loopPath);
			EditorGUILayout.Separator();


			// rotation settings
			EditorTool.BoldLabel("Rotation Settings");
			EditorAutomation.Automate(this.path.rotationSettings, this.baseEditor);

			if(PathRotationType.Value == this.path.rotationSettings.type)
			{
				this.path.rotation = EditorGUILayout.Vector3Field("Rotation",
					this.path.rotation);
			}

			if(PathRotationType.LookAtObject == this.path.rotationSettings.type)
			{
				this.path.lookAtObject = (Transform)EditorGUILayout.ObjectField(
					"Look At", this.path.lookAtObject, typeof(Transform), true);
			}
			else
			{
				this.path.lookAtObject = null;
			}

			if(PathRotationType.None != this.path.rotationSettings.type)
			{
				this.path.smoothRotation = EditorGUILayout.FloatField("Rotation Smoothing",
					this.path.smoothRotation);
			}

			EditorGUILayout.Separator();


		}
		this.baseEditor.EndFoldout();


		// path points
		if(this.baseEditor.BeginFoldout("Path Point Settings", "", "", true))
		{
			if(EditorTool.Button(new GUIContent("Add Path Point", EditorContent.Instance.AddIcon)))
			{
				Undo.RecordObject(this.path, "Add Path Point");
				ArrayHelper.Add(ref this.path.pathPoint,
					new PathPoint(this.path.pathPoint.Length == 0 ? new Vector3(1, 0, 0) :
						this.path.pathPoint[this.path.pathPoint.Length - 1].position));
			}

			for(int i = 0; i < this.path.pathPoint.Length; i++)
			{
				EditorGUILayout.BeginVertical(EditorContent.Instance.InspectorBoxStyle);
				EditorTool.BoldLabel("Path Point " + i);
				if(EditorTool.Button(EditorContent.Instance.RemoveContent, EditorTool.W_SMALL_BUTTON))
				{
					Undo.RecordObject(this.path, "Remove Path Point " + i);
					ArrayHelper.RemoveAt(ref this.path.pathPoint, i);
					return;
				}

				EditorGUILayout.LabelField("Length", this.path.pathPoint[i].Length.ToString());

				this.path.pathPoint[i].position = EditorGUILayout.Vector3Field("Position",
					this.path.pathPoint[i].position);

				if(this.path.loopPath || i < this.path.pathPoint.Length - 1)
				{
					// tangents
					this.path.pathPoint[i].outTangent = EditorGUILayout.Vector3Field("Out Tangent",
						this.path.pathPoint[i].outTangent);
					this.path.pathPoint[i].inTangent = EditorGUILayout.Vector3Field("In Tangent",
						this.path.pathPoint[i].inTangent);
					EditorGUILayout.Separator();


					// approximation for length calculation
					this.path.pathPoint[i].approximation = EditorGUILayout.FloatField("Length Approximation",
						this.path.pathPoint[i].approximation);
					if(this.path.pathPoint[i].approximation < 0.001f)
					{
						this.path.pathPoint[i].approximation = 0.001f;
					}
					EditorGUILayout.Separator();


					// rotation settings
					EditorTool.BoldLabel("Rotation Settings");
					this.path.pathPoint[i].ownRotation = EditorGUILayout.Toggle("Own Rotation",
						this.path.pathPoint[i].ownRotation);

					if(this.path.pathPoint[i].ownRotation)
					{
						if(this.path.pathPoint[i].rotationSettings == null)
						{
							this.path.pathPoint[i].rotationSettings = new PathRotationSettings();
						}
						EditorAutomation.Automate(this.path.pathPoint[i].rotationSettings, this.baseEditor);

						if(PathRotationType.Value == this.path.pathPoint[i].rotationSettings.type)
						{
							this.path.pathPoint[i].rotation = EditorGUILayout.Vector3Field("Rotation",
								this.path.pathPoint[i].rotation);
						}

						if(PathRotationType.LookAtObject == this.path.pathPoint[i].rotationSettings.type)
						{
							this.path.pathPoint[i].lookAtObject = (Transform)EditorGUILayout.ObjectField(
								"Look At", this.path.pathPoint[i].lookAtObject, typeof(Transform), true);
						}
						else
						{
							this.path.pathPoint[i].lookAtObject = null;
						}

						if(PathRotationType.None != this.path.pathPoint[i].rotationSettings.type)
						{
							this.path.pathPoint[i].smoothRotation = EditorGUILayout.FloatField("Rotation Smoothing",
								this.path.pathPoint[i].smoothRotation);
						}
					}
					else
					{
						this.path.pathPoint[i].rotationSettings = null;
						this.path.pathPoint[i].lookAtObject = null;
					}
					EditorGUILayout.Separator();


					// curve editing
					if(this.editCurve == i)
					{
						if(EditorTool.Button(new GUIContent("Stop Editing", EditorContent.Instance.EditIcon)))
						{
							this.editCurve = -1;
						}
					}
					else if(EditorTool.Button(new GUIContent("Edit Curve", EditorContent.Instance.EditIcon)))
					{
						this.editCurve = i;
					}
				}
				EditorGUILayout.Separator();

				EditorGUILayout.EndVertical();
			}
			EditorGUILayout.Separator();
		}
		this.baseEditor.EndFoldout();

		this.EndSetup();
	}


	/*
	============================================================================
	Scene view functions
	============================================================================
	*/
	void OnSceneGUI()
	{
		if(this.path != null &&
			DragAndDrop.objectReferences.Length == 0)
		{
			Color tmp = Handles.color;
			Handles.color = Color.blue;

			Vector3[] pathPosition = new Vector3[this.path.pathPoint.Length];

			for(int i = 0; i < this.path.pathPoint.Length; i++)
			{
				pathPosition[i] = this.path.transform.TransformPoint(this.path.pathPoint[i].position);

				Handles.SphereHandleCap(0, pathPosition[i], Quaternion.identity,
					0.1f * HandleUtility.GetHandleSize(pathPosition[i]), Event.current.type);
			}

			for(int i = 0; i < this.path.pathPoint.Length; i++)
			{
				if(i < this.path.pathPoint.Length - 1)
				{
					this.Curve(this.editCurve == i,
						pathPosition[i],
						this.path.pathPoint[i],
						pathPosition[i + 1],
						this.path.pathPoint[i + 1]);
				}
				else if(this.path.loopPath && this.path.pathPoint.Length > 1)
				{
					this.Curve(this.editCurve == i,
						pathPosition[i],
						this.path.pathPoint[i],
						pathPosition[0],
						this.path.pathPoint[0]);
				}

				Handles.Label(pathPosition[i], "Path Point " + i);

				// move
				if(this.editCurve == -1)
				{
					if(Tool.Move == Tools.current)
					{
						EditorGUI.BeginChangeCheck();
						// handle
						pathPosition[i] = Handles.PositionHandle(
							pathPosition[i],
							Quaternion.identity);

						if(EditorGUI.EndChangeCheck())
						{
							// undo
							Undo.RecordObject(this.path,
								"Move Path Point " + i);
							this.path.pathPoint[i].position = this.path.transform.InverseTransformPoint(pathPosition[i]);
							GUI.changed = true;
						}
					}
				}
			}

			/*for(int i=0; i<this.path.pathPoint.Length; i++)
			{
				this.path.pathPoint[i].position = this.path.transform.InverseTransformPoint(pathPosition[i]);
			}*/

			Handles.color = tmp;

			this.EndSetup();
		}
	}

	private void Curve(bool edit,
		Vector3 startPosition, PathPoint start,
		Vector3 endPosition, PathPoint end)
	{
		if(/*Tool.View == Tools.current) && */edit)
		{
			// start tangent
			// undo
			Undo.RecordObject(this.path,
				"Move Out Tangent");

			// handle
			start.outTangent = Handles.PositionHandle(
				start.outTangent + startPosition,
				Quaternion.identity);

			Handles.DrawAAPolyLine(this.path.pathWidth, startPosition, start.outTangent);
			start.outTangent -= startPosition;


			// end tangent
			// undo
			Undo.RecordObject(this.path,
				"Move In Tangent");

			// handle
			end.inTangent = Handles.PositionHandle(
				end.inTangent + endPosition,
				Quaternion.identity);

			Handles.DrawAAPolyLine(this.path.pathWidth, endPosition, end.inTangent);
			end.inTangent -= endPosition;
		}

		Handles.DrawBezier(
			startPosition,
			endPosition,
			startPosition + start.outTangent,
			endPosition + end.inTangent,
			this.path.pathColor, null, this.path.pathWidth);

		if(edit)
		{
			Handles.FreeRotateHandle(Quaternion.identity,
				this.path.transform.TransformPoint(start.GetPosition(this.test, end)),
				1);
		}
	}
}
