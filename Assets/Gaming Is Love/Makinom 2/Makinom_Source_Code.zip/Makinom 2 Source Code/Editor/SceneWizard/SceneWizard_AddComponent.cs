﻿
using UnityEngine;
using UnityEditor;
using GamingIsLove.Makinom.Components;
using System.Collections.Generic;

namespace GamingIsLove.Makinom.Editor
{
	public abstract class SceneWizard_BaseAddComponent
	{

	}

	[EditorSettingInfo("Camera Event", "")]
	public class SceneWizard_AddComponent_CameraEvent : SceneWizard_BaseAddComponent
	{
		public static void Use()
		{
			SceneObjectHelper.AddToSelectionSimple<CameraEvent>();
		}
	}

	[EditorSettingInfo("Music Player", "")]
	public class SceneWizard_AddComponent_MusicPlayer : SceneWizard_BaseAddComponent
	{
		public static void Use()
		{
			SceneObjectHelper.AddToSelectionSimple<MusicPlayer>();
		}
	}

	[EditorSettingInfo("Pool", "")]
	public class SceneWizard_AddComponent_Pool : SceneWizard_BaseAddComponent
	{
		public static void Use()
		{
			SceneObjectHelper.AddToSelectionSimple<PoolComponent>();
		}
	}

	[EditorSettingInfo("Object Variables", "")]
	public class SceneWizard_AddComponent_ObjectVariables : SceneWizard_BaseAddComponent
	{
		public static void Use()
		{
			SceneObjectHelper.AddToSelectionSimple<ObjectVariablesComponent>();
		}
	}

	[EditorSettingInfo("Place On Ground", "")]
	public class SceneWizard_AddComponent_PlaceOnGround : SceneWizard_BaseAddComponent
	{
		public static void Use()
		{
			SceneObjectHelper.AddToSelectionSimple<PlaceOnGround>();
		}
	}

	[EditorSettingInfo("Scene Changer 2D", "")]
	public class SceneWizard_AddComponent_SceneChanger2D : SceneWizard_BaseAddComponent
	{
		public static void Use()
		{
			foreach(GameObject obj in Selection.objects)
			{
				if(obj != null)
				{
					obj.AddComponent<SceneChanger>();
					if(obj.GetComponent<Collider>() == null)
					{
						CircleCollider2D collider = obj.AddComponent<CircleCollider2D>();
						collider.radius = 5f;
						collider.isTrigger = true;
					}
					obj.layer = 2;
				}
			}
		}
	}

	[EditorSettingInfo("Scene Changer 3D", "")]
	public class SceneWizard_AddComponent_SceneChanger3D : SceneWizard_BaseAddComponent
	{
		public static void Use()
		{
			foreach(GameObject obj in Selection.objects)
			{
				if(obj != null)
				{
					obj.AddComponent<SceneChanger>();
					if(obj.GetComponent<Collider2D>() == null)
					{
						SphereCollider collider = obj.AddComponent<SphereCollider>();
						collider.radius = 5f;
						collider.isTrigger = true;
					}
					obj.layer = 2;
				}
			}
		}
	}

	[EditorSettingInfo("Sound Assignment", "")]
	public class SceneWizard_AddComponent_SoundAssignment : SceneWizard_BaseAddComponent
	{
		public static void Use()
		{
			SceneObjectHelper.AddToSelectionSimple<SoundAssignmentComponent>();
		}
	}

	[EditorSettingInfo("Sound Channel", "")]
	public class SceneWizard_AddComponent_SoundChannel : SceneWizard_BaseAddComponent
	{
		public static void Use()
		{
			SceneObjectHelper.AddToSelectionSimple<SoundChannelComponent>();
		}
	}

	[EditorSettingInfo("Spawn Point", "")]
	public class SceneWizard_AddComponent_SpawnPoint : SceneWizard_BaseAddComponent
	{
		public static void Use()
		{
			SceneObjectHelper.AddToSelection<SpawnPoint>();
		}
	}

	[EditorSettingInfo("Waypoint Path", "")]
	public class SceneWizard_AddComponent_WaypointPath : SceneWizard_BaseAddComponent
	{
		public static void Use()
		{
			SceneObjectHelper.AddToSelectionSimple<WaypointPathComponent>();
		}
	}

	[EditorSettingInfo("Interaction Controller 2D", "")]
	public class SceneWizard_AddComponent_InteractionController2D : SceneWizard_BaseAddComponent
	{
		public static void Use()
		{
			foreach(GameObject obj in Selection.objects)
			{
				if(obj != null)
				{
					if(obj.GetComponent<Collider2D>() == null)
					{
						BoxCollider2D collider = obj.AddComponent<BoxCollider2D>();
						collider.size = new Vector2(1, 2);
						collider.isTrigger = true;
						obj.layer = 2;
					}
					if(obj.GetComponent<Rigidbody2D>() == null)
					{
						Rigidbody2D rigidbody = obj.AddComponent<Rigidbody2D>();
						rigidbody.gravityScale = 0;
						rigidbody.isKinematic = true;
						rigidbody.constraints = RigidbodyConstraints2D.FreezeAll;
					}
					obj.AddComponent<InteractionController>();
				}
			}
		}
	}

	[EditorSettingInfo("Interaction Controller 3D", "")]
	public class SceneWizard_AddComponent_InteractionController3D : SceneWizard_BaseAddComponent
	{
		public static void Use()
		{
			foreach(GameObject obj in Selection.objects)
			{
				if(obj != null)
				{
					if(obj.GetComponent<Collider>() == null)
					{
						BoxCollider collider = obj.AddComponent<BoxCollider>();
						collider.size = new Vector3(1.5f, 2, 1);
						collider.isTrigger = true;
						obj.layer = 2;
					}
					if(obj.GetComponent<Rigidbody>() == null)
					{
						Rigidbody rigidbody = obj.AddComponent<Rigidbody>();
						rigidbody.useGravity = false;
						rigidbody.isKinematic = true;
						rigidbody.constraints = RigidbodyConstraints.FreezeAll;
					}
					obj.AddComponent<InteractionController>();
				}
			}
		}
	}

	[EditorSettingInfo("Component Manager", "")]
	public class SceneWizard_AddComponent_ComponentManager : SceneWizard_BaseAddComponent
	{
		public static void Use()
		{
			SceneObjectHelper.AddToSelectionSimple<ComponentManager>();
		}
	}

	[EditorSettingInfo("Game Object Manager", "")]
	public class SceneWizard_AddComponent_GameObjectManager : SceneWizard_BaseAddComponent
	{
		public static void Use()
		{
			SceneObjectHelper.AddToSelectionSimple<GameObjectManager>();
		}
	}

	[EditorSettingInfo("Radius", "")]
	public class SceneWizard_AddComponent_Radius : SceneWizard_BaseAddComponent
	{
		public static void Use()
		{
			SceneObjectHelper.AddToSelectionSimple<RadiusComponent>();
		}
	}

	[EditorSettingInfo("Object Changers", "")]
	public class SceneWizard_AddComponent_ObjectChanges : SceneWizard_BaseAddComponent
	{
		public static void Use()
		{
			SceneObjectHelper.AddToSelectionSimple<ObjectChanges>();
		}
	}

	[EditorSettingInfo("Move Speed", "")]
	public class SceneWizard_AddComponent_MoveSpeed : SceneWizard_BaseAddComponent
	{
		public static void Use()
		{
			SceneObjectHelper.AddToSelectionSimple<MoveSpeedComponent>();
		}
	}
}
