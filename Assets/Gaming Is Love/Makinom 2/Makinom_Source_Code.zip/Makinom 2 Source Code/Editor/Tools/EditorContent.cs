
using GamingIsLove.Makinom;
using UnityEngine;
using UnityEditor;
using System.Collections.Generic;
using System.Reflection;
using System.IO;

namespace GamingIsLove.Makinom.Editor
{
	public class EditorContent
	{
		private static EditorContent instance;

		private static System.Object instanceLock = new System.Object();

		protected static List<MakinomEditorExtension> extensions;

		private MakinomEditorAsset editorAsset;

		private int unityMainVersion = -1;

		private int unitySubVersion = -1;

		private float uiScale = 1;


		// contents
		private GUIContent saveContent = new GUIContent("Save Settings");

		private GUIContent reloadContent = new GUIContent("Reload Settings");

		private GUIContent cancelContent = new GUIContent("Cancel");

		private GUIContent confirmContent = new GUIContent("Confirm");

		private GUIContent addContent = new GUIContent("Add");

		private GUIContent copyContent = new GUIContent("Copy");

		private GUIContent removeContent = new GUIContent("Remove");

		private GUIContent moveUpContent = new GUIContent("Move Up");

		private GUIContent moveDownContent = new GUIContent("Move Down");

		private GUIContent allFoldoutsContent = new GUIContent(" < All Settings >", "Shows all settings.");

		private GUIContent limitFoldoutContent = new GUIContent(" < Limit View >", "Limits the view to a single foldout.");

		private GUIContent copyToClipboardContent = new GUIContent("", "Copy to Clipboard");

		private GUIContent openLinkContent = new GUIContent("", "Open Link");

		private GUIContent searchFilterSortContent = new GUIContent("Search, Filter & Sort",
			"Search and filter the data list of this tab.\n" +
			"Sort the data by name (ascending or descending) or move data up/down.\n" +
			"You can also move data around via dragging.");




		// big icons
		private Texture2D saveIcon;

		private Texture2D reloadIcon;

		private Texture2D deleteIcon;

		private Texture2D cancelIcon;


		// navigation icons
		private Texture2D navigateBackIcon;

		private Texture2D navigateForwardIcon;


		// small icons
		private Texture2D addIcon;

		private Texture2D copyIcon;

		private Texture2D copyToClipboardIcon;

		private Texture2D pasteFromClipboardIcon;

		private Texture2D pasteSettingsIcon;

		private Texture2D swapIcon;

		private Texture2D removeIcon;

		private Texture2D moveUpIcon;

		private Texture2D moveDownIcon;

		private Texture2D openLinkIcon;

		private Texture2D editBigIcon;


		// micro icons
		private Texture2D plusIcon;

		private Texture2D editIcon;

		private Texture2D listIcon;

		private Texture2D foldoutButtonsIcon;

		private Texture2D openFoldoutsIcon;

		private Texture2D closeFoldoutsIcon;

		private Texture2D smallRemoveIcon;

		private Texture2D searchPreviousIcon;

		private Texture2D searchNextIcon;


		// GUI styles
		private GUILayoutOption labelWidth;

		private GUIStyle emptyStyle = new GUIStyle();

		private GUIStyle foldoutStyle;

		private GUIStyle foldoutPrettyStyle;

		private GUIStyle foldoutInspectorStyle;

		private GUIStyle searchFoundLabelStyle;

		// box
		private GUIStyle boxSlimStyle;

		private GUIStyle boxStyle;

		private GUIStyle boxFoldoutPrettyStyle;

		private GUIStyle boxFoldoutInspectorStyle;

		private GUIStyle boxSearchFilterStyle;

		private GUIStyle searchBoxStyle;

		private GUIStyle nodeBoxStyle;

		private GUIStyle inspectorBoxStyle;

		// text area
		private GUIStyle boxTextAreaStyle;

		private GUIStyle textAreaStyle;

		// buttons
		private GUIStyle selectionGridStyle;

		private GUIStyle selectionGridSelectedStyle;

		private GUIStyle selectionGridCenterStyle;

		private GUIStyle buttonStyle;

		private GUIStyle buttonRichTextStyle;


		// setting highlights
		private GUIStyle settingHighlightStyle;

		private GUIStyle settingHighlightStyle1;

		private GUIStyle settingHighlightStyle2;

		private GUIStyle settingHighlightStyle3;

		private GUIStyle settingHighlightStyle4;

		private GUIStyle settingHighlightStyle5;

		private GUIStyle jumpListHighlightStyle;

		// custom popups
		private GUIStyle popupTextFieldStyle;

		private GUIStyle popupListStyle;

		private GUIStyle hoverPopupListStyle;

		private GUIStyle selectedPopupListStyle;

		private GUIStyle popupListTypeStyle;

		private GUIStyle hoverPopupListTypeStyle;

		private GUIStyle selectedPopupListTypeStyle;

		private GUIStyle popupListHeaderStyle;

		// arrows
		private GUIStyle rightArrowStyle = (GUIStyle)"AC RightArrow";

		private GUIStyle leftArrowStyle = (GUIStyle)"AC LeftArrow";


		// help texts
		private string helpHeader = "";

		private string helpText = "";

		private string helpInfo = "";


		// texts
		private string[] patrons;


		// node clipboards
		private List<EditorClipboard> schematicClipboard = new List<EditorClipboard>();

		private List<EditorClipboard> formulaClipboard = new List<EditorClipboard>();


		// foldouts
		private Dictionary<string, bool> foldoutState = new Dictionary<string, bool>();


		/*
		============================================================================
		Init functions
		============================================================================
		*/
		private EditorContent()
		{
			if(instance != null)
			{
				Debug.LogError("You can't create two instances of EditorContent!");
			}
			else
			{
				instance = this;

				string[] version = Application.unityVersion.Split('.');
				if(!int.TryParse(version[0], out instance.unityMainVersion))
				{
					instance.unityMainVersion = -1;
				}
				if(!int.TryParse(version[1], out instance.unitySubVersion))
				{
					instance.unitySubVersion = -1;
				}
				instance.uiScale = EditorPrefs.HasKey("CustomEditorUIScale") ?
					EditorPrefs.GetInt("CustomEditorUIScale") / 100.0f :
					1;
				if(instance.uiScale < 1)
				{
					instance.uiScale = 1;
				}
			}
		}

		public static EditorContent Instance
		{
			get
			{
				if(instance == null)
				{
					lock(instanceLock)
					{
						if(instance == null)
						{
							new EditorContent();
						}
					}
				}
				return instance;
			}
		}

		public static List<MakinomEditorExtension> Extensions
		{
			get
			{
				if(EditorContent.extensions == null)
				{
					EditorContent.extensions = ReflectionTypeHandler.FindAndCreateAll<MakinomEditorExtension>();
					EditorContent.extensions.Sort(new MakinomEditorExtension.Sorter());
				}
				return EditorContent.extensions;
			}
		}

		public static float UIScale
		{
			get { return EditorContent.Instance.uiScale; }
		}

		private void LoadResources()
		{
			try
			{
				Assembly assembly = Assembly.GetExecutingAssembly();

				// big icons
				// reload
				this.reloadIcon = EditorContent.LoadImage(
					assembly.GetManifestResourceStream("GamingIsLove.Makinom.Editor.Images.Icons.Buttons.Reload.png"),
					32, 32);

				// save
				this.saveIcon = EditorContent.LoadImage(
					assembly.GetManifestResourceStream("GamingIsLove.Makinom.Editor.Images.Icons.Buttons.Save.png"),
					32, 32);

				// delete
				this.deleteIcon = EditorContent.LoadImage(
					assembly.GetManifestResourceStream("GamingIsLove.Makinom.Editor.Images.Icons.Buttons.Delete.png"),
					32, 32);

				// cancel
				this.cancelIcon = EditorContent.LoadImage(
					assembly.GetManifestResourceStream("GamingIsLove.Makinom.Editor.Images.Icons.Buttons.Cancel.png"),
					32, 32);


				// navigation icons
				// back
				this.navigateBackIcon = EditorContent.LoadImage(
					assembly.GetManifestResourceStream("GamingIsLove.Makinom.Editor.Images.Icons.Buttons.NavigateBack.png"),
					24, 24);

				// forward
				this.navigateForwardIcon = EditorContent.LoadImage(
					assembly.GetManifestResourceStream("GamingIsLove.Makinom.Editor.Images.Icons.Buttons.NavigateForward.png"),
					24, 24);

				// small icons
				// add
				this.addIcon = EditorContent.LoadImage(
					assembly.GetManifestResourceStream("GamingIsLove.Makinom.Editor.Images.Icons.Buttons.Add.png"),
					24, 24);

				// copy
				this.copyIcon = EditorContent.LoadImage(
					assembly.GetManifestResourceStream("GamingIsLove.Makinom.Editor.Images.Icons.Buttons.Copy.png"),
					24, 24);

				// copy to clipboard
				this.copyToClipboardIcon = EditorContent.LoadImage(
					assembly.GetManifestResourceStream("GamingIsLove.Makinom.Editor.Images.Icons.Buttons.CopyToClipboard.png"),
					24, 24);

				// paste from clipboard
				this.pasteFromClipboardIcon = EditorContent.LoadImage(
					assembly.GetManifestResourceStream("GamingIsLove.Makinom.Editor.Images.Icons.Buttons.PasteFromClipboard.png"),
					24, 24);

				// paste settings
				this.pasteSettingsIcon = EditorContent.LoadImage(
					assembly.GetManifestResourceStream("GamingIsLove.Makinom.Editor.Images.Icons.Buttons.PasteSettingsFromClipboard.png"),
					24, 24);

				// swap
				this.swapIcon = EditorContent.LoadImage(
					assembly.GetManifestResourceStream("GamingIsLove.Makinom.Editor.Images.Icons.Buttons.Swap.png"),
					24, 24);

				// remove
				this.removeIcon = EditorContent.LoadImage(
					assembly.GetManifestResourceStream("GamingIsLove.Makinom.Editor.Images.Icons.Buttons.Remove.png"),
					24, 24);

				// move up
				this.moveUpIcon = EditorContent.LoadImage(
					assembly.GetManifestResourceStream("GamingIsLove.Makinom.Editor.Images.Icons.Buttons.MoveUp.png"),
					24, 24);

				// move down
				this.moveDownIcon = EditorContent.LoadImage(
					assembly.GetManifestResourceStream("GamingIsLove.Makinom.Editor.Images.Icons.Buttons.MoveDown.png"),
					24, 24);

				// open link
				this.openLinkIcon = EditorContent.LoadImage(
					assembly.GetManifestResourceStream("GamingIsLove.Makinom.Editor.Images.Icons.Buttons.OpenLink.png"),
					24, 24);

				// edit big
				this.editBigIcon = EditorContent.LoadImage(
					assembly.GetManifestResourceStream("GamingIsLove.Makinom.Editor.Images.Icons.Buttons.EditBig.png"),
					24, 24);


				// micro icons
				// plus
				this.plusIcon = EditorContent.LoadImage(
					assembly.GetManifestResourceStream("GamingIsLove.Makinom.Editor.Images.Icons.Buttons.Plus.png"),
					12, 12);

				// edit
				this.editIcon = EditorContent.LoadImage(
					assembly.GetManifestResourceStream("GamingIsLove.Makinom.Editor.Images.Icons.Buttons.Edit.png"),
					12, 12);

				// list
				this.listIcon = EditorContent.LoadImage(
					assembly.GetManifestResourceStream("GamingIsLove.Makinom.Editor.Images.Icons.Buttons.List.png"),
					16, 12);

				// foldout buttons
				this.foldoutButtonsIcon = EditorContent.LoadImage(
					assembly.GetManifestResourceStream("GamingIsLove.Makinom.Editor.Images.Icons.Buttons.FoldoutButtons.png"),
					16, 12);

				// open foldout
				this.openFoldoutsIcon = EditorContent.LoadImage(
					assembly.GetManifestResourceStream("GamingIsLove.Makinom.Editor.Images.Icons.Buttons.OpenFoldouts.png"),
					16, 12);

				// close foldout
				this.closeFoldoutsIcon = EditorContent.LoadImage(
					assembly.GetManifestResourceStream("GamingIsLove.Makinom.Editor.Images.Icons.Buttons.CloseFoldouts.png"),
					16, 12);

				// small remove
				this.smallRemoveIcon = EditorContent.LoadImage(
					assembly.GetManifestResourceStream("GamingIsLove.Makinom.Editor.Images.Icons.Buttons.SmallRemove.png"),
					16, 12);

				// search previous
				this.searchPreviousIcon = EditorContent.LoadImage(
					assembly.GetManifestResourceStream("GamingIsLove.Makinom.Editor.Images.Icons.Buttons.SearchPrevious.png"),
					16, 12);

				// search next
				this.searchNextIcon = EditorContent.LoadImage(
					assembly.GetManifestResourceStream("GamingIsLove.Makinom.Editor.Images.Icons.Buttons.SearchNext.png"),
					16, 12);


				// GUI styles
				string imageBase = EditorGUIUtility.isProSkin ?
					"GamingIsLove.Makinom.Editor.Images.Editor.Dark." :
					"GamingIsLove.Makinom.Editor.Images.Editor.Light.";
				Color highlightTextColor = EditorGUIUtility.isProSkin ?
					new Color(0.25f, 0.25f, 0.25f) :
					new Color(0.94f, 0.94f, 0.94f);


				// foldout
				this.foldoutStyle = new GUIStyle(EditorStyles.foldout);

				this.foldoutPrettyStyle = new GUIStyle(EditorStyles.foldout);
				this.foldoutPrettyStyle.alignment = TextAnchor.MiddleLeft;
				this.foldoutPrettyStyle.fontStyle = FontStyle.Bold;
				this.foldoutPrettyStyle.margin = new RectOffset(0, 0, 0, 0);

				this.foldoutInspectorStyle = new GUIStyle(EditorStyles.foldout);
				this.foldoutInspectorStyle.fontStyle = FontStyle.Bold;
				this.foldoutInspectorStyle.alignment = TextAnchor.MiddleLeft;
				if(this.IsVersionOrLater(2019, 3))
				{
					this.foldoutInspectorStyle.fontSize = 13;
					this.foldoutInspectorStyle.margin = new RectOffset(10, 0, 0, 0);
				}
				else
				{
					this.foldoutInspectorStyle.fontSize = 12;
					this.foldoutInspectorStyle.margin = new RectOffset(20, 0, 0, 0);
				}


				// box style
				this.boxSlimStyle = new GUIStyle();
				this.boxSlimStyle.clipping = TextClipping.Clip;
				this.boxSlimStyle.border = new RectOffset(4, 4, 3, 5);
				this.boxSlimStyle.margin = new RectOffset(0, 0, 0, 0);
				if(this.IsVersionOrLater(2019, 3))
				{
					this.boxSlimStyle.padding = new RectOffset(5, 5, 2, 5);
				}
				else
				{
					this.boxSlimStyle.padding = new RectOffset(5, 5, 5, 5);
				}
				this.boxSlimStyle.overflow = new RectOffset(0, 0, 0, 0);
				this.boxSlimStyle.normal.background = EditorContent.LoadImage(
					assembly.GetManifestResourceStream(imageBase + "BoxStyle.png"),
					32, 32);

				this.boxSearchFilterStyle = new GUIStyle(this.boxSlimStyle);
				this.boxSearchFilterStyle.overflow.left = 5;
				this.boxSearchFilterStyle.overflow.right = 5;
				this.boxSearchFilterStyle.margin.bottom = 2;

				this.boxStyle = new GUIStyle(this.boxSlimStyle);
				this.boxStyle.padding = new RectOffset(10, 10, 10, 10);

				// foldout pretty box
				this.boxFoldoutPrettyStyle = new GUIStyle(this.boxStyle);
				this.boxFoldoutPrettyStyle.padding = new RectOffset(10, 10, 15, 10);

				// foldout inspector box
				this.boxFoldoutInspectorStyle = new GUIStyle(this.boxStyle);
				this.boxFoldoutInspectorStyle.padding = new RectOffset(10, 10, 5, 10);
				//this.boxFoldoutInspectorStyle.margin = new RectOffset(5, 0, 0, 0);

				// text area box
				this.boxTextAreaStyle = new GUIStyle(this.boxSlimStyle);
				this.boxTextAreaStyle.border = new RectOffset(4, 4, 4, 4);
				this.boxTextAreaStyle.normal.background = EditorContent.LoadImage(
					assembly.GetManifestResourceStream(imageBase + "TextBoxStyle.png"),
					32, 32);

				// search box style
				this.searchBoxStyle = new GUIStyle(this.boxSlimStyle);
				this.searchBoxStyle.margin = new RectOffset(0, 0, 0, 0);

				this.searchFoundLabelStyle = new GUIStyle(EditorStyles.miniLabel);
				this.searchFoundLabelStyle.padding.top = 3;

				this.nodeBoxStyle = new GUIStyle();
				this.nodeBoxStyle.padding = new RectOffset(3, 3, 3, 3);
				this.nodeBoxStyle.richText = false;

				this.inspectorBoxStyle = new GUIStyle(this.boxSlimStyle);


				// text area style
				this.textAreaStyle = new GUIStyle(EditorStyles.textArea);
				this.textAreaStyle.wordWrap = true;
				this.textAreaStyle.stretchWidth = true;
				this.textAreaStyle.stretchHeight = true;


				// selection grid buttons (for sub section and data list)
				this.selectionGridStyle = new GUIStyle();
				this.selectionGridStyle.font = GUI.skin.button.font;
				if(this.IsVersionOrLater(2019, 3))
				{
					this.selectionGridStyle.fontSize = 12;
					this.selectionGridStyle.padding = new RectOffset(7, 7, 4, 2);
				}
				else
				{
					this.selectionGridStyle.fontSize = 11;
					this.selectionGridStyle.padding = new RectOffset(7, 7, 4, 3);
				}
				this.selectionGridStyle.clipping = TextClipping.Clip;
				this.selectionGridStyle.alignment = TextAnchor.UpperLeft;
				this.selectionGridStyle.border = new RectOffset(3, 3, 3, 3);
				this.selectionGridStyle.margin = new RectOffset(2, 2, 0, 0);
				this.selectionGridStyle.overflow = new RectOffset(-1, -1, -2, 0);

				this.selectionGridStyle.normal.background = EditorContent.LoadImage(
					assembly.GetManifestResourceStream(imageBase + "ButtonStyle.png"),
					16, 16);
				this.selectionGridStyle.onNormal.background = EditorContent.LoadImage(
					assembly.GetManifestResourceStream(imageBase + "ButtonStyle_Active.png"),
					16, 16);

				this.selectionGridStyle.active.background = EditorContent.LoadImage(
					assembly.GetManifestResourceStream(imageBase + "ButtonStyle_Active.png"),
					16, 16);
				this.selectionGridStyle.onActive.background = EditorContent.LoadImage(
					assembly.GetManifestResourceStream(imageBase + "ButtonStyle_Active.png"),
					16, 16);

				this.selectionGridStyle.hover.background = EditorContent.LoadImage(
					assembly.GetManifestResourceStream(imageBase + "ButtonStyle.png"),
					16, 16);
				this.selectionGridStyle.onHover.background = EditorContent.LoadImage(
					assembly.GetManifestResourceStream(imageBase + "ButtonStyle_Active.png"),
					16, 16);

				this.selectionGridStyle.focused.background = EditorContent.LoadImage(
					assembly.GetManifestResourceStream(imageBase + "ButtonStyle.png"),
					16, 16);
				this.selectionGridStyle.onFocused.background = EditorContent.LoadImage(
					assembly.GetManifestResourceStream(imageBase + "ButtonStyle_Active.png"),
					16, 16);

				this.selectionGridCenterStyle = new GUIStyle(this.selectionGridStyle);
				this.selectionGridCenterStyle.alignment = TextAnchor.MiddleCenter;


				// selected selection grid button (for sub section and data list)
				this.selectionGridSelectedStyle = new GUIStyle(this.selectionGridStyle);
				this.selectionGridSelectedStyle.fontStyle = FontStyle.Bold;
				this.selectionGridSelectedStyle.fontSize += 1;
				this.selectionGridSelectedStyle.stretchHeight = false;
				this.selectionGridSelectedStyle.margin = new RectOffset(0, 0, 0, 0);
				if(this.IsVersionOrLater(2019, 3))
				{
					this.selectionGridSelectedStyle.padding = new RectOffset(9, 9, 3, 2);
				}
				else
				{
					this.selectionGridSelectedStyle.padding = new RectOffset(9, 9, 4, 1);
				}
				this.selectionGridSelectedStyle.overflow = new RectOffset(-1, -1, -1, 1);
				this.selectionGridSelectedStyle.active.textColor = highlightTextColor;
				this.selectionGridSelectedStyle.normal = this.selectionGridSelectedStyle.active;
				this.selectionGridSelectedStyle.hover = this.selectionGridSelectedStyle.active;
				this.selectionGridSelectedStyle.focused = this.selectionGridSelectedStyle.active;

				if(EditorGUIUtility.isProSkin)
				{
					this.selectionGridStyle.normal.textColor = GUI.skin.button.normal.textColor;
					this.selectionGridStyle.hover.textColor = GUI.skin.button.hover.textColor;
					this.selectionGridStyle.focused.textColor = GUI.skin.button.focused.textColor;
					this.selectionGridCenterStyle.normal.textColor = GUI.skin.button.normal.textColor;
					this.selectionGridCenterStyle.hover.textColor = GUI.skin.button.hover.textColor;
					this.selectionGridCenterStyle.focused.textColor = GUI.skin.button.focused.textColor;
				}


				// settings highlight box
				this.settingHighlightStyle = new GUIStyle();
				this.settingHighlightStyle.border = new RectOffset(3, 1, 0, 0);
				this.settingHighlightStyle.overflow = new RectOffset(3, 0, 0, 0);
				this.settingHighlightStyle.padding = new RectOffset(4, 0, 5, 5);
				this.settingHighlightStyle.normal.background = EditorContent.LoadImage(
					assembly.GetManifestResourceStream("GamingIsLove.Makinom.Editor.Images.GUIStyles.SettingsHighlightBox.png"),
					20, 10);
				this.settingHighlightStyle.hover.background = EditorContent.LoadImage(
					assembly.GetManifestResourceStream("GamingIsLove.Makinom.Editor.Images.GUIStyles.SettingsHighlightedBox.png"),
					20, 10);

				// settings highlight box 1
				this.settingHighlightStyle1 = new GUIStyle(this.settingHighlightStyle);
				this.settingHighlightStyle1.normal.background = EditorContent.LoadImage(
					assembly.GetManifestResourceStream("GamingIsLove.Makinom.Editor.Images.GUIStyles.SettingsHighlightBox1.png"),
					20, 10);
				this.settingHighlightStyle1.hover.background = EditorContent.LoadImage(
					assembly.GetManifestResourceStream("GamingIsLove.Makinom.Editor.Images.GUIStyles.SettingsHighlightedBox1.png"),
					20, 10);

				// settings highlight box 2
				this.settingHighlightStyle2 = new GUIStyle(this.settingHighlightStyle);
				this.settingHighlightStyle2.normal.background = EditorContent.LoadImage(
					assembly.GetManifestResourceStream("GamingIsLove.Makinom.Editor.Images.GUIStyles.SettingsHighlightBox2.png"),
					20, 10);
				this.settingHighlightStyle2.hover.background = EditorContent.LoadImage(
					assembly.GetManifestResourceStream("GamingIsLove.Makinom.Editor.Images.GUIStyles.SettingsHighlightedBox2.png"),
					20, 10);

				// settings highlight box 3
				this.settingHighlightStyle3 = new GUIStyle(this.settingHighlightStyle);
				this.settingHighlightStyle3.normal.background = EditorContent.LoadImage(
					assembly.GetManifestResourceStream("GamingIsLove.Makinom.Editor.Images.GUIStyles.SettingsHighlightBox3.png"),
					20, 10);
				this.settingHighlightStyle3.hover.background = EditorContent.LoadImage(
					assembly.GetManifestResourceStream("GamingIsLove.Makinom.Editor.Images.GUIStyles.SettingsHighlightedBox3.png"),
					20, 10);

				// settings highlight box 4
				this.settingHighlightStyle4 = new GUIStyle(this.settingHighlightStyle);
				this.settingHighlightStyle4.normal.background = EditorContent.LoadImage(
					assembly.GetManifestResourceStream("GamingIsLove.Makinom.Editor.Images.GUIStyles.SettingsHighlightBox4.png"),
					20, 10);
				this.settingHighlightStyle4.hover.background = EditorContent.LoadImage(
					assembly.GetManifestResourceStream("GamingIsLove.Makinom.Editor.Images.GUIStyles.SettingsHighlightedBox4.png"),
					20, 10);

				// settings highlight box 5
				this.settingHighlightStyle5 = new GUIStyle(this.settingHighlightStyle);
				this.settingHighlightStyle5.normal.background = EditorContent.LoadImage(
					assembly.GetManifestResourceStream("GamingIsLove.Makinom.Editor.Images.GUIStyles.SettingsHighlightBox5.png"),
					20, 10);
				this.settingHighlightStyle5.hover.background = EditorContent.LoadImage(
					assembly.GetManifestResourceStream("GamingIsLove.Makinom.Editor.Images.GUIStyles.SettingsHighlightedBox5.png"),
					20, 10);


				// jump list highlight
				this.jumpListHighlightStyle = new GUIStyle();
				this.jumpListHighlightStyle.border = new RectOffset(3, 1, 0, 0);
				this.jumpListHighlightStyle.overflow = new RectOffset(0, 0, 0, 0);
				this.jumpListHighlightStyle.padding = new RectOffset(3, 0, 0, 0);
				this.jumpListHighlightStyle.normal.background = EditorContent.LoadImage(
					assembly.GetManifestResourceStream("GamingIsLove.Makinom.Editor.Images.GUIStyles.SettingsHighlightedBox.png"),
					20, 10);

				// custom popup
				this.popupTextFieldStyle = new GUIStyle(EditorStyles.textField);
				this.popupTextFieldStyle.margin = new RectOffset(0, 0, 0, 0);

				this.popupListStyle = new GUIStyle(EditorStyles.label);
				this.popupListStyle.richText = true;
				this.popupListStyle.padding = new RectOffset(10, 5, 5, 5);
				this.popupListStyle.margin = new RectOffset(0, 0, 0, 0);
				this.popupListStyle.normal.background = EditorContent.LoadImage(
					assembly.GetManifestResourceStream(EditorGUIUtility.isProSkin ?
						"GamingIsLove.Makinom.Editor.Images.GUIStyles.PopupListBackground_Dark.png" :
						"GamingIsLove.Makinom.Editor.Images.GUIStyles.PopupListBackground.png"),
					8, 8);
				this.popupListStyle.focused.background = this.popupListStyle.normal.background;
				this.popupListStyle.hover.background = this.popupListStyle.normal.background;

				this.selectedPopupListStyle = new GUIStyle(this.popupListStyle);
				this.selectedPopupListStyle.normal.textColor = Color.white;
				this.selectedPopupListStyle.normal.background = EditorContent.LoadImage(
					assembly.GetManifestResourceStream(EditorGUIUtility.isProSkin ?
						"GamingIsLove.Makinom.Editor.Images.GUIStyles.SelectedPopupListBackground_Dark.png" :
						"GamingIsLove.Makinom.Editor.Images.GUIStyles.SelectedPopupListBackground.png"),
					8, 8);
				this.selectedPopupListStyle.active.background = this.selectedPopupListStyle.normal.background;
				this.selectedPopupListStyle.active.textColor = this.selectedPopupListStyle.normal.textColor;
				this.selectedPopupListStyle.hover.background = this.selectedPopupListStyle.normal.background;
				this.selectedPopupListStyle.hover.textColor = this.selectedPopupListStyle.normal.textColor;
				this.selectedPopupListStyle.focused.background = this.selectedPopupListStyle.normal.background;
				this.selectedPopupListStyle.focused.textColor = this.selectedPopupListStyle.normal.textColor;

				this.popupListStyle.active.background = this.selectedPopupListStyle.normal.background;
				this.popupListStyle.active.textColor = this.selectedPopupListStyle.normal.textColor;

				this.hoverPopupListStyle = new GUIStyle(this.popupListStyle);
				this.hoverPopupListStyle.normal.background = EditorContent.LoadImage(
					 assembly.GetManifestResourceStream(EditorGUIUtility.isProSkin ?
						"GamingIsLove.Makinom.Editor.Images.GUIStyles.HoverPopupListBackground_Dark.png" :
						"GamingIsLove.Makinom.Editor.Images.GUIStyles.HoverPopupListBackground.png"),
					 8, 8);
				this.hoverPopupListStyle.focused.background = this.hoverPopupListStyle.normal.background;
				this.hoverPopupListStyle.hover.background = this.hoverPopupListStyle.normal.background;

				this.popupListHeaderStyle = new GUIStyle(EditorStyles.label);
				this.popupListHeaderStyle.fontStyle = FontStyle.Bold;
				this.popupListHeaderStyle.alignment = TextAnchor.MiddleCenter;
				this.popupListHeaderStyle.richText = true;
				this.popupListHeaderStyle.padding = new RectOffset(5, 5, 5, 5);
				this.popupListHeaderStyle.margin = new RectOffset(0, 0, 0, 0);
				if(EditorGUIUtility.isProSkin)
				{
					this.popupListHeaderStyle.normal.background = EditorContent.LoadImage(
						 assembly.GetManifestResourceStream("GamingIsLove.Makinom.Editor.Images.GUIStyles.HeaderPopupListBackground_Dark.png"),
						 8, 8);
				}

				this.popupListTypeStyle = new GUIStyle(this.popupListStyle);
				this.popupListTypeStyle.padding.left = 23;
				this.selectedPopupListTypeStyle = new GUIStyle(this.selectedPopupListStyle);
				this.selectedPopupListTypeStyle.padding.left = 23;
				this.hoverPopupListTypeStyle = new GUIStyle(this.hoverPopupListStyle);
				this.hoverPopupListTypeStyle.padding.left = 23;


				// button
				this.buttonStyle = new GUIStyle(GUI.skin.button);
				this.buttonStyle.alignment = TextAnchor.MiddleCenter;
				if(!EditorGUIUtility.isProSkin)
				{
					this.buttonStyle.onNormal.textColor = highlightTextColor;
					this.buttonStyle.onActive.textColor = highlightTextColor;
					this.buttonStyle.onHover.textColor = highlightTextColor;
					this.buttonStyle.onFocused.textColor = highlightTextColor;
				}

				this.buttonRichTextStyle = new GUIStyle(this.buttonStyle);
				this.buttonRichTextStyle.richText = true;
				this.buttonRichTextStyle.padding.left = 0;
				this.buttonRichTextStyle.padding.right = 0;

				if(this.IsVersionOrLater(2019, 3))
				{
					this.labelWidth = GUILayout.Width(149);
				}
				else
				{
					this.labelWidth = GUILayout.Width(146);
				}


				// texts
				this.patrons = EditorContent.LoadTextToArray(assembly.GetManifestResourceStream("GamingIsLove.Makinom.Editor.Patrons.txt"));
			}
			catch
			{
				Debug.LogWarning("Error accessing icons!");
			}
		}


		/*
		============================================================================
		Tool functions
		============================================================================
		*/
		public static Texture2D LoadImage(System.Reflection.Assembly[] assembly, string name, int width, int height)
		{
			Texture2D texture = null;
			for(int i = 0; i < assembly.Length; i++)
			{
				try
				{
					Stream stream = assembly[i].GetManifestResourceStream(name);
					if(stream != null)
					{
						texture = EditorContent.LoadImage(stream, width, height);
						if(texture != null)
						{
							break;
						}
					}
				}
				catch
				{
					Debug.LogWarning("Error accessing icon!");
				}
			}
			return texture;
		}

		public static Texture2D LoadImage(string name, int width, int height)
		{
			Texture2D texture = null;
			try
			{
				texture = EditorContent.LoadImage(
					System.Reflection.Assembly.GetExecutingAssembly().GetManifestResourceStream(name),
					width, height);
			}
			catch
			{
				Debug.LogWarning("Error accessing icon!");
			}
			return texture;
		}

		public static Texture2D LoadImage(Stream stream, int width, int height)
		{
			Texture2D texture = null;
			try
			{
				byte[] bytes = new byte[stream.Length];
				stream.Read(bytes, 0, bytes.Length);
				stream.Close();
				stream.Dispose();
				texture = new Texture2D(width, height);
				texture.LoadImage(bytes);
				texture.hideFlags = HideFlags.HideAndDontSave;
			}
			catch
			{
				Debug.LogWarning("Error accessing icon!");
			}
			return texture;
		}

		public static string[] LoadTextToArray(Stream stream)
		{
			string[] text = null;
			try
			{
				List<string> list = new List<string>();
				StreamReader reader = new StreamReader(stream);
				while(!reader.EndOfStream)
				{
					list.Add(reader.ReadLine());
				}
				text = list.ToArray();

				reader.Close();
				reader.Dispose();
				stream.Close();
				stream.Dispose();
			}
			catch
			{
				Debug.LogWarning("Error accessing text!");
			}
			return text;
		}

		/// <summary>
		/// Returns the main version number, e.g. 5.6 > 5, 2017.4 > 2017, 2018.2 > 2018, etc.
		/// </summary>
		public int UnityMainVersion
		{
			get { return this.unityMainVersion; }
		}

		/// <summary>
		/// Returns the sub version number, e.g. 5.6 > 6, 2017.4 > 4, 2018.2 > 2, etc.
		/// </summary>
		public int UnitySubVersion
		{
			get { return this.unityMainVersion; }
		}

		/// <summary>
		/// 
		/// </summary>
		/// <param name="main">The main Unity version to check for (e.g. 5, 2017, etc.).</param>
		/// <param name="sub">The sub Unity version to check for, or -1 to not check sub version.</param>
		/// <returns></returns>
		public bool IsVersionOrLater(int main, int sub)
		{
			if(this.unityMainVersion > main)
			{
				return true;
			}
			else if(this.unityMainVersion == main)
			{
				return sub < 0 || this.unitySubVersion >= sub;
			}
			return false;
		}


		/*
		============================================================================
		GUI contents
		============================================================================
		*/
		public GUIContent SaveContent
		{
			get
			{
				if(this.saveContent.image == null)
				{
					this.saveContent.image = this.SaveIcon;
				}
				return this.saveContent;
			}
		}

		public GUIContent ReloadContent
		{
			get
			{
				if(this.reloadContent.image == null)
				{
					this.reloadContent.image = this.ReloadIcon;
				}
				return this.reloadContent;
			}
		}

		public GUIContent CancelContent
		{
			get
			{
				if(this.cancelContent.image == null)
				{
					this.cancelContent.image = this.CancelIcon;
				}
				return this.cancelContent;
			}
		}

		public GUIContent ConfirmContent
		{
			get
			{
				if(this.confirmContent.image == null)
				{
					this.confirmContent.image = this.SaveIcon;
				}
				return this.confirmContent;
			}
		}

		public GUIContent AddContent
		{
			get
			{
				if(this.addContent.image == null)
				{
					this.addContent.image = this.AddIcon;
				}
				return this.addContent;
			}
		}

		public GUIContent RemoveContent
		{
			get
			{
				if(this.removeContent.image == null)
				{
					this.removeContent.image = this.RemoveIcon;
				}
				return this.removeContent;
			}
		}

		public GUIContent CopyContent
		{
			get
			{
				if(this.copyContent.image == null)
				{
					this.copyContent.image = this.CopyIcon;
				}
				return this.copyContent;
			}
		}

		public GUIContent MoveUpContent
		{
			get
			{
				if(this.moveUpContent.image == null)
				{
					this.moveUpContent.image = this.MoveUpIcon;
				}
				return this.moveUpContent;
			}
		}

		public GUIContent MoveDownContent
		{
			get
			{
				if(this.moveDownContent.image == null)
				{
					this.moveDownContent.image = this.MoveDownIcon;
				}
				return this.moveDownContent;
			}
		}

		public GUIContent AllFoldouts
		{
			get
			{
				if(this.allFoldoutsContent.image == null)
				{
					this.allFoldoutsContent.image = this.MoveUpIcon;
				}
				return this.allFoldoutsContent;
			}
		}

		public GUIContent LimitFoldout
		{
			get
			{
				if(this.limitFoldoutContent.image == null)
				{
					this.limitFoldoutContent.image = this.MoveDownIcon;
				}
				return this.limitFoldoutContent;
			}
		}

		public GUIContent CopyToClipboardContent
		{
			get
			{
				if(this.copyToClipboardContent.image == null)
				{
					this.copyToClipboardContent.image = this.CopyToClipboardIcon;
				}
				return this.copyToClipboardContent;
			}
		}

		public GUIContent OpenLinkContent
		{
			get
			{
				if(this.openLinkContent.image == null)
				{
					this.openLinkContent.image = this.OpenLinkIcon;
				}
				return this.openLinkContent;
			}
		}

		public GUIContent SearchFilterSortContent
		{
			get { return this.searchFilterSortContent; }
		}


		/*
		============================================================================
		Icons
		============================================================================
		*/
		public Texture2D SaveIcon
		{
			get
			{
				if(this.saveIcon == null)
				{
					this.LoadResources();
				}
				return this.saveIcon;
			}
		}

		public Texture2D ReloadIcon
		{
			get
			{
				if(this.reloadIcon == null)
				{
					this.LoadResources();
				}
				return this.reloadIcon;
			}
		}

		public Texture2D DeleteIcon
		{
			get
			{
				if(this.deleteIcon == null)
				{
					this.LoadResources();
				}
				return this.deleteIcon;
			}
		}

		public Texture2D NavigateBackIcon
		{
			get
			{
				if(this.navigateBackIcon == null)
				{
					this.LoadResources();
				}
				return this.navigateBackIcon;
			}
		}

		public Texture2D NavigateForwardIcon
		{
			get
			{
				if(this.navigateForwardIcon == null)
				{
					this.LoadResources();
				}
				return this.navigateForwardIcon;
			}
		}

		public Texture2D CancelIcon
		{
			get
			{
				if(this.cancelIcon == null)
				{
					this.LoadResources();
				}
				return this.cancelIcon;
			}
		}


		public Texture2D AddIcon
		{
			get
			{
				if(this.addIcon == null)
				{
					this.LoadResources();
				}
				return this.addIcon;
			}
		}

		public Texture2D CopyIcon
		{
			get
			{
				if(this.copyIcon == null)
				{
					this.LoadResources();
				}
				return this.copyIcon;
			}
		}

		public Texture2D CopyToClipboardIcon
		{
			get
			{
				if(this.copyToClipboardIcon == null)
				{
					this.LoadResources();
				}
				return this.copyToClipboardIcon;
			}
		}

		public Texture2D PasteFromClipboardIcon
		{
			get
			{
				if(this.pasteFromClipboardIcon == null)
				{
					this.LoadResources();
				}
				return this.pasteFromClipboardIcon;
			}
		}

		public Texture2D PasteSettingsIcon
		{
			get
			{
				if(this.pasteSettingsIcon == null)
				{
					this.LoadResources();
				}
				return this.pasteSettingsIcon;
			}
		}

		public Texture2D SwapIcon
		{
			get
			{
				if(this.swapIcon == null)
				{
					this.LoadResources();
				}
				return this.swapIcon;
			}
		}

		public Texture2D RemoveIcon
		{
			get
			{
				if(this.removeIcon == null)
				{
					this.LoadResources();
				}
				return this.removeIcon;
			}
		}

		public Texture2D MoveUpIcon
		{
			get
			{
				if(this.moveUpIcon == null)
				{
					this.LoadResources();
				}
				return this.moveUpIcon;
			}
		}

		public Texture2D MoveDownIcon
		{
			get
			{
				if(this.moveDownIcon == null)
				{
					this.LoadResources();
				}
				return this.moveDownIcon;
			}
		}

		public Texture2D OpenLinkIcon
		{
			get
			{
				if(this.openLinkIcon == null)
				{
					this.LoadResources();
				}
				return this.openLinkIcon;
			}
		}

		public Texture2D EditBigIcon
		{
			get
			{
				if(this.editBigIcon == null)
				{
					this.LoadResources();
				}
				return this.editBigIcon;
			}
		}

		public Texture2D PlusIcon
		{
			get
			{
				if(this.plusIcon == null)
				{
					this.LoadResources();
				}
				return this.plusIcon;
			}
		}

		public Texture2D EditIcon
		{
			get
			{
				if(this.editIcon == null)
				{
					this.LoadResources();
				}
				return this.editIcon;
			}
		}

		public Texture2D ListIcon
		{
			get
			{
				if(this.listIcon == null)
				{
					this.LoadResources();
				}
				return this.listIcon;
			}
		}

		public Texture2D FoldoutButtonsIcon
		{
			get
			{
				if(this.foldoutButtonsIcon == null)
				{
					this.LoadResources();
				}
				return this.foldoutButtonsIcon;
			}
		}

		public Texture2D OpenFoldoutsIcon
		{
			get
			{
				if(this.openFoldoutsIcon == null)
				{
					this.LoadResources();
				}
				return this.openFoldoutsIcon;
			}
		}

		public Texture2D CloseFoldoutsIcon
		{
			get
			{
				if(this.closeFoldoutsIcon == null)
				{
					this.LoadResources();
				}
				return this.closeFoldoutsIcon;
			}
		}

		public Texture2D SmallRemoveIcon
		{
			get
			{
				if(this.smallRemoveIcon == null)
				{
					this.LoadResources();
				}
				return this.smallRemoveIcon;
			}
		}

		public Texture2D SearchPreviousIcon
		{
			get
			{
				if(this.searchPreviousIcon == null)
				{
					this.LoadResources();
				}
				return this.searchPreviousIcon;
			}
		}

		public Texture2D SearchNextIcon
		{
			get
			{
				if(this.searchNextIcon == null)
				{
					this.LoadResources();
				}
				return this.searchNextIcon;
			}
		}


		/*
		============================================================================
		GUI styles
		============================================================================
		*/
		public GUIStyle EmptyStyle
		{
			get
			{
				if(this.emptyStyle == null)
				{
					this.LoadResources();
				}
				return this.emptyStyle;
			}
		}

		public GUIStyle FoldoutStyle
		{
			get
			{
				if(this.foldoutStyle == null)
				{
					this.LoadResources();
				}
				return this.foldoutStyle;
			}
		}

		public GUIStyle FoldoutPrettyStyle
		{
			get
			{
				if(this.foldoutPrettyStyle == null)
				{
					this.LoadResources();
				}
				return this.foldoutPrettyStyle;
			}
		}

		public GUIStyle FoldoutInspectorStyle
		{
			get
			{
				if(this.foldoutInspectorStyle == null)
				{
					this.LoadResources();
				}
				return this.foldoutInspectorStyle;
			}
		}

		public GUIStyle TextAreaStyle
		{
			get
			{
				if(this.textAreaStyle == null)
				{
					this.LoadResources();
				}
				return this.textAreaStyle;
			}
		}

		public GUIStyle SelectionGridStyle
		{
			get
			{
				if(this.selectionGridStyle == null)
				{
					this.LoadResources();
				}
				return this.selectionGridStyle;
			}
		}

		public GUIStyle SelectionGridSelectedStyle
		{
			get
			{
				if(this.selectionGridSelectedStyle == null)
				{
					this.LoadResources();
				}
				return this.selectionGridSelectedStyle;
			}
		}

		public GUIStyle SelectionGridCenterStyle
		{
			get
			{
				if(this.selectionGridCenterStyle == null)
				{
					this.LoadResources();
				}
				return this.selectionGridCenterStyle;
			}
		}

		public GUIStyle BoxSlimStyle
		{
			get
			{
				if(this.boxSlimStyle == null)
				{
					this.LoadResources();
				}
				return this.boxSlimStyle;
			}
		}

		public GUIStyle BoxStyle
		{
			get
			{
				if(this.boxStyle == null)
				{
					this.LoadResources();
				}
				return this.boxStyle;
			}
		}

		public GUIStyle BoxFoldoutPrettyStyle
		{
			get
			{
				if(this.boxFoldoutPrettyStyle == null)
				{
					this.LoadResources();
				}
				return this.boxFoldoutPrettyStyle;
			}
		}

		public GUIStyle BoxFoldoutInspectorStyle
		{
			get
			{
				if(this.boxFoldoutInspectorStyle == null)
				{
					this.LoadResources();
				}
				return this.boxFoldoutInspectorStyle;
			}
		}

		public GUIStyle BoxTextAreaStyle
		{
			get
			{
				if(this.boxTextAreaStyle == null)
				{
					this.LoadResources();
				}
				return this.boxTextAreaStyle;
			}
		}

		public GUIStyle BoxSearchFilterStyle
		{
			get
			{
				if(this.boxSearchFilterStyle == null)
				{
					this.LoadResources();
				}
				return this.boxSearchFilterStyle;
			}
		}

		public GUIStyle SearchBoxStyle
		{
			get
			{
				if(this.searchBoxStyle == null)
				{
					this.LoadResources();
				}
				return this.searchBoxStyle;
			}
		}

		public GUIStyle SearchFoundLabelStyle
		{
			get
			{
				if(this.searchFoundLabelStyle == null)
				{
					this.LoadResources();
				}
				return this.searchFoundLabelStyle;
			}
		}

		public GUIStyle NodeBoxStyle
		{
			get
			{
				if(this.nodeBoxStyle == null)
				{
					this.LoadResources();
				}
				return this.nodeBoxStyle;
			}
		}

		public GUIStyle InspectorBoxStyle
		{
			get
			{
				if(this.inspectorBoxStyle == null)
				{
					this.LoadResources();
				}
				return this.inspectorBoxStyle;
			}
		}

		public GUIStyle SettingHighlightStyle
		{
			get
			{
				if(this.settingHighlightStyle == null)
				{
					this.LoadResources();
				}
				return this.settingHighlightStyle;
			}
		}

		public GUIStyle SettingHighlightStyle1
		{
			get
			{
				if(this.settingHighlightStyle1 == null)
				{
					this.LoadResources();
				}
				return this.settingHighlightStyle1;
			}
		}

		public GUIStyle SettingHighlightStyle2
		{
			get
			{
				if(this.settingHighlightStyle2 == null)
				{
					this.LoadResources();
				}
				return this.settingHighlightStyle2;
			}
		}

		public GUIStyle SettingHighlightStyle3
		{
			get
			{
				if(this.settingHighlightStyle3 == null)
				{
					this.LoadResources();
				}
				return this.settingHighlightStyle3;
			}
		}

		public GUIStyle SettingHighlightStyle4
		{
			get
			{
				if(this.settingHighlightStyle4 == null)
				{
					this.LoadResources();
				}
				return this.settingHighlightStyle4;
			}
		}

		public GUIStyle SettingHighlightStyle5
		{
			get
			{
				if(this.settingHighlightStyle5 == null)
				{
					this.LoadResources();
				}
				return this.settingHighlightStyle5;
			}
		}

		public GUIStyle PopupTextFieldStyle
		{
			get
			{
				if(this.popupTextFieldStyle == null)
				{
					this.LoadResources();
				}
				return this.popupTextFieldStyle;
			}
		}

		public GUIStyle PopupListHeaderStyle
		{
			get
			{
				if(this.popupListHeaderStyle == null)
				{
					this.LoadResources();
				}
				return this.popupListHeaderStyle;
			}
		}

		public GUIStyle PopupListStyle
		{
			get
			{
				if(this.popupListStyle == null)
				{
					this.LoadResources();
				}
				return this.popupListStyle;
			}
		}

		public GUIStyle HoverPopupListStyle
		{
			get
			{
				if(this.hoverPopupListStyle == null)
				{
					this.LoadResources();
				}
				return this.hoverPopupListStyle;
			}
		}

		public GUIStyle SelectedPopupListStyle
		{
			get
			{
				if(this.selectedPopupListStyle == null)
				{
					this.LoadResources();
				}
				return this.selectedPopupListStyle;
			}
		}

		public GUIStyle PopupListTypeStyle
		{
			get
			{
				if(this.popupListTypeStyle == null)
				{
					this.LoadResources();
				}
				return this.popupListTypeStyle;
			}
		}

		public GUIStyle HoverPopupListTypeStyle
		{
			get
			{
				if(this.hoverPopupListTypeStyle == null)
				{
					this.LoadResources();
				}
				return this.hoverPopupListTypeStyle;
			}
		}

		public GUIStyle SelectedPopupListTypeStyle
		{
			get
			{
				if(this.selectedPopupListTypeStyle == null)
				{
					this.LoadResources();
				}
				return this.selectedPopupListTypeStyle;
			}
		}

		public GUIStyle JumpListHighlightStyle
		{
			get
			{
				if(this.jumpListHighlightStyle == null)
				{
					this.LoadResources();
				}
				return this.jumpListHighlightStyle;
			}
		}

		public GUIStyle ButtonStyle
		{
			get
			{
				if(this.buttonStyle == null)
				{
					this.LoadResources();
				}
				return this.buttonStyle;
			}
		}

		public GUIStyle ButtonRichTextStyle
		{
			get
			{
				if(this.buttonRichTextStyle == null)
				{
					this.LoadResources();
				}
				return this.buttonRichTextStyle;
			}
		}


		/*
		============================================================================
		Arrow functions
		============================================================================
		*/
		public void DrawLeftArrow()
		{
			if(Event.current.type == EventType.Repaint)
			{
				Rect rect = GUILayoutUtility.GetLastRect();
				rect.x += 6;
				rect.y += (rect.height / 2) - 7;
				rect.width = 13;
				rect.height = 13;
				this.leftArrowStyle.Draw(rect, false, false, false, false);
			}
		}

		public void DrawRightArrow(bool leftSide)
		{
			if(Event.current.type == EventType.Repaint)
			{
				Rect rect = GUILayoutUtility.GetLastRect();
				if(leftSide)
				{
					rect.x += 10;
				}
				else
				{
					rect.x = rect.width - 13;
				}
				rect.y += (rect.height / 2) - 7;
				rect.width = 13;
				rect.height = 13;
				this.rightArrowStyle.Draw(rect, false, false, false, false);
			}
		}


		/*
		============================================================================
		Help text contents
		============================================================================
		*/
		public void SetEditorHelp(string helpHeader, string helpText, string helpInfo)
		{
			this.helpHeader = helpHeader;
			this.helpText = helpText;
			this.helpInfo = helpInfo;
		}

		public string HelpHeader
		{
			get { return this.helpHeader; }
		}

		public string HelpText
		{
			get { return this.helpText; }
		}

		public string HelpInfo
		{
			get { return this.helpInfo; }
		}


		/*
		============================================================================
		Keys
		============================================================================
		*/
		private static bool IsCTRL
		{
			get { return Event.current.type == EventType.KeyDown && Event.current.control; }
		}

		public static bool CTRL_C
		{
			get { return IsCTRL && Event.current.keyCode == KeyCode.C; }
		}

		public static bool CTRL_X
		{
			get { return IsCTRL && Event.current.keyCode == KeyCode.X; }
		}

		public static bool CTRL_V
		{
			get { return IsCTRL && Event.current.keyCode == KeyCode.V; }
		}

		public static bool CTRL_A
		{
			get { return IsCTRL && Event.current.keyCode == KeyCode.Y; }
		}

		public static bool CTRL_I
		{
			get { return IsCTRL && Event.current.keyCode == KeyCode.I; }
		}

		public static bool CTRL_B
		{
			get { return IsCTRL && Event.current.keyCode == KeyCode.B; }
		}

		public static bool CTRL_F
		{
			get { return IsCTRL && Event.current.keyCode == KeyCode.F; }
		}

		public static bool CTRL_D
		{
			get { return IsCTRL && Event.current.keyCode == KeyCode.D; }
		}


		/*
		============================================================================
		Texts
		============================================================================
		*/
		public string[] Patrons
		{
			get
			{
				if(this.patrons == null)
				{
					this.LoadResources();
				}
				return this.patrons;
			}
		}


		/*
		============================================================================
		Node clipboards
		============================================================================
		*/
		public List<EditorClipboard> SchematicClipboard
		{
			get { return this.schematicClipboard; }
		}

		public List<EditorClipboard> FormulaClipboard
		{
			get { return this.formulaClipboard; }
		}


		/*
		============================================================================
		Foldout state functions
		============================================================================
		*/
		public void TryGetFoldoutState(string key, ref bool value)
		{
			bool tmp = true;
			if(this.foldoutState.TryGetValue(key, out tmp))
			{
				value = tmp;
			}
		}

		public void SetFoldoutState(string key, bool value)
		{
			if(this.foldoutState.ContainsKey(key))
			{
				this.foldoutState[key] = value;
			}
			else
			{
				this.foldoutState.Add(key, value);
			}
		}

		public void StoreFoldoutStates(MakinomEditorAsset editorAsset)
		{
			if(editorAsset != null)
			{
				List<string> key = new List<string>();
				List<bool> state = new List<bool>();
				foreach(KeyValuePair<string, bool> pair in this.foldoutState)
				{
					key.Add(pair.Key);
					state.Add(pair.Value);
				}
				editorAsset.FoldoutKey = key;
				editorAsset.FoldoutState = state;
			}
		}

		public void LoadFoldoutStates(MakinomEditorAsset editorAsset)
		{
			this.foldoutState.Clear();

			if(editorAsset != null &&
				editorAsset.FoldoutKey != null &&
				editorAsset.FoldoutState != null)
			{
				for(int i = 0; i < editorAsset.FoldoutKey.Count; i++)
				{
					this.foldoutState.Add(editorAsset.FoldoutKey[i], editorAsset.FoldoutState[i]);
				}
			}
		}


		/*
		============================================================================
		Editor asset access
		============================================================================
		*/
		public static MakinomEditorAsset EditorAsset
		{
			get
			{
				if(EditorContent.instance.editorAsset == null)
				{
					EditorContent.instance.editorAsset = MakinomAssetHelper.LoadEditorAsset(true);
				}
				EditorUtility.SetDirty(EditorContent.instance.editorAsset);
				return EditorContent.instance.editorAsset;
			}
		}

	}
}
