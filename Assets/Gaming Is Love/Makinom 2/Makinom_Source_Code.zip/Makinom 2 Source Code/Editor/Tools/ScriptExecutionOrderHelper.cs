
using UnityEngine;
using UnityEditor;
using GamingIsLove.Makinom;
using GamingIsLove.Makinom.Components;

[InitializeOnLoad]
public class MakinomScriptExecutionOrderHelper : Editor
{
	static MakinomScriptExecutionOrderHelper()
	{
		string gameStarter = typeof(GameStarter).Name;
		string makinomHandler = typeof(MakinomHandler).Name;
		string lateFixedTick = typeof(MakinomLateFixedTick).Name;
		string collisionCamera = typeof(CollisionCamera).Name;

		MonoScript[] script = MonoImporter.GetAllRuntimeMonoScripts();

		int count = 0;
		for(int i = 0; i < script.Length; i++)
		{
			if(count >= 4)
			{
				return;
			}
			if(script[i].name == gameStarter)
			{
				if(MonoImporter.GetExecutionOrder(script[i]) == 0)
				{
					MonoImporter.SetExecutionOrder(script[i], -1000);
				}
				count++;
			}
			else if(script[i].name == makinomHandler)
			{
				if(MonoImporter.GetExecutionOrder(script[i]) == 0)
				{
					MonoImporter.SetExecutionOrder(script[i], -100);
				}
				count++;
			}
			else if(script[i].name == lateFixedTick)
			{
				if(MonoImporter.GetExecutionOrder(script[i]) == 0)
				{
					MonoImporter.SetExecutionOrder(script[i], 1000);
				}
				count++;
			}
			else if(script[i].name == collisionCamera)
			{
				if(MonoImporter.GetExecutionOrder(script[i]) == 0)
				{
					MonoImporter.SetExecutionOrder(script[i], 1100);
				}
				count++;
			}
		}
	}
}
