﻿
using UnityEngine;
using GamingIsLove.Makinom;
using System.Collections.Generic;

namespace GamingIsLove.Makinom.Components
{
	public interface IMoveSpeed
	{
		float GetMoveSpeed(MoveSpeedType moveType);
	}

	[AddComponentMenu("Makinom/Controls/Move Speed")]
	public class MoveSpeedComponent : SerializedBehaviour<MoveSpeedComponent.Settings>, IMoveSpeed
	{
		public virtual float GetMoveSpeed(MoveSpeedType moveType)
		{
			if(MoveSpeedType.Walk == moveType)
			{
				return this.settings.walkSpeed.GetValue(
					this.settings.walkSpeed.NeedsCall ? new DataCall(this.gameObject) : null);
			}
			else if(MoveSpeedType.Run == moveType)
			{
				return this.settings.runSpeed.GetValue(
					this.settings.runSpeed.NeedsCall ? new DataCall(this.gameObject) : null);
			}
			else if(MoveSpeedType.Sprint == moveType)
			{
				return this.settings.sprintSpeed.GetValue(
					this.settings.sprintSpeed.NeedsCall ? new DataCall(this.gameObject) : null);
			}
			return 0;
		}

		/*
		============================================================================
		Settings class
		============================================================================
		*/
		public class Settings : BaseData
		{
			[EditorHelp("Walk Speed Settings", "The walk speed in world units per second.")]
			public FloatValue<GameObjectSelection> walkSpeed = new FloatValue<GameObjectSelection>(3);

			[EditorHelp("Run Speed", "The run speed in world units per second.")]
			public FloatValue<GameObjectSelection> runSpeed = new FloatValue<GameObjectSelection>(6);

			[EditorHelp("Sprint Speed", "The sprint speed in world units per second.")]
			public FloatValue<GameObjectSelection> sprintSpeed = new FloatValue<GameObjectSelection>(9);

			public Settings()
			{

			}
		}
	}
}
