﻿
using UnityEngine;
using System.Collections.Generic;
using System.Collections;
using GamingIsLove.Makinom.UI;

namespace GamingIsLove.Makinom.Components
{
	[AddComponentMenu("")]
	public class InteractionForwarder : BaseInteractionComponent
	{
		public BaseInteractionComponent interaction;

		public override float MoveDestinationOffset
		{
			get { return this.interaction.MoveDestinationOffset; }
		}

		public override MoveToInteractionComponentSettings MoveToInteractionSettings
		{
			get { return this.interaction.MoveToInteractionSettings; }
		}


		/*
		============================================================================
		Register functions
		============================================================================
		*/
		public override void Register()
		{
			if(this.interaction != null)
			{
				base.Register();
			}
		}


		/*
		============================================================================
		Auto start functions
		============================================================================
		*/
		protected override void Start()
		{
			this.Register();
		}

		protected override void OnEnable()
		{
			this.Register();
		}

		protected override void OnDisable()
		{
			this.Unregister();
		}

		protected override void OnDestroy()
		{

		}

		public override void OnAutoSceneLoaded()
		{

		}

		protected override bool AutoStartCheck()
		{
			return false;
		}

		protected override void CheckAutoStart()
		{

		}

		protected override IEnumerator CheckAutoStart2()
		{
			return null;
		}

		protected override void EndCheck()
		{

		}


		/*
		============================================================================
		Interaction functions
		============================================================================
		*/
		public override MachineTypeAsset MachineType
		{
			get { return this.interaction.MachineType; }
		}

		public override bool IsInteract
		{
			get { return this.interaction.IsInteract; }
		}

		public override bool CanInteract(GameObject startingObject)
		{
			return this.interaction.CanInteract(startingObject);
		}

		public override bool Interact(GameObject startingObject)
		{
			return this.interaction.Interact(startingObject);
		}

		protected override void Update()
		{

		}

		public override bool DropInteract(DragInfo drag)
		{
			return this.interaction.DropInteract(drag);
		}

		public override void StartInteraction(GameObject startingObject)
		{
			this.DoTurns(startingObject);
			this.interaction.StartInteraction(startingObject);
		}

		public override void DoTurns(GameObject startingObject)
		{
			if(startingObject != null &&
				this.interaction != null)
			{
				if(this.interaction.startSettings.turnStartingObject)
				{
					startingObject.transform.LookAt(new Vector3(
						this.transform.position.x,
						startingObject.transform.position.y,
						this.transform.position.z));
				}
				if(this.interaction.startSettings.turnMachineObject)
				{
					this.transform.LookAt(new Vector3(
						startingObject.transform.position.x,
						this.transform.position.y,
						startingObject.transform.position.z));
				}
			}
		}


		/*
		============================================================================
		Mouse functions
		============================================================================
		*/
		public override void OnMouseDown()
		{
			this.interaction.OnMouseDown();
		}

		public override void OnMouseDrag()
		{
			this.interaction.OnMouseDrag();
		}

		public override void OnMouseUp()
		{
			this.interaction.OnMouseUp();
		}

		public override void OnMouseUpAsButton()
		{
			this.interaction.OnMouseUpAsButton();
		}

		public override void OnMouseEnter()
		{
			this.interaction.OnMouseEnter();
		}

		public override void OnMouseOver()
		{
			this.interaction.OnMouseOver();
		}

		public override void OnMouseExit()
		{
			this.interaction.OnMouseExit();
		}


		/*
		============================================================================
		Trigger functions
		============================================================================
		*/
		public override void OnTriggerEnter(Collider other)
		{
			this.interaction.OnTriggerEnter(other);
		}

		public override void OnTriggerStay(Collider other)
		{
			this.interaction.OnTriggerStay(other);
		}

		public override void OnTriggerExit(Collider other)
		{
			this.interaction.OnTriggerExit(other);
		}


		/*
		============================================================================
		Trigger2D functions
		============================================================================
		*/
		public override void OnTriggerEnter2D(Collider2D other)
		{
			this.interaction.OnTriggerEnter2D(other);
		}

		public override void OnTriggerStay2D(Collider2D other)
		{
			this.interaction.OnTriggerStay2D(other);
		}

		public override void OnTriggerExit2D(Collider2D other)
		{
			this.interaction.OnTriggerExit2D(other);
		}


		/*
		============================================================================
		Collision functions
		============================================================================
		*/
		public override void OnCollisionEnter(Collision collision)
		{
			this.interaction.OnCollisionEnter(collision);
		}

		public override void OnCollisionStay(Collision collision)
		{
			this.interaction.OnCollisionStay(collision);
		}

		public override void OnCollisionExit(Collision collision)
		{
			this.interaction.OnCollisionExit(collision);
		}

		public override void OnParticleCollision(GameObject other)
		{
			this.interaction.OnParticleCollision(other);
		}

		public override void OnControllerColliderHit(ControllerColliderHit hit)
		{
			this.interaction.OnControllerColliderHit(hit);
		}


		/*
		============================================================================
		Collision2D functions
		============================================================================
		*/
		public override void OnCollisionEnter2D(Collision2D collision)
		{
			this.interaction.OnCollisionEnter2D(collision);
		}

		public override void OnCollisionStay2D(Collision2D collision)
		{
			this.interaction.OnCollisionStay2D(collision);
		}

		public override void OnCollisionExit2D(Collision2D collision)
		{
			this.interaction.OnCollisionExit2D(collision);
		}
	}
}
