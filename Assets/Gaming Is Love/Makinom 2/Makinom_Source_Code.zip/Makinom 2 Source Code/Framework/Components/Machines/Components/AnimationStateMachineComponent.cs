
using UnityEngine;
using GamingIsLove.Makinom.Schematics;
using System.Collections;

namespace GamingIsLove.Makinom.Components
{
	[AddComponentMenu("Makinom/Machines/Animation State Machine")]
	public class AnimationStateMachineComponent : StateMachineBehaviour, ISchematicStarter, ISerializationCallbackReceiver
	{
		[SerializeField]
		[HideInInspector]
		protected ComponentDataFile serialize_settings;

		[System.NonSerialized]
		public AnimationStateMachineStartSetting startSetting = new AnimationStateMachineStartSetting();

		[System.NonSerialized]
		public AnimationStateMachineAssetSetting assetSetting = new AnimationStateMachineAssetSetting();

		[System.NonSerialized]
		public MachineStartVariableSetting startVariableSetting = new MachineStartVariableSetting();

		[System.NonSerialized]
		public MachineChangeAfterSetting changeAfterSetting = new MachineChangeAfterSetting();

		[System.NonSerialized]
		public AnimationStateMachineConditionSetting conditionSetting = new AnimationStateMachineConditionSetting();


		// resources
		public MachineResourcesSetting resources = new MachineResourcesSetting();


		// ingame
		protected GameObject gameObject;

		protected Schematic schematic;

		protected bool machineStarted = false;

		public virtual bool CanRestart(GameObject startingObject)
		{
			return this.CheckVariables(startingObject);
		}


		/*
		============================================================================
		Schematic asset functions
		============================================================================
		*/
		protected virtual void OnEnable()
		{
			this.LoadSchematic();
		}

		public virtual bool SchematicFound
		{
			get
			{
				if(this.schematic == null)
				{
					this.LoadSchematic();
				}
				return this.schematic != null;
			}
		}

		public virtual Schematic RuntimeSchematic
		{
			get { return this.schematic; }
		}

		public virtual void LoadSchematic()
		{
			if(this.schematic == null &&
				this.assetSetting.schematicAsset != null)
			{
				this.schematic = new Schematic(this.assetSetting.schematicAsset);

				if(this.assetSetting.autoStop)
				{
					this.schematic.AutoStopCheckTime = this.assetSetting.autoStopCheckTime;
				}
			}
		}

		public virtual void LoadSchematicEditor()
		{
			if(Application.isEditor &&
				!Application.isPlaying &&
				this.assetSetting.schematicAsset != null)
			{
				this.startVariableSetting.CheckStartVariables(this.assetSetting.schematicAsset.Settings);
				this.resources.CheckSchematic(this.assetSetting.schematicAsset.Settings);
			}
		}


		/*
		============================================================================
		Getters functions
		============================================================================
		*/
		public virtual MachineTypeAsset MachineType
		{
			get { return this.assetSetting.machineType; }
		}


		/*
		============================================================================
		Variable functions
		============================================================================
		*/
		public virtual bool CheckVariables(GameObject machineObject)
		{
			if(this.conditionSetting.checkVariables &&
				this.conditionSetting.variableCondition.Has)
			{
				return this.conditionSetting.variableCondition.CheckVariables(
					new DataCall(machineObject, machineObject,
						this.assetSetting.inputID.GetInputID(machineObject, machineObject)));
			}
			return true;
		}


		/*
		============================================================================
		State machine functions
		============================================================================
		*/
		public override void OnStateMachineEnter(Animator animator, int stateMachinePathHash)
		{
			if(this.startSetting.isStateMachineEnter)
			{
				DataCall call = this.startVariableSetting.NeedsCall ||
						(this.startSetting.checkPathHash && this.startSetting.pathHashCheck.NeedsCall) ?
					new DataCall(animator.gameObject, Maki.Game.Player.GameObject,
						this.assetSetting.inputID.GetInputID(animator.gameObject, Maki.Game.Player.GameObject)) : null;
				if(this.startSetting.CanStart(this, Maki.Game.Player.GameObject) &&
					this.startSetting.CheckPathHash(call, stateMachinePathHash))
				{
					VariableHandler handler = this.startVariableSetting.GetStartVariables(call);
					if(handler == null)
					{
						handler = new VariableHandler();
					}
					handler.Set("stateMachinePathHash", stateMachinePathHash);
					this.StartMachine(animator.gameObject, handler);
				}
			}
		}

		public override void OnStateMachineExit(Animator animator, int stateMachinePathHash)
		{
			if(this.startSetting.isStateMachineExit)
			{
				DataCall call = this.startVariableSetting.NeedsCall ||
						(this.startSetting.checkPathHash && this.startSetting.pathHashCheck.NeedsCall) ?
					new DataCall(animator.gameObject, Maki.Game.Player.GameObject,
						this.assetSetting.inputID.GetInputID(animator.gameObject, Maki.Game.Player.GameObject)) : null;
				if(this.startSetting.CanStart(this, Maki.Game.Player.GameObject) &&
					this.startSetting.CheckPathHash(call, stateMachinePathHash))
				{
					VariableHandler handler = this.startVariableSetting.GetStartVariables(call);
					if(handler == null)
					{
						handler = new VariableHandler();
					}
					handler.Set("stateMachinePathHash", stateMachinePathHash);
					this.StartMachine(animator.gameObject, handler);
				}
			}
		}


		/*
		============================================================================
		State functions
		============================================================================
		*/
		public override void OnStateEnter(Animator animator, AnimatorStateInfo stateInfo, int layerIndex)
		{
			if(this.startSetting.isStateEnter)
			{
				DataCall call = this.startVariableSetting.NeedsCall ||
						(this.startSetting.checkLayerIndex && this.startSetting.layerCheck.NeedsCall) ?
					new DataCall(animator.gameObject, Maki.Game.Player.GameObject,
						this.assetSetting.inputID.GetInputID(animator.gameObject, Maki.Game.Player.GameObject)) : null;
				if(this.startSetting.CanStart(this, Maki.Game.Player.GameObject) &&
					this.startSetting.CheckLayer(call, layerIndex))
				{
					this.StartMachine(animator.gameObject,
						VariableHelper.AddStateInfo(stateInfo, layerIndex,
							this.startVariableSetting.GetStartVariables(call)));
				}
			}
		}

		public override void OnStateExit(Animator animator, AnimatorStateInfo stateInfo, int layerIndex)
		{
			if(this.startSetting.isStateExit)
			{
				DataCall call = this.startVariableSetting.NeedsCall ||
						(this.startSetting.checkLayerIndex && this.startSetting.layerCheck.NeedsCall) ?
					new DataCall(animator.gameObject, Maki.Game.Player.GameObject,
						this.assetSetting.inputID.GetInputID(animator.gameObject, Maki.Game.Player.GameObject)) : null;
				if(this.startSetting.CanStart(this, Maki.Game.Player.GameObject) &&
					this.startSetting.CheckLayer(call, layerIndex))
				{
					this.StartMachine(animator.gameObject,
						VariableHelper.AddStateInfo(stateInfo, layerIndex,
							this.startVariableSetting.GetStartVariables(call)));
				}
			}
		}

		public override void OnStateIK(Animator animator, AnimatorStateInfo stateInfo, int layerIndex)
		{
			if(this.startSetting.isStateIK)
			{
				DataCall call = this.startVariableSetting.NeedsCall ||
						(this.startSetting.checkLayerIndex && this.startSetting.layerCheck.NeedsCall) ?
					new DataCall(animator.gameObject, Maki.Game.Player.GameObject,
						this.assetSetting.inputID.GetInputID(animator.gameObject, Maki.Game.Player.GameObject)) : null;
				if(this.startSetting.CanStart(this, Maki.Game.Player.GameObject) &&
					this.startSetting.CheckLayer(call, layerIndex))
				{
					this.StartMachine(animator.gameObject,
						VariableHelper.AddStateInfo(stateInfo, layerIndex,
							this.startVariableSetting.GetStartVariables(call)));
				}
			}
		}

		public override void OnStateMove(Animator animator, AnimatorStateInfo stateInfo, int layerIndex)
		{
			if(this.startSetting.isStateMove)
			{
				DataCall call = this.startVariableSetting.NeedsCall ||
						(this.startSetting.checkLayerIndex && this.startSetting.layerCheck.NeedsCall) ?
					new DataCall(animator.gameObject, Maki.Game.Player.GameObject,
						this.assetSetting.inputID.GetInputID(animator.gameObject, Maki.Game.Player.GameObject)) : null;
				if(this.startSetting.CanStart(this, Maki.Game.Player.GameObject) &&
					this.startSetting.CheckLayer(call, layerIndex))
				{
					this.StartMachine(animator.gameObject,
						VariableHelper.AddStateInfo(stateInfo, layerIndex,
							this.startVariableSetting.GetStartVariables(call)));
				}
			}
		}

		public override void OnStateUpdate(Animator animator, AnimatorStateInfo stateInfo, int layerIndex)
		{
			if(this.startSetting.isStateUpdate)
			{
				DataCall call = this.startVariableSetting.NeedsCall ||
						(this.startSetting.checkLayerIndex && this.startSetting.layerCheck.NeedsCall) ?
					new DataCall(animator.gameObject, Maki.Game.Player.GameObject,
						this.assetSetting.inputID.GetInputID(animator.gameObject, Maki.Game.Player.GameObject)) : null;
				if(this.startSetting.CanStart(this, Maki.Game.Player.GameObject) &&
					this.startSetting.CheckLayer(call, layerIndex))
				{
					this.StartMachine(animator.gameObject,
						VariableHelper.AddStateInfo(stateInfo, layerIndex,
							this.startVariableSetting.GetStartVariables(call)));
				}
			}
		}


		/*
		============================================================================
		Start machine functions
		============================================================================
		*/
		public virtual IEnumerator StartMachine(GameObject startingObject, VariableHandler startVariables, float delay)
		{
			yield return new WaitForSeconds(delay);
			this.StartMachine(startingObject, startVariables);
		}

		public virtual void StartMachine(GameObject startingObject, VariableHandler startVariables)
		{
			if(!this.machineStarted)
			{
				if(this.SchematicFound &&
					(Maki.Control.CanInteract ||
						MachineExecutionType.Blocking != this.assetSetting.executionType))
				{
					this.gameObject = startingObject;

					if(MachineExecutionType.Multi == this.assetSetting.executionType)
					{
						Schematic tmpSchematic = null;
						if(this.schematic.Executing)
						{
							tmpSchematic = new Schematic(this.assetSetting.schematicAsset);
						}
						else
						{
							this.schematic.Clear();
							tmpSchematic = this.schematic;
						}

						if(tmpSchematic != null)
						{
							if(startVariables != null)
							{
								tmpSchematic.Variables = startVariables;
							}
							tmpSchematic.InPause = this.assetSetting.inPause;
							this.StartMachine(tmpSchematic, startingObject);
						}
					}
					else
					{
						this.machineStarted = true;
						if(startVariables != null)
						{
							this.schematic.Variables = startVariables;
						}
						this.schematic.InPause = this.assetSetting.inPause;
						this.StartMachine(this.schematic, startingObject);
					}
				}
			}
		}

		protected virtual void StartMachine(Schematic tmpSchematic, GameObject startingObject)
		{
			if(this.assetSetting.startDelayTime > 0)
			{
				Maki.StartCoroutine(this.StartAfter(tmpSchematic, startingObject));
			}
			else
			{
				if(this.assetSetting.setPriority)
				{
					tmpSchematic.PlaySchematic(this.assetSetting.priority, this, this,
						startingObject, startingObject,
						MachineExecutionType.Blocking == this.assetSetting.executionType,
						this.assetSetting.updateType,
						this.assetSetting.inputID.GetInputID(this.gameObject, startingObject));
				}
				else
				{
					tmpSchematic.PlaySchematic(this, this,
						startingObject, startingObject,
						MachineExecutionType.Blocking == this.assetSetting.executionType,
						this.assetSetting.updateType,
						this.assetSetting.inputID.GetInputID(this.gameObject, startingObject));
				}
			}
		}

		protected virtual IEnumerator StartAfter(Schematic tmpSchematic, GameObject startingObject)
		{
			yield return new WaitForSeconds(this.assetSetting.startDelayTime);
			if(this.assetSetting.setPriority)
			{
				tmpSchematic.PlaySchematic(this.assetSetting.priority, this, this,
					startingObject, startingObject,
					MachineExecutionType.Blocking == this.assetSetting.executionType,
					this.assetSetting.updateType,
					this.assetSetting.inputID.GetInputID(this.gameObject, startingObject));
			}
			else
			{
				tmpSchematic.PlaySchematic(this, this,
					startingObject, startingObject,
					MachineExecutionType.Blocking == this.assetSetting.executionType,
					this.assetSetting.updateType,
					this.assetSetting.inputID.GetInputID(this.gameObject, startingObject));
			}
		}


		/*
		============================================================================
		End machine functions
		============================================================================
		*/
		public virtual void StopMachine()
		{
			if(this.machineStarted && this.schematic != null)
			{
				this.schematic.Stop();
			}
		}

		public virtual void SchematicFinished(Schematic schematic)
		{
			if(this.assetSetting.endDelayTime > 0)
			{
				Maki.StartCoroutine(this.EndAfter(schematic));
			}
			else
			{
				this.SchematicFinished2(schematic);
			}
		}

		protected virtual IEnumerator EndAfter(Schematic schematic)
		{
			yield return new WaitForSeconds(this.assetSetting.endDelayTime);
			this.SchematicFinished2(schematic);
		}

		protected virtual void SchematicFinished2(Schematic schematic)
		{
			if(this.changeAfterSetting.HasVariables)
			{
				GameObject startingObject = schematic != null && schematic.StartingObject != null ?
					schematic.StartingObject.GetFirst(schematic) : this.gameObject;
				this.changeAfterSetting.SetVariables(
					new DataCall(this.gameObject, startingObject,
						this.assetSetting.inputID.GetInputID(this.gameObject, startingObject)));
			}
			this.machineStarted = false;
		}


		/*
		============================================================================
		Serialization functions
		============================================================================
		*/
		public virtual void OnBeforeSerialize()
		{
			DataObject data = new DataObject();

			data.Set("startSetting", this.startSetting.GetData());
			data.Set("assetSetting", this.assetSetting.GetData());
			data.Set("changeAfterSetting", this.changeAfterSetting.GetData());
			data.Set("startVariableSetting", this.startVariableSetting.GetData());
			data.Set("conditionSetting", this.conditionSetting.GetData());

			this.serialize_settings = data.GetComponentDataFile("settings", false);
		}

		public virtual void OnAfterDeserialize()
		{
			if(this.serialize_settings != null)
			{
				DataObject data = this.serialize_settings.ToDataObject();

				this.startSetting.SetData(data.GetFile("startSetting"));
				this.assetSetting.SetData(data.GetFile("assetSetting"));
				this.changeAfterSetting.SetData(data.GetFile("changeAfterSetting"));
				this.startVariableSetting.SetData(data.GetFile("startVariableSetting"));
				this.conditionSetting.SetData(data.GetFile("conditionSetting"));

				this.serialize_settings = null;
			}
		}
	}
}
