
using UnityEngine;
using System.Collections.Generic;

namespace GamingIsLove.Makinom.Components
{
	[AddComponentMenu("")]
	public class RotatorComponent : MonoBehaviour
	{
		protected RotateComponentSettings.Instance componentSettings;

		protected GetFloat deltaTime;

		protected bool inPause = false;

		protected Interpolation.QuaternionInstance interpolation;

		protected Interpolation.FloatInstance interpolation2D;

		protected float time;

		protected float time2;

		protected Vector3 startRotation;

		protected Quaternion lastRotation;

		protected float lastAngle = 0;

		protected bool rotateToPosition = false;

		protected bool rotateToPosition2D = false;

		protected bool rotateDirection = false;

		protected bool rotateCurve = false;

		protected Vector3 direction = Vector3.zero;


		// curves
		protected AnimationCurve xCurve;

		protected AnimationCurve yCurve;

		protected AnimationCurve zCurve;


		// callback
		protected Notify[] notify;

		public virtual void StopMoving()
		{
			this.inPause = false;
			this.rotateToPosition = false;
			this.rotateToPosition2D = false;
			this.rotateDirection = false;
			this.interpolation = null;
			this.interpolation2D = null;

			this.rotateCurve = false;
			this.xCurve = null;
			this.yCurve = null;
			this.zCurve = null;
			this.deltaTime = null;

			this.notify = null;
		}


		/*
		============================================================================
		Rotate functions
		============================================================================
		*/
		public virtual void RotateToPosition(RotateComponentSettings.Instance componentSettings, Vector3 position,
			Vector3 worldUp, Interpolation interpolation, float time, GetFloat deltaTime, bool inPause, params Notify[] notify)
		{
			Notify[] tmpNotify = this.notify;
			this.StopMoving();

			this.deltaTime = deltaTime;
			this.inPause = inPause;
			this.componentSettings = componentSettings;

			this.interpolation = interpolation.CreateQuaternion(this.transform.rotation,
				Quaternion.LookRotation(position - this.transform.position, worldUp),
				time);
			this.notify = notify;

			this.lastRotation = this.transform.rotation;

			this.rotateToPosition = true;
			this.enabled = true;

			this.Notify(tmpNotify);
		}

		public virtual void RotateToPosition2D(RotateComponentSettings.Instance componentSettings, float angle,
			Interpolation interpolation, float time, GetFloat deltaTime, bool inPause, params Notify[] notify)
		{
			Notify[] tmpNotify = this.notify;
			this.StopMoving();

			this.deltaTime = deltaTime;
			this.inPause = inPause;
			this.componentSettings = componentSettings;

			float tmp = this.transform.eulerAngles.z;
			ValueHelper.SecureRotation2(ref tmp);
			ValueHelper.SecureRotation2(ref angle);
			if(Mathf.Abs(tmp - angle) > 180)
			{
				if(angle < 0)
				{
					angle += 360;
				}
				else if(angle > 0)
				{
					angle -= 360;
				}
			}
			this.interpolation2D = interpolation.CreateFloat(tmp, angle, time);
			this.notify = notify;

			this.lastAngle = tmp;

			this.rotateToPosition2D = true;
			this.enabled = true;

			this.Notify(tmpNotify);
		}

		public virtual void Rotation(RotateComponentSettings.Instance componentSettings, float time,
			Vector3 direction, GetFloat deltaTime, bool inPause, params Notify[] notify)
		{
			Notify[] tmpNotify = this.notify;
			this.StopMoving();

			this.deltaTime = deltaTime;
			this.inPause = inPause;
			this.componentSettings = componentSettings;
			this.time = 0;
			this.time2 = time;
			this.direction = direction;
			this.notify = notify;

			this.rotateDirection = true;
			this.enabled = true;

			this.Notify(tmpNotify);
		}

		public virtual void Rotation(RotateComponentSettings.Instance componentSettings, float time,
			Vector3 distance, Interpolation interpolation, GetFloat deltaTime, bool inPause, params Notify[] notify)
		{
			Notify[] tmpNotify = this.notify;
			this.StopMoving();

			this.deltaTime = deltaTime;
			this.inPause = inPause;
			this.componentSettings = componentSettings;

			this.interpolation = interpolation.CreateQuaternion(this.transform.rotation,
				Quaternion.Euler(distance + this.transform.eulerAngles), time);

			this.lastRotation = this.transform.rotation;
			this.notify = notify;

			this.rotateDirection = true;
			this.enabled = true;

			this.Notify(tmpNotify);
		}

		public virtual void RotateByCurve(RotateComponentSettings.Instance componentSettings,
			AnimationCurve xCurve, AnimationCurve yCurve, AnimationCurve zCurve, float time,
			GetFloat deltaTime, bool inPause, params Notify[] notify)
		{
			Notify[] tmpNotify = this.notify;
			this.StopMoving();

			this.deltaTime = deltaTime;
			this.inPause = inPause;
			this.componentSettings = componentSettings;
			this.startRotation = this.transform.eulerAngles;
			this.lastRotation = this.transform.rotation;

			this.xCurve = xCurve;
			this.yCurve = yCurve;
			this.zCurve = zCurve;

			this.time = 0;
			this.time2 = time;
			this.notify = notify;

			this.rotateCurve = true;
			this.enabled = true;

			this.Notify(tmpNotify);
		}


		/*
		============================================================================
		Callbacks functions
		============================================================================
		*/
		protected virtual void Notify()
		{
			if(this.notify != null)
			{
				Notify[] tmpNotify = this.notify;
				this.notify = null;
				this.Notify(tmpNotify);
			}
		}

		protected virtual void Notify(Notify[] tmpNotify)
		{
			if(tmpNotify != null)
			{
				for(int i = 0; i < tmpNotify.Length; i++)
				{
					if(tmpNotify[i] != null)
					{
						tmpNotify[i]();
					}
				}
			}
		}


		/*
		============================================================================
		Update functions
		============================================================================
		*/
		protected virtual void Update()
		{
			if(this.inPause || !Maki.Game.Paused)
			{
				if(this.rotateToPosition)
				{
					Quaternion tmp = this.interpolation.Tick(this.deltaTime == null ? Maki.Game.DeltaTime : this.deltaTime());
					this.componentSettings.ChangeRotation(
						(Quaternion.Inverse(this.lastRotation) * tmp).eulerAngles);
					this.lastRotation = tmp;

					if(this.interpolation.Finished)
					{
						this.rotateToPosition = false;
						this.enabled = false;
						this.Notify();
					}
				}
				else if(this.rotateToPosition2D)
				{
					float tmp = this.interpolation2D.Tick(this.deltaTime == null ? Maki.Game.DeltaTime : this.deltaTime());
					this.componentSettings.ChangeRotation(new Vector3(0, 0, tmp - this.lastAngle));
					this.lastAngle = tmp;

					if(this.interpolation2D.Finished)
					{
						this.rotateToPosition2D = false;
						this.enabled = false;
						this.Notify();
					}
				}
				else if(this.rotateDirection)
				{
					float deltaTime = this.deltaTime == null ? Maki.Game.DeltaTime : this.deltaTime();
					if(this.interpolation == null)
					{
						this.time += deltaTime;
						this.componentSettings.ChangeRotation(this.direction * deltaTime);

						if(this.time >= this.time2)
						{
							this.rotateDirection = false;
							this.enabled = false;
							this.Notify();
						}
					}
					else
					{
						Quaternion tmp = this.interpolation.Tick(deltaTime);
						this.componentSettings.ChangeRotation(
							(Quaternion.Inverse(this.lastRotation) * tmp).eulerAngles);
						this.lastRotation = tmp;

						if(this.interpolation.Finished)
						{
							this.rotateDirection = false;
							this.enabled = false;
							this.Notify();
						}
					}
				}
				else if(this.rotateCurve)
				{
					this.time += this.deltaTime == null ? Maki.Game.DeltaTime : this.deltaTime();

					Vector3 tmp = Vector3.zero;
					if(this.xCurve != null)
					{
						tmp.x = this.xCurve.Evaluate(this.time);
					}
					if(this.yCurve != null)
					{
						tmp.y = this.yCurve.Evaluate(this.time);
					}
					if(this.zCurve != null)
					{
						tmp.z = this.zCurve.Evaluate(this.time);
					}

					tmp = this.startRotation + tmp;
					this.componentSettings.ChangeRotation(
						(Quaternion.Inverse(this.lastRotation) * Quaternion.Euler(tmp)).eulerAngles);
					this.lastRotation = Quaternion.Euler(tmp);

					if(this.time >= this.time2)
					{
						this.rotateCurve = false;
						this.enabled = false;
						this.Notify();
					}
				}
			}
		}
	}
}
