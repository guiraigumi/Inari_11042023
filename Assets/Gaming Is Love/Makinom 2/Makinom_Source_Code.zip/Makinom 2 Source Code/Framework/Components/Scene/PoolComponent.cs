﻿
using UnityEngine;
using System.Collections.Generic;

namespace GamingIsLove.Makinom.Components
{
	[AddComponentMenu("Makinom/Scenes/Pool")]
	public class PoolComponent : SerializedBehaviour<PoolComponent.Settings>
	{
		protected virtual void Start()
		{
			PoolAsset asset = this.settings.pool;
			if(asset != null)
			{
				Maki.Pooling.Register(asset);
			}
		}


		/*
		============================================================================
		Settings class
		============================================================================
		*/
		public class Settings : BaseData
		{
			[EditorHelp("Pool", "Select the game object pool that will be used in this scene.", "")]
			public AssetSelection<PoolAsset> pool = new AssetSelection<PoolAsset>();

			public Settings()
			{

			}
		}

		protected virtual void OnDrawGizmos()
		{
			Gizmos.DrawIcon(transform.position, "/GamingIsLove/Makinom/Components/PoolComponent Icon.png");
		}
	}
}
