
using UnityEngine;
using System.Collections.Generic;
using System.Collections;

namespace GamingIsLove.Makinom.Components
{
	[AddComponentMenu("")]
	public class SpawnedPrefabObject : MonoBehaviour
	{
		public GameObject usedPrefab;

		public virtual void SetActive(bool active, float time)
		{
			if(time > 0)
			{
				this.StartCoroutine(this.SetActive2(active, time));
			}
			else
			{
				this.gameObject.SetActive(active);
			}
		}

		protected virtual IEnumerator SetActive2(bool active, float time)
		{
			yield return new WaitForSeconds(time);
			this.gameObject.SetActive(active);
		}
	}
}
