﻿
using UnityEngine;
using System.Collections.Generic;

namespace GamingIsLove.Makinom.Components
{
	public abstract class SerializedBehaviour<T> : SerializedBehaviour, ISerializationCallbackReceiver where T : IBaseData, new()
	{
		[System.NonSerialized]
		public T settings = new T();

		[SerializeField]
		[HideInInspector]
		protected ComponentDataFile serialize_setting;


		/*
		============================================================================
		Serialization functions
		============================================================================
		*/
		public override IBaseData SerializedSettings
		{
			get { return this.settings; }
		}

		public virtual void OnBeforeSerialize()
		{
			this.serialize_setting = this.settings.GetData().GetComponentDataFile("settings", false);
		}

		public virtual void OnAfterDeserialize()
		{
			if(this.serialize_setting != null)
			{
				this.settings.SetData(this.serialize_setting.ToDataObject());
				this.serialize_setting = null;
			}
		}
	}

	public abstract class SerializedBehaviour : MonoBehaviour
	{
		public abstract IBaseData SerializedSettings
		{
			get;
		}
	}
}
