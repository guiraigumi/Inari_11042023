
using UnityEngine;

namespace GamingIsLove.Makinom
{
	[System.AttributeUsage(System.AttributeTargets.All, AllowMultiple = false)]
	public class EditorHelpAttribute : System.Attribute
	{
		public GUIContent content;

		public string info;

		public EditorHelpAttribute(string name, string text)
		{
			this.content = new GUIContent(name, text);
			this.info = "";
		}

		public EditorHelpAttribute(string name, string text, string info)
		{
			this.content = new GUIContent(name, text);
			this.info = info;
		}

		public EditorHelpAttribute(EditorHelpAttribute other)
		{
			this.content = new GUIContent(other.content);
			this.info = other.info;
		}
	}
}

