﻿
namespace GamingIsLove.Makinom
{
	[System.AttributeUsage(System.AttributeTargets.Field, AllowMultiple = false)]
	public class EditorHideAttribute : System.Attribute
	{
		public bool always = false;

		public EditorHideAttribute()
		{

		}

		public EditorHideAttribute(bool always)
		{
			this.always = always;
		}
	}
}
