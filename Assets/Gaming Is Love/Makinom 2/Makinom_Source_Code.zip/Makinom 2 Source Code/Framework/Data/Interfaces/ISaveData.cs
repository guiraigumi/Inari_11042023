
namespace GamingIsLove.Makinom
{
	/// <summary>
	/// Interface used for saving/loading data with a save game.
	/// This doesn't automatically save the data - it still has to be included into the save game somewhere (e.g. the GameHandler class).
	/// </summary>
	public interface ISaveData
	{
		/// <summary>
		/// Used to save the data - you need to add the data to a <see cref="GamingIsLove.Makinom.DataObject"/>.
		/// </summary>
		/// <returns>
		/// A <see cref="GamingIsLove.Makinom.DataObject"/> containing the data.
		/// </returns>
		DataObject SaveGame();

		/// <summary>
		/// Used to load the data - you need to get the data from the <see cref="GamingIsLove.Makinom.DataObject"/>.
		/// </summary>
		/// <param name='data'>
		/// A <see cref="GamingIsLove.Makinom.DataObject"/> containing the data.
		/// </param>
		void LoadGame(DataObject data);
	}
}

