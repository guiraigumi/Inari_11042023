﻿
using UnityEngine;
using System.Collections.Generic;

namespace GamingIsLove.Makinom
{
	public interface IVariableSource
	{
		bool HasVariables
		{
			get;
		}

		VariableHandler Variables
		{
			get;
		}
	}
}
