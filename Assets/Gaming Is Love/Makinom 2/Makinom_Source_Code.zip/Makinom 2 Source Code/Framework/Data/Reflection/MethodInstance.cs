﻿
using UnityEngine;
using System.Text;
using System.Reflection;

namespace GamingIsLove.Makinom.Reflection
{
	public class MethodInstance
	{
		public MethodInfo methodInfo;

		public object instance;

		public MethodInstance(object instance)
		{
			this.instance = instance;
		}

		public void Invoke(params object[] parameters)
		{
			if(this.methodInfo != null)
			{
				this.methodInfo.Invoke(this.instance, parameters);
			}
		}
	}
}
