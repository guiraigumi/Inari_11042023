﻿
using UnityEngine;
using System.Collections.Generic;

namespace GamingIsLove.Makinom
{
	public abstract class BaseLanguageDataWithType<T, V> : BaseLanguageData, ITypeAsset<T>, ITypeData<V>, ITypeContent where T : MakinomGenericAsset<V> where V : BaseLanguageData, new()
	{
		public BaseLanguageDataWithType()
		{

		}

		public BaseLanguageDataWithType(string name) : base(name)
		{

		}

		public abstract T TypeAsset
		{
			get;
		}

		public virtual bool HasType
		{
			get { return this.TypeAsset != null; }
		}

		public virtual V TypeData
		{
			get { return this.TypeAsset != null ? this.TypeAsset.Settings : null; }
		}

		public virtual IContent GetTypeContent()
		{
			return this.TypeAsset != null ? this.TypeAsset.Settings : null;
		}

		public override string GetEditorPopupName(bool addType)
		{
			if(addType &&
				this.TypeData != null)
			{
				return this.ID + ": " + this.EditorName +
					"\n<i>" + this.TypeData.EditorName + "</i>";
			}
			return this.ID + ": " + this.EditorName;
		}
	}
}
