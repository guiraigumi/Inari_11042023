
using UnityEngine;

namespace GamingIsLove.Makinom
{
	public class LanguagesSettings : GenericAssetListSettings<LanguageAsset, Language>
	{
		[EditorHide(true)]
		public int exportIDSettings = 0;

		[EditorHide(true)]
		public int exportIDScenes = 0;

		[EditorHide(true)]
		public int exportIDPrefabs = 0;

		[EditorHide(true)]
		public int exportIDSchematics = 0;

		public LanguagesSettings(MakinomProjectAsset project)
		{
			this.LoadProject(project);
			this.CreateGUIDLookup();
		}


		/*
		============================================================================
		Properties
		============================================================================
		*/
		public override string Filename
		{
			get { return "Languages"; }
		}


		/*
		============================================================================
		Ingame functions
		============================================================================
		*/
		public Language GetInitialLanguage()
		{
			if(Maki.SaveGameSettings.storeOptionLanguage &&
				PlayerPrefs.HasKey("languageGUID"))
			{
				Language language = this.Get(PlayerPrefs.GetString("languageGUID", ""));
				if(language != null)
				{
					return language;
				}
			}
			for(int i = 0; i < this.assets.Count; i++)
			{
				if(this.assets[i] != null &&
					this.assets[i].Settings.initialLanguage)
				{
					return this.assets[i].Settings;
				}
			}
			return this.assets.Count > 0 ? this.assets[0].Settings : null;
		}
	}
}

