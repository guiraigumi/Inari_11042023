
using UnityEngine;
using GamingIsLove.Makinom.UI;

namespace GamingIsLove.Makinom
{
	public class UISettings : BaseSettings, IUISystemChanged
	{
		// drag/drop settings
		[EditorFoldout("Drag/Drop Settings", "Define drag/drop interaction settings.", "")]
		[EditorEndFoldout]
		public DragDropSettings dragDrop = new DragDropSettings();


		// buttons
		[EditorFoldout("Default Buttons", "Default button settings, the buttons are used system wide.", "")]
		[EditorEndFoldout]
		public DefaultButtonSettings defaultButtons = new DefaultButtonSettings();


		// flying texts
		[EditorFoldout("Flying Text Settings", "Define the default flying text settings.", "")]
		[EditorTitleLabel("Default UI")]
		[EditorLabel("Used as fallback for creating flying texts if the individual flying texts don't define a UI setup.")]
		public BaseUIFlyingTextSettings defaultFlyingText = Maki.UISystem.settings.Create<BaseUIFlyingTextSettings>();

		// create object
		[EditorSeparator]
		public FlyingTextObjectCreationSettings flyingTextObjectCreation = new FlyingTextObjectCreationSettings();

		// visibility
		[EditorHelp("Check Visibility", "Check the visibility of the flying text's position in the world space.\n" +
			"The visibility is checked using the camera's viewport.")]
		[EditorSeparator]
		public bool flyingTextCheckVisibility = true;

		[EditorHelp("Viewport Padding", "Define the padding that will be added to viewport checks.\n" +
			"Positive values will expand the viewport, negative values will contract the viewport.\n" +
			"A viewport position is visible if the x and y axes is between 0 and 1 and the z axis is 0 or greater.", "")]
		[EditorCondition("flyingTextCheckVisibility", true)]
		[EditorEndCondition]
		public Vector3 flyingTextViewportPadding = Vector3.zero;

		// display distance
		[EditorSeparator]
		public UIDisplayRangeSettings flyingTextDisplayRange = new UIDisplayRangeSettings();

		// positions
		[EditorFoldout("Default Flying Text Positions", "Define the default positions for flying texts.\n" +
			"Each flying text can optionally override the default positions.", "")]
		[EditorEndFoldout(2)]
		public FlyingTextPositionSettings defaultFlyingTextPositions = new FlyingTextPositionSettings();


		// exit game question
		[EditorFoldout("Exit Game Question", "This dialogue is displayed when you exit a running game (e.g. via 'Stop Game' node).", "")]
		[EditorEndFoldout]
		public QuestionControl exitGameQuestion = new QuestionControl();

		public UISettings(MakinomProjectAsset project)
		{
			this.LoadProject(project);
		}

		public override void SetData(DataObject data)
		{
			base.SetData(data);

			this.CheckUIData();
		}


		/*
		============================================================================
		Properties
		============================================================================
		*/
		public override string Filename
		{
			get { return "UI Settings"; }
		}


		/*
		============================================================================
		UI system changed
		============================================================================
		*/
		public virtual void CheckUIData()
		{
			if(!Maki.UISystem.settings.CheckType<BaseUIFlyingTextSettings>(this.defaultFlyingText))
			{
				this.UISystemChanged();
			}
		}

		public virtual void UISystemChanged()
		{
			DataObject data = this.defaultFlyingText.GetData();
			this.defaultFlyingText = Maki.UISystem.settings.Create<BaseUIFlyingTextSettings>();
			this.defaultFlyingText.SetData(data);
		}
	}
}
