﻿
using UnityEngine;
using System.Collections.Generic;

namespace GamingIsLove.Makinom
{
	public class AudioHandler : ISaveData
	{
		// global volume
		protected float globalVolume = 1;

		protected bool muteGlobalVolume = false;

		protected Interpolation.FloatInstance fadeGlobalVolume;


		// music volume
		protected float musicVolume = 1;

		protected bool muteMusicVolume = false;

		protected Interpolation.FloatInstance fadeMusicVolume;


		// sound volume
		protected float soundVolume = 1;

		protected bool muteSoundVolume = false;

		protected Interpolation.FloatInstance fadeSoundVolume;


		// music
		protected GameObject soundObject;

		protected Dictionary<int, SoundChannel> soundChannel = new Dictionary<int, SoundChannel>();


		// music
		protected GameObject musicObject;

		protected Dictionary<int, MusicChannel> musicChannel = new Dictionary<int, MusicChannel>();

		public AudioHandler()
		{

		}

		public virtual void Init()
		{
			if(Application.isPlaying)
			{
				// sound channels
				if(this.soundObject == null)
				{
					this.soundObject = new GameObject("Sound");
					this.soundObject.transform.SetParent(Maki.GameObject.transform);
				}
				if(!this.soundChannel.ContainsKey(0))
				{
					this.soundChannel.Add(0, new SoundChannel(this.soundObject, 0));
				}
				// music channels
				if(this.musicObject == null)
				{
					this.musicObject = new GameObject("Music");
					this.musicObject.transform.SetParent(Maki.GameObject.transform);
				}
				if(!this.musicChannel.ContainsKey(0))
				{
					this.musicChannel.Add(0, new MusicChannel(this.musicObject, 0));
				}

				// volumes
				// global volume
				if(Maki.SaveGameSettings.storeOptionGlobalVolume &&
				   PlayerPrefs.HasKey("muteGlobalVolume"))
				{
					this.muteGlobalVolume = PlayerPrefs.GetInt("muteGlobalVolume") == 1;
				}
				if(Maki.SaveGameSettings.storeOptionGlobalVolume &&
					PlayerPrefs.HasKey("globalVolume"))
				{
					this.GlobalVolume = PlayerPrefs.GetFloat("globalVolume");
				}
				else
				{
					this.GlobalVolume = Maki.GameSettings.startGlobalVolume;
				}
				// music volume
				if(Maki.SaveGameSettings.storeOptionMusicVolume &&
				   PlayerPrefs.HasKey("muteMusicVolume"))
				{
					this.muteMusicVolume = PlayerPrefs.GetInt("muteMusicVolume") == 1;
				}
				if(Maki.SaveGameSettings.storeOptionMusicVolume &&
					PlayerPrefs.HasKey("musicVolume"))
				{
					this.MusicVolume = PlayerPrefs.GetFloat("musicVolume");
				}
				else
				{
					this.MusicVolume = Maki.GameSettings.startMusicVolume;
				}
				// sound volume
				if(Maki.SaveGameSettings.storeOptionSoundVolume &&
				   PlayerPrefs.HasKey("muteSoundVolume"))
				{
					this.muteSoundVolume = PlayerPrefs.GetInt("muteSoundVolume") == 1;
				}
				if(Maki.SaveGameSettings.storeOptionSoundVolume &&
					PlayerPrefs.HasKey("soundVolume"))
				{
					this.SoundVolume = PlayerPrefs.GetFloat("soundVolume");
				}
				else
				{
					this.SoundVolume = Maki.GameSettings.startSoundVolume;
				}

				// init channel settings
				for(int i = 0; i < Maki.GameSettings.soundChannel.Length; i++)
				{
					Maki.GameSettings.soundChannel[i].Initialize();
				}
				for(int i = 0; i < Maki.GameSettings.musicChannel.Length; i++)
				{
					Maki.GameSettings.musicChannel[i].Initialize();
				}
			}
		}

		public virtual void Tick()
		{
			// global volume fading
			if(this.fadeGlobalVolume != null)
			{
				this.globalVolume = this.fadeGlobalVolume.Tick(Time.unscaledDeltaTime);
				this.UpdateSoundVolumes();
				this.UpdateMusicVolumes();

				if(this.fadeGlobalVolume.Finished)
				{
					this.fadeGlobalVolume = null;
				}
			}
			// music volume fading
			if(this.fadeMusicVolume != null)
			{
				this.musicVolume = this.fadeMusicVolume.Tick(Time.unscaledDeltaTime);
				this.UpdateMusicVolumes();

				if(this.fadeMusicVolume.Finished)
				{
					this.fadeMusicVolume = null;
				}
			}
			// sound volume fading
			if(this.fadeSoundVolume != null)
			{
				this.soundVolume = this.fadeSoundVolume.Tick(Time.unscaledDeltaTime);
				this.UpdateSoundVolumes();

				if(this.fadeSoundVolume.Finished)
				{
					this.fadeSoundVolume = null;
				}
			}

			// sound channels
			foreach(KeyValuePair<int, SoundChannel> ch in this.soundChannel)
			{
				ch.Value.Tick();
			}
			// music channels
			foreach(KeyValuePair<int, MusicChannel> ch in this.musicChannel)
			{
				ch.Value.Tick();
			}
		}


		/*
		============================================================================
		Global volume functions
		============================================================================
		*/
		public virtual float GlobalVolume
		{
			get { return this.muteGlobalVolume ? 0 : this.globalVolume; }
			set
			{
				if(this.globalVolume != value)
				{
					this.globalVolume = value;
					if(this.globalVolume < 0)
					{
						this.globalVolume = 0;
					}
					else if(this.globalVolume > 1)
					{
						this.globalVolume = 1;
					}
					this.UpdateSoundVolumes();
					this.UpdateMusicVolumes();
					if(Maki.SaveGameSettings.storeOptionGlobalVolume)
					{
						PlayerPrefs.SetFloat("globalVolume", this.globalVolume);
					}
				}
			}
		}

		public virtual float RealGlobalVolume
		{
			get { return this.globalVolume; }
		}

		public virtual bool MuteGlobalVolume
		{
			get { return this.muteGlobalVolume; }
			set
			{
				if(this.muteGlobalVolume != value)
				{
					this.muteGlobalVolume = value;
					this.UpdateSoundVolumes();
					this.UpdateMusicVolumes();
					if(Maki.SaveGameSettings.storeOptionGlobalVolume)
					{
						PlayerPrefs.SetInt("muteGlobalVolume", this.muteGlobalVolume ? 1 : 0);
					}
				}
			}
		}

		public virtual void FadeGlobalVolume(float toVolume, Interpolation interpolation, float time)
		{
			ValueHelper.Limit(ref toVolume, 0.0f, 1.0f);
			this.fadeGlobalVolume = interpolation.CreateFloat(this.globalVolume, toVolume, time);
		}


		/*
		============================================================================
		Music volume functions
		============================================================================
		*/
		public virtual float MusicVolume
		{
			get { return this.muteMusicVolume ? 0 : (this.musicVolume * this.GlobalVolume); }
			set
			{
				if(this.musicVolume != value)
				{
					this.musicVolume = value;
					if(this.musicVolume < 0)
					{
						this.musicVolume = 0;
					}
					else if(this.musicVolume > 1)
					{
						this.musicVolume = 1;
					}
					this.UpdateMusicVolumes();
					if(Maki.SaveGameSettings.storeOptionMusicVolume)
					{
						PlayerPrefs.SetFloat("musicVolume", this.musicVolume);
					}
				}
			}
		}

		public virtual float RealMusicVolume
		{
			get { return this.musicVolume; }
		}

		public virtual bool MuteMusicVolume
		{
			get { return this.muteMusicVolume; }
			set
			{
				if(this.muteMusicVolume != value)
				{
					this.muteMusicVolume = value;
					this.UpdateMusicVolumes();
					if(Maki.SaveGameSettings.storeOptionMusicVolume)
					{
						PlayerPrefs.SetInt("muteMusicVolume", this.muteMusicVolume ? 1 : 0);
					}
				}
			}
		}

		public virtual void FadeMusicVolume(float toVolume, Interpolation interpolation, float time)
		{
			ValueHelper.Limit(ref toVolume, 0.0f, 1.0f);
			this.fadeMusicVolume = interpolation.CreateFloat(this.musicVolume, toVolume, time);
		}


		/*
		============================================================================
		Sound volume functions
		============================================================================
		*/
		public virtual float SoundVolume
		{
			get { return this.muteSoundVolume ? 0 : (this.soundVolume * this.GlobalVolume); }
			set
			{
				if(this.soundVolume != value)
				{
					this.soundVolume = value;
					if(this.soundVolume < 0)
					{
						this.soundVolume = 0;
					}
					else if(this.soundVolume > 1)
					{
						this.soundVolume = 1;
					}
					this.UpdateSoundVolumes();
					if(Maki.SaveGameSettings.storeOptionSoundVolume)
					{
						PlayerPrefs.SetFloat("soundVolume", this.soundVolume);
					}
				}
			}
		}

		public virtual float RealSoundVolume
		{
			get { return this.soundVolume; }
		}

		public virtual bool MuteSoundVolume
		{
			get { return this.muteSoundVolume; }
			set
			{
				if(this.muteSoundVolume != value)
				{
					this.muteSoundVolume = value;
					this.UpdateSoundVolumes();
					if(Maki.SaveGameSettings.storeOptionSoundVolume)
					{
						PlayerPrefs.SetInt("muteSoundVolume", this.muteSoundVolume ? 1 : 0);
					}
				}
			}
		}

		public virtual void FadeSoundVolume(float toVolume, Interpolation interpolation, float time)
		{
			ValueHelper.Limit(ref toVolume, 0.0f, 1.0f);
			this.fadeSoundVolume = interpolation.CreateFloat(this.soundVolume, toVolume, time);
		}

		public virtual SoundChannel GetSoundChannel(int index)
		{
			if(!this.soundChannel.ContainsKey(index))
			{
				this.soundChannel.Add(index, new SoundChannel(this.soundObject, index));
			}
			return this.soundChannel[index];
		}

		public virtual void UpdateSoundVolumes()
		{
			foreach(KeyValuePair<int, SoundChannel> ch in this.soundChannel)
			{
				ch.Value.UpdateVolume();
			}
		}

		public virtual Dictionary<int, SoundChannel> GetSoundChannels()
		{
			return this.soundChannel;
		}


		/*
		============================================================================
		Music functions
		============================================================================
		*/
		public virtual MusicChannel GetMusicChannel(int index)
		{
			if(!this.musicChannel.ContainsKey(index))
			{
				this.musicChannel.Add(index, new MusicChannel(this.musicObject, index));
			}
			return this.musicChannel[index];
		}

		public virtual bool IsPlayingMusic()
		{
			foreach(KeyValuePair<int, MusicChannel> ch in this.musicChannel)
			{
				if(ch.Value.IsPlaying())
				{
					return true;
				}
			}
			return false;
		}

		public virtual bool IsPlayingMusic(MusicClipSetting musicClip)
		{
			foreach(KeyValuePair<int, MusicChannel> ch in this.musicChannel)
			{
				if(ch.Value.IsPlaying(musicClip))
				{
					return true;
				}
			}
			return false;
		}

		public virtual void UpdateMusicVolumes()
		{
			foreach(KeyValuePair<int, MusicChannel> ch in this.musicChannel)
			{
				ch.Value.UpdateVolume();
			}
		}

		public virtual void StopMusic()
		{
			foreach(KeyValuePair<int, MusicChannel> ch in this.musicChannel)
			{
				ch.Value.Stop();
			}
		}

		public virtual Dictionary<int, MusicChannel> GetMusicChannels()
		{
			return this.musicChannel;
		}


		/*
		============================================================================
		Save game functions
		============================================================================
		*/
		public virtual DataObject SaveGame()
		{
			DataObject data = new DataObject();

			// volumes
			if(Maki.SaveGameSettings.saveVolumes)
			{
				data.Set("globalVolume", this.globalVolume);
				data.Set("muteGlobalVolume", this.muteGlobalVolume);

				data.Set("musicVolume", this.musicVolume);
				data.Set("muteMusicVolume", this.muteMusicVolume);

				data.Set("soundVolume", this.soundVolume);
				data.Set("muteSoundVolume", this.muteSoundVolume);
			}

			// sound channels
			Dictionary<string, DataObject> channelData = new Dictionary<string, DataObject>();
			foreach(KeyValuePair<int, SoundChannel> ch in this.soundChannel)
			{
				channelData.Add(ch.Key.ToString(), ch.Value.SaveGame());
			}
			if(channelData.Count > 0)
			{
				DataObject soundData = new DataObject();
				soundData.SetData<DataObject>(channelData, typeof(DataObject));
				data.Set("sound", soundData);
			}

			// music channels
			channelData = new Dictionary<string, DataObject>();
			foreach(KeyValuePair<int, MusicChannel> ch in this.musicChannel)
			{
				channelData.Add(ch.Key.ToString(), ch.Value.SaveGame());
			}
			if(channelData.Count > 0)
			{
				DataObject musicData = new DataObject();
				musicData.SetData<DataObject>(channelData, typeof(DataObject));
				data.Set("music", musicData);
			}

			return data;
		}

		public virtual void LoadGame(DataObject data)
		{
			if(data != null)
			{
				// volumes
				if(Maki.SaveGameSettings.saveVolumes)
				{
					data.Get("globalVolume", ref this.globalVolume);
					data.Get("muteGlobalVolume", ref this.muteGlobalVolume);

					data.Get("musicVolume", ref this.musicVolume);
					data.Get("muteMusicVolume", ref this.muteMusicVolume);

					data.Get("soundVolume", ref this.soundVolume);
					data.Get("muteSoundVolume", ref this.muteSoundVolume);
				}

				// sound channels
				this.LoadSoundChannels(data.GetFile("sound"));

				// music channels
				this.LoadMusicChannels(data.GetFile("music"));
			}
		}

		public virtual void LoadSoundChannels(DataObject data)
		{
			if(data != null)
			{
				Dictionary<string, DataObject> tmp = data.GetData<DataObject>(typeof(DataObject));
				if(tmp != null && tmp.Count > 0)
				{
					foreach(KeyValuePair<string, DataObject> pair in tmp)
					{
						int index = -1;
						if(int.TryParse(pair.Key, out index))
						{
							this.GetSoundChannel(index).LoadGame(pair.Value);
						}
					}
				}
			}
		}

		public virtual void LoadMusicChannels(DataObject data)
		{
			if(data != null)
			{
				Dictionary<string, DataObject> tmp = data.GetData<DataObject>(typeof(DataObject));
				if(tmp != null && tmp.Count > 0)
				{
					foreach(KeyValuePair<string, DataObject> pair in tmp)
					{
						int index = -1;
						if(int.TryParse(pair.Key, out index))
						{
							this.GetMusicChannel(index).LoadGame(pair.Value);
						}
					}
				}
			}
		}
	}
}
