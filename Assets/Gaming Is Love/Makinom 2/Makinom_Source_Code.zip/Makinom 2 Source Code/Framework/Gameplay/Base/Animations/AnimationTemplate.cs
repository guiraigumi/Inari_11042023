
using UnityEngine;
using System.Collections.Generic;

namespace GamingIsLove.Makinom
{
	public class AnimationTemplateAsset : MakinomGenericAsset<AnimationTemplate>
	{
		public AnimationTemplateAsset()
		{

		}

		public override string DataName
		{
			get { return "Animation Template"; }
		}
	}

	public class AnimationTemplate : BaseIndexData
	{
		[EditorHelp("Name", "The name of the animation template.", "")]
		[EditorFoldout("Base Settings", "Set the name of this animation template.", "")]
		[EditorEndFoldout]
		[EditorWidth(true)]
		public string name = "";


		// legacy
		[EditorHelp("Use Legacy", "Use a legacy animation.\n" +
			"This will be used when a game object has an 'Animation' component attached.", "")]
		[EditorFoldout("Legacy Animation", "You can use a legacy animation.\n" +
			"These settings will be used when a game object has an 'Animation' component attached.", "")]
		public bool useLegacy = false;

		[EditorEndFoldout]
		[EditorCondition("useLegacy", true)]
		[EditorEndCondition]
		[EditorAutoInit]
		public LegacyAnimation legacy;


		// mecanim
		[EditorHelp("Use Mecanim", "Use a mecanim animation.\n" +
			"This will be used when a game object has an 'Animator' component attached.", "")]
		[EditorFoldout("Mecanim Animation", "You can use a mecanim animation.\n" +
			"These settings will be used when a game object has an 'Animator' component attached.", "")]
		public bool useMecanim = false;

		[EditorEndFoldout]
		[EditorCondition("useMecanim", true)]
		[EditorEndCondition]
		[EditorAutoInit]
		public MecanimAnimation mecanim;


		// custom
		[EditorHelp("Use Custom", "Use a custom animation system.\n" +
			"This will be used when a game object has a defined custom component attached.", "")]
		[EditorFoldout("Custom Animation", "You can use a custom animation system.\n" +
			"These settings will be used when a game object has a defined custom component attached.", "")]
		public bool useCustom = false;

		[EditorEndFoldout]
		[EditorCondition("useCustom", true)]
		[EditorEndCondition]
		[EditorAutoInit]
		public CustomAnimation custom;

		public AnimationTemplate()
		{

		}

		public AnimationTemplate(string name) : base(name)
		{
			this.name = name;
		}

		public override string EditorName
		{
			get { return this.name; }
			set { this.name = value; }
		}


		/*
		============================================================================
		Animation functions
		============================================================================
		*/
		public AnimInfo Play(DataCall call)
		{
			if(call.UserGameObject != null)
			{
				Animation animation = call.UserGameObject.GetComponent<Animation>();
				if(this.useLegacy && animation != null)
				{
					this.legacy.Init(call, animation);
					return this.legacy.Play(animation);
				}
				else
				{
					Animator animator = call.UserGameObject.GetComponent<Animator>();
					if(this.useMecanim && animator != null)
					{
						return this.mecanim.Play(animator);
					}
					else if(this.useCustom)
					{
						return this.custom.Play(call);
					}
				}
			}
			return AnimInfo.None;
		}

		public void Stop(DataCall call)
		{
			if(call.UserGameObject != null)
			{
				Animation animation = call.UserGameObject.GetComponent<Animation>();
				if(this.useLegacy && animation != null)
				{
					this.legacy.Stop(animation);
				}
				else
				{
					Animator animator = call.UserGameObject.GetComponent<Animator>();
					if(this.useMecanim && animator != null)
					{
						this.mecanim.Stop(animator);
					}
					else if(this.useCustom)
					{
						this.custom.Stop(call);
					}
				}
			}
		}
	}
}
