﻿
using UnityEngine;
using System.Collections;
using System.Collections.Generic;

namespace GamingIsLove.Makinom
{
	public class WaitForAnimation : BaseWaitForAnim
	{
		private Animation animation;

		public WaitForAnimation(Animation animation)
		{
			this.animation = animation;
		}

		public Animation Animation
		{
			get { return this.animation; }
		}

		public override void Play(string name, Notify callback, bool wait, float maxWaitTime)
		{
			this.Cancel();

			if(this.animation != null &&
				!string.IsNullOrEmpty(name) &&
				this.animation[name] != null)
			{
				this.maxWaitTime = maxWaitTime;
				this.animation.Play(name);

				if(wait &&
					this.maxWaitTime > 0)
				{
					this.coroutine = Maki.StartCoroutine(this.Wait(name, callback));
				}
				else if(callback != null)
				{
					callback();
				}
			}
		}

		private IEnumerator Wait(string name, Notify callback)
		{
			float timeout = Time.realtimeSinceStartup +
				Mathf.Min(this.maxWaitTime, this.animation[name].length);

			while(Time.realtimeSinceStartup < timeout)
			{
				yield return null;
			}

			this.coroutine = null;
			if(callback != null)
			{
				callback();
			}
		}
	}
}
