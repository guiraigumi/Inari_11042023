﻿
using UnityEngine;
using System.Collections.Generic;

namespace GamingIsLove.Makinom
{
	[EditorSettingInfo("Reference", "Select the asset that will be used.\n" +
		"This saves a direct reference to the asset.")]
	public class ReferenceAssetSource<T> : BaseAssetSource<T> where T : UnityEngine.Object
	{
		[EditorHelp("Asset", "Select the asset that will be used.", "")]
		[EditorHide]
		[EditorWidth(150, true)]
		public T asset;

		public ReferenceAssetSource()
		{

		}

		public override T Get()
		{
			return this.asset;
		}


		/*
		============================================================================
		Editor functions
		============================================================================
		*/
		public override bool EditorHasAssetField
		{
			get { return true; }
		}

		public override Object EditorAsset
		{
			get { return this.asset; }
			set { this.asset = value as T; }
		}

		public override bool HasAsset
		{
			get { return this.asset != null; }
		}

		public override string ToString()
		{
			return this.asset != null ? this.asset.name : "";
		}
	}
}
