﻿
using UnityEngine;
using System.Collections.Generic;

namespace GamingIsLove.Makinom
{
	[EditorSettingInfo("Acceleration", "A selected axis of the last linear acceleration of a device is used.")]
	public class AccelerationInputIDKeySetting : BaseInputIDKeySetting
	{
		// vector3 axis information
		[EditorHelp("Axis", "Select the axis of the Vector3 that will be used.", "")]
		public AxisType axisType = AxisType.X;

		[EditorHelp("Use Absolute Value", "Use the absolute value of the axis, i.e. -0.2 will become 0.2.", "")]
		public bool axisAbsoluteValue = true;

		[EditorHelp("Button Check", "A button press is recognized based on the selected check function.\n" +
			"The input can be recognized if the selected axis value is equal, not equal, less or greater than a defined value.\n" +
			"Range inclusive checks if the value is between two defined values, including the values.\n" +
			"Range exclusive checks if the value is between two defined values, excluding the values.\n" +
			"Approximately checks if the value is similar to the defined value.", "")]
		public ValueCheck<GameObjectSelection> axisButtonCheck = new ValueCheck<GameObjectSelection>();

		public AccelerationInputIDKeySetting()
		{

		}


		/*
		============================================================================
		Input functions
		============================================================================
		*/
		public override void Tick(InputIDKey inputKey, int inputKeyID)
		{
			inputKey.UpdateAxis = VectorHelper.GetAxisValue(Input.acceleration, this.axisType);

			if(this.axisButtonCheck.Check(
				this.axisAbsoluteValue ? Mathf.Abs(inputKey.UpdateAxis) : inputKey.UpdateAxis,
				this.axisButtonCheck.NeedsCall ? new DataCall(inputKey.inputID) : null))
			{
				inputKey.InputReceived = true;
			}
			else
			{
				inputKey.SetUpdateAxisUnmanipulated(0);
			}
		}
	}
}
