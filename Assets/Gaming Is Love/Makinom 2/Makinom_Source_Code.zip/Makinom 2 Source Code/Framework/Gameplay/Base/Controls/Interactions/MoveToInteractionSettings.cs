﻿
using UnityEngine;
using UnityEngine.AI;
using System.Collections.Generic;
using System.Reflection;

namespace GamingIsLove.Makinom
{
	public class MoveToInteractionSettings : BaseData
	{
		// move to interaction
		[EditorHelp("Use Move To Interaction", "The player will automatically move to an interaction before starting the interaction.", "")]
		public bool useMoveToInteraction = false;

		[EditorHelp("Set Interaction Radius", "Set a default radius for interaction machines.\n" +
			"If disabled, the determined radius of the game object will be used, i.e. " +
			"either from a 'Radius' component, colliders or NavMesh agent attached to the game object.", "")]
		[EditorCondition("useMoveToInteraction", true)]
		public bool setInteractionRadius = false;

		[EditorHelp("Default Interaction Radius", "The default radius used for interaction game objects.\n" +
			"The destination of the movement will be calculated from the player's radius, " +
			"the interaction's radius and the stop distance.", "")]
		[EditorCondition("setInteractionRadius", true)]
		[EditorEndCondition]
		public float defaultInteractionRadius = 1;

		[EditorHelp("Stop Distance", "The distance in world units the player will stop before the interaction.", "")]
		public float defaultStopDistance = 1;

		[EditorHelp("Interaction Distance", "The distance in world units the player must at least have to the destination position " +
			"to start the interaction after moving toward it.\n" +
			"The distance is checked less equal.", "")]
		public float interactionDistance = 0.1f;

		[EditorHelp("Ignore Distance", "The distance along the enabled axes will be ignored, " +
			"e.g. enabling Y will ignore the height difference for the destination distance check.", "")]
		public AxisBool ignoreDistance = new AxisBool();

		[EditorHelp("Ignore Radius", "The radius of the game objects will be ignored for the " +
			"destination distance check.", "")]
		public bool ignoreRadius = false;

		[EditorHelp("Don't Move When Closer", "Don't move to the interaction when the player " +
			"is already closer to it than the move destination.\n" +
			"If the interaction defined a destination object, this won't be used.", "")]
		public bool noMoveWhenCloser = true;


		// move position/speed component calls
		[EditorTitleLabel("Move Component Settings")]
		[EditorSeparator]
		public MovementComponentSetting moveComponent = new MovementComponentSetting();


		// move speed
		[EditorSeparator]
		public MoveSpeed<GameObjectSelection> moveSpeed = new MoveSpeed<GameObjectSelection>(5);


		// block controls
		[EditorHelp("Block Player Control", "The control of the player will be blocked while moving to an interaction.", "")]
		[EditorTitleLabel("Control Blocks")]
		[EditorSeparator]
		public bool blockPlayer = false;

		[EditorHelp("Block Camera Control", "The control of the camera will be blocked while moving to an interaction.", "")]
		public bool blockCamera = false;


		// cancel keys
		[EditorHelp("Cancel Input Key", "Select the input key that will cancel moving to an interaction.", "")]
		[EditorTitleLabel("Cancel Input Keys")]
		[EditorSeparator]
		[EditorArray("Add Cancel Input Key", "Adds an input key that will cancel moving to an interaction.", "",
			"Remove", "Removes this input key.", "", isHorizontal=true)]
		[EditorEndCondition]
		public AssetSelection<InputKeyAsset>[] cancelKey = new AssetSelection<InputKeyAsset>[0];

		public MoveToInteractionSettings()
		{

		}

		public override void SetData(DataObject data)
		{
			base.SetData(data);

			if(data.Contains<DataObject>("speed"))
			{
				this.moveSpeed.speed.SetData(data.GetFile("speed"));
			}
		}

		public bool CancelMovement()
		{
			for(int i = 0; i < this.cancelKey.Length; i++)
			{
				if(InputKey.GetButton(this.cancelKey[i].StoredAsset))
				{
					return true;
				}
			}
			return false;
		}
	}
}
