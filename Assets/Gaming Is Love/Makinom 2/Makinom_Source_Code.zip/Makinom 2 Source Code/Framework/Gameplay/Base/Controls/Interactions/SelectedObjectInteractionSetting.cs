﻿
using UnityEngine;
using GamingIsLove.Makinom.Components;
using System.Collections.Generic;

namespace GamingIsLove.Makinom
{
	public class SelectedObjectInteractionSetting : BaseData
	{
		// interaction range
		[EditorHelp("Limit Interaction Range", "Interactions on the 'Selected Object' can only be started within a defined to the player.\n" +
			"If disabled, the player can start all interactions, regardless of the distance to them.", "")]
		public bool soLimitRange = false;

		[EditorCondition("soLimitRange", true)]
		[EditorEndCondition]
		[EditorAutoInit]
		public RangeValue soRange;

		public SelectedObjectInteractionSetting()
		{

		}
	}
}
