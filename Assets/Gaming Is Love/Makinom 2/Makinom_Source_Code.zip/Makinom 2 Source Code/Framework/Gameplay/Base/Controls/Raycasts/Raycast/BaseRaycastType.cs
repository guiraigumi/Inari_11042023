﻿
using UnityEngine;
using System.Collections.Generic;

namespace GamingIsLove.Makinom
{
	public abstract class BaseRaycastType : BaseTypeData
	{
		public abstract RaycastOutput Raycast(IDataCall call, RaycastType raycastType,
			int layerMask, Vector3 originOffset, bool storeCoords, Camera camera);

		public abstract List<RaycastOutput> RaycastAll(IDataCall call, RaycastType raycastType,
			int layerMask, Vector3 originOffset, bool storeCoords, Camera camera);
	}

	public abstract class BaseRaycastType<T> : BaseRaycastType where T : IObjectSelection, new()
	{

	}
}
