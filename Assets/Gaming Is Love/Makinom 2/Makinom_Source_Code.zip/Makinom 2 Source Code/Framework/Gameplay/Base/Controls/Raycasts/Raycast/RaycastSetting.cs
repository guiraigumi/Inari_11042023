﻿
using UnityEngine;
using System.Collections.Generic;

namespace GamingIsLove.Makinom
{
	public class RaycastSetting<T> : BaseData where T : IObjectSelection, new()
	{
		[EditorHelp("Raycast Origin", "Select where the raycast comes from:", "")]
		[EditorInfo(settingBaseType=typeof(BaseRaycastType), settingAutoSetup="settings")]
		public string type = "";


		// settings
		[EditorSeparator]
		public BaseRaycastType<T> settings = new ScreenRaycastType<T>();


		// general
		[EditorSeparator]
		public RaycastTypeOverride raycastType = new RaycastTypeOverride();

		[EditorSeparator]
		[EditorHelp("Layer Mask", "The layer mask used for the raycast.", "")]
		[EditorTitleLabel("Layer Mask")]
		public FloatValue<T> layerMask = new FloatValue<T>(typeof(FloatValue_LayerMaskType<T>));

		[EditorSeparator]
		[EditorTitleLabel("Origin Offset")]
		[EditorLabel("The offset will be added to the origin position of the raycast.")]
		public Vector3Value<T> originOffset = new Vector3Value<T>();

		public RaycastSetting()
		{
			this.type = this.settings.GetGenericTypeName();
		}

		public override void EditorAutoSetup(string fieldName)
		{
			if(!this.settings.IsType(this.type))
			{
				DataObject data = this.settings.GetData();
				System.Type tmpType = ReflectionTypeHandler.Instance.GetType(this.type, typeof(BaseRaycastType));
				if(tmpType != null)
				{
					object tmpSettings = ReflectionTypeHandler.Instance.CreateInstance(
						tmpType.MakeGenericType(typeof(T)));
					if(tmpSettings is BaseRaycastType<T>)
					{
						this.settings = (BaseRaycastType<T>)tmpSettings;
						this.settings.SetData(data);
					}
					else
					{
						this.settings = new ScreenRaycastType<T>();
						this.settings.SetData(data);
						this.type = this.settings.GetGenericTypeName();
					}
				}
				else
				{
					this.settings = new ScreenRaycastType<T>();
					this.settings.SetData(data);
					this.type = this.settings.GetGenericTypeName();
				}
			}
		}

		public override string ToString()
		{
			return this.settings.ToString();
		}


		/*
		============================================================================
		Cast functions
		============================================================================
		*/
		public virtual RaycastOutput Raycast(IDataCall call, Camera camera, bool storeCoords)
		{
			return this.settings.Raycast(call, this.raycastType,
				(int)this.layerMask.GetValue(call), this.originOffset.GetValue(call), storeCoords, camera);
		}

		public virtual List<RaycastOutput> RaycastAll(IDataCall call, Camera camera, bool storeCoords)
		{
			return this.settings.RaycastAll(call, this.raycastType,
				(int)this.layerMask.GetValue(call), this.originOffset.GetValue(call), storeCoords, camera);
		}
	}
}
