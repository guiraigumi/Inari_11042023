
using UnityEngine;
using System.Collections.Generic;

namespace GamingIsLove.Makinom
{
	public class RaycastOutput
	{
		public bool is2D = false;

		public float distance = Mathf.Infinity;

		public Vector3 point = Vector3.zero;

		public Vector3 normal = Vector3.zero;

		public Transform transform;


		// 3D raycasts
		public Vector3 barycentricCoord = Vector3.zero;

		public Vector2 lightmapCoord = Vector2.zero;

		public Vector2 textureCoord = Vector2.zero;

		public Vector2 textureCoord2 = Vector2.zero;

		public int triangleIndex = 0;


		// 2D raycasts
		public Vector2 centroid = Vector2.zero;

		public float fraction = 0;

		public RaycastOutput()
		{

		}

		public RaycastOutput(RaycastHit hit)
		{
			this.is2D = false;
			this.point = hit.point;
			this.normal = hit.normal;
			this.transform = hit.transform;
			this.distance = hit.distance;
			this.triangleIndex = hit.triangleIndex;
		}

		public RaycastOutput(RaycastHit hit, bool storeCoords)
		{
			this.is2D = false;
			this.point = hit.point;
			this.normal = hit.normal;
			this.transform = hit.transform;
			this.distance = hit.distance;
			this.triangleIndex = hit.triangleIndex;
			if(storeCoords)
			{
				MeshCollider meshCollider = hit.collider as MeshCollider;
				if(meshCollider == null || meshCollider.sharedMesh.isReadable)
				{
					if(meshCollider.sharedMesh.HasVertexAttribute(UnityEngine.Rendering.VertexAttribute.TexCoord0))
					{
						this.textureCoord = hit.textureCoord;
					}
					if(meshCollider.sharedMesh.HasVertexAttribute(UnityEngine.Rendering.VertexAttribute.TexCoord1))
					{
						this.textureCoord2 = hit.textureCoord2;
						this.lightmapCoord = hit.lightmapCoord;
					}
				}
				this.barycentricCoord = hit.barycentricCoordinate;
			}
		}

		public RaycastOutput(RaycastHit2D hit)
		{
			this.is2D = true;
			this.point = hit.point;
			this.normal = hit.normal;
			this.transform = hit.transform;
			this.distance = hit.distance;
			this.centroid = hit.centroid;
			this.fraction = hit.fraction;
		}
	}

	public class RaycastOutputSorter : IComparer<RaycastOutput>
	{
		public int Compare(RaycastOutput x, RaycastOutput y)
		{
			return x.distance.CompareTo(y.distance);
		}
	}
}
