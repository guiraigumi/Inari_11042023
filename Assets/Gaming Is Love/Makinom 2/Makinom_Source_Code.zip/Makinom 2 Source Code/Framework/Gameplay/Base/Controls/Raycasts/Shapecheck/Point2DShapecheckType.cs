﻿
using UnityEngine;
using System.Collections.Generic;

namespace GamingIsLove.Makinom
{
	[EditorSettingInfo("Point 2D", "Checks if colliders overlap a point in space (uses 'COllider2D').")]
	public class Point2DShapecheckType<T> : BaseShapecheckType<T> where T : IObjectSelection, new()
	{
		[EditorTitleLabel("Point")]
		[EditorLabel("A point in world space.\n" +
			"Ignores the Z-axis.")]
		public Vector3Value<T> origin = new Vector3Value<T>();


		// depth
		[EditorHelp("Minimum Depth", "Only include objects with a Z coordinate (depth) greater than this value.", "")]
		[EditorSeparator]
		[EditorTitleLabel("Minimum Depth")]
		public FloatValue<T> minDepth = new FloatValue<T>(typeof(FloatValue_NegativeInfinityType<T>));

		[EditorHelp("Maximum Depth", "Only include objects with a Z coordinate (depth) less than this value.", "")]
		[EditorSeparator]
		[EditorTitleLabel("Maximum Depth")]
		public FloatValue<T> maxDepth = new FloatValue<T>(typeof(FloatValue_InfinityType<T>));

		public Point2DShapecheckType()
		{

		}

		public override string ToString()
		{
			return "Point 2D";
		}

		public override bool Is2D
		{
			get { return true; }
		}

		public override bool Check(IDataCall call, int layerMask)
		{
			return Physics2D.OverlapPoint(
				this.origin.GetValue(call), layerMask,
				this.minDepth.GetValue(call), this.maxDepth.GetValue(call)) != null;
		}

		public override Collider Overlap(IDataCall call, int layerMask)
		{
			return null;
		}

		public override Collider[] OverlapAll(IDataCall call, int layerMask)
		{
			return null;
		}

		public override Collider2D Overlap2D(IDataCall call, int layerMask)
		{
			return Physics2D.OverlapPoint(
				this.origin.GetValue(call), layerMask,
				this.minDepth.GetValue(call), this.maxDepth.GetValue(call));
		}

		public override Collider2D[] OverlapAll2D(IDataCall call, int layerMask)
		{
			return Physics2D.OverlapPointAll(
				this.origin.GetValue(call), layerMask,
				this.minDepth.GetValue(call), this.maxDepth.GetValue(call));
		}
	}
}
