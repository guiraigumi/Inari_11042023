
using UnityEngine;
using GamingIsLove.Makinom.Schematics;
using GamingIsLove.Makinom.Components;
using System.Collections.Generic;

namespace GamingIsLove.Makinom
{
	public class ControlMachineSetting : BaseData
	{
		[EditorHelp("Blocked By", "Select when this custom control will be blocked:\n" +
			"- None: This control won't be blocked.\n" +
			"- Player: When the player control is blocked.\n" +
			"- Camera: When the camera control is blocked.\n" +
			"- Both: When the player or camera control is blocked.", "")]
		public ControlBlockType blockType = ControlBlockType.None;

		[EditorHelp("Placed On", "Select on which object this custom control will be added/searched:\n" +
			"- Player: On the player's game object.\n" +
			"- Camera: On the main camera's game object.\n" +
			"- Game: On the persistant game object managing Makinom (alive in all scenes and at all times).", "")]
		public ControlPlaceType placeType = ControlPlaceType.Player;


		// placement
		[EditorHelp("From Root", "Adding the machine component will start from the root of the game object.\n" +
			"Use this option if the game object isn't the real root.", "")]
		[EditorSeparator]
		public bool fromRoot = false;

		[EditorHelp("On Child", "The machine component will be added to a a child object of the game object (e.g. Path/to/Child).\n" +
			"Leave empty if you don't want to use a child object.", "")]
		[EditorWidth(true)]
		public string childName = "";


		// machine settings
		[EditorHelp("Use Template", "Use a machine template to add the machine component.", "")]
		[EditorSeparator]
		public bool useTemplate = true;

		[EditorHelp("Machine Template", "Select the machine template that will be used.", "")]
		[EditorCondition("useTemplate", true)]
		[EditorAutoInit]
		public AssetSelection<MachineTemplateAsset> template;

		[EditorSeparator]
		[EditorElseCondition]
		[EditorEndCondition]
		[EditorAutoInit]
		public MachineComponentSetup machineSetup;

		public ControlMachineSetting()
		{

		}

		public void Add(GameObject gameObject)
		{
			if(gameObject != null)
			{
				if(this.fromRoot)
				{
					gameObject = gameObject.transform.root.gameObject;
				}
				if(this.childName != "")
				{
					gameObject = TransformHelper.GetChildObject(this.childName, gameObject);
				}

				BaseMachineComponent comp = null;
				if(this.useTemplate)
				{
					MachineTemplateAsset asset = this.template;
					comp = asset != null ? asset.Settings.machineSetup.AddComponent(gameObject) : null;
				}
				else
				{
					comp = this.machineSetup.AddComponent(gameObject);
				}

				if(comp != null)
				{
					if(ControlBlockType.Player == this.blockType)
					{
						Maki.Control.AddPlayerControl(comp);
					}
					else if(ControlBlockType.Camera == this.blockType)
					{
						Maki.Control.AddCameraControl(comp);
					}
					else if(ControlBlockType.Both == this.blockType)
					{
						Maki.Control.AddPlayerControl(comp);
						Maki.Control.AddCameraControl(comp);
					}
				}
			}
		}

		public void Remove(GameObject gameObject)
		{
			if(gameObject != null)
			{
				if(this.fromRoot)
				{
					gameObject = gameObject.transform.root.gameObject;
				}
				if(this.childName != "")
				{
					gameObject = TransformHelper.GetChildObject(this.childName, gameObject);
				}

				BaseMachineComponent comp = null;
				if(this.useTemplate)
				{
					MachineTemplateAsset asset = this.template;
					comp = asset != null ? asset.Settings.machineSetup.GetComponent(gameObject) : null;
				}
				else
				{
					comp = this.machineSetup.GetComponent(gameObject);
				}

				if(comp != null)
				{
					if(ControlBlockType.Player == this.blockType)
					{
						Maki.Control.RemovePlayerControl(comp);
					}
					else if(ControlBlockType.Camera == this.blockType)
					{
						Maki.Control.RemoveCameraControl(comp);
					}
					else if(ControlBlockType.Both == this.blockType)
					{
						Maki.Control.RemovePlayerControl(comp);
						Maki.Control.RemoveCameraControl(comp);
					}
					GameObject.Destroy(comp);
				}
			}
		}
	}
}

