
using UnityEngine;
using GamingIsLove.Makinom.Components;
using System.Collections.Generic;

namespace GamingIsLove.Makinom
{
	public class ControlSettings : BaseData
	{
		[EditorFoldout("Collision Camera Settings", "Optionally enable using a collision camera.", "")]
		[EditorEndFoldout]
		public CollisionCameraSetting collisionCamera = new CollisionCameraSetting();

		// control machines
		[EditorFoldout("Control Machines", "Automatically add machine components as controls " +
			"to the player or main camera.\n" +
			"Control machine components will be automatically enabled/disabled " +
			"when the selected control state changes.", "")]
		[EditorEndFoldout]
		[EditorArray("Add Control Machine", "Adds a control machine.\n" +
			"Control machine components will be automatically enabled/disabled when the selected control state changes.", "",
			"Remove", "Removes the control machine.", "", isCopy=true, isMove=true,
			foldout=true, foldoutText=new string[] {
				"Control Machine", "Define the schematic and machine component settings.", ""
		})]
		public ControlMachineSetting[] controlMachine = new ControlMachineSetting[0];

		[EditorFoldout("Control Behaviours", "Automatically add/find custom control behaviour components to the player or main camera.\n" +
			"Control behaviour components will be automatically enabled/disabled when the selected control state changes.\n" +
			"Use custom control behaviour components to implement your own control scripts into Makinom's control block system.", "")]
		[EditorEndFoldout]
		[EditorArray("Add Custom Control", "Adds a control behaviour component.\n" +
			"Control behaviour components will be automatically enabled/disabled when the selected control state changes.", "",
			"Remove", "Removes the control behaviour component.", "", isCopy=true, isMove=true,
			foldout=true, foldoutText=new string[] {
				"Control Behaviour", "Define the name and settings of the custom control behaviour component.", ""
		})]
		public ControlBehaviour[] behaviours = new ControlBehaviour[0];

		public ControlSettings()
		{

		}


		/*
		============================================================================
		Component functions
		============================================================================
		*/
		public void Add(GameObject gameObject, ControlPlaceType placeType)
		{
			NoControl check = gameObject.GetComponent<NoControl>();
			if(check == null)
			{
				if(ControlPlaceType.Camera == placeType)
				{
					this.collisionCamera.Add(gameObject);
				}

				// control machines
				for(int i = 0; i < this.controlMachine.Length; i++)
				{
					if(placeType == this.controlMachine[i].placeType)
					{
						this.controlMachine[i].Add(gameObject);
					}
				}

				// control behaviours
				for(int i = 0; i < this.behaviours.Length; i++)
				{
					if(placeType == this.behaviours[i].placeType)
					{
						this.behaviours[i].Add(gameObject);
					}
				}
			}
		}

		public void Remove(GameObject gameObject, ControlPlaceType placeType)
		{
			NoControl check = gameObject.GetComponent<NoControl>();
			if(check == null)
			{
				if(ControlPlaceType.Camera == placeType)
				{
					this.collisionCamera.Remove(gameObject);
				}

				// control machines
				for(int i = 0; i < this.controlMachine.Length; i++)
				{
					if(placeType == this.controlMachine[i].placeType)
					{
						this.controlMachine[i].Remove(gameObject);
					}
				}

				// control behaviours
				for(int i = 0; i < this.behaviours.Length; i++)
				{
					if(placeType == this.behaviours[i].placeType)
					{
						this.behaviours[i].Remove(gameObject);
					}
				}
			}
		}
	}
}
