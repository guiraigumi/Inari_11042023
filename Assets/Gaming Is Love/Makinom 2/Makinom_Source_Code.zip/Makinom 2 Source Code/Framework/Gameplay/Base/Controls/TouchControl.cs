
using UnityEngine;
using System.Collections.Generic;

namespace GamingIsLove.Makinom
{
	public class TouchControl
	{
		private Dictionary<int, Vector2> start = new Dictionary<int, Vector2>();

		private Dictionary<int, Vector2> hold = new Dictionary<int, Vector2>();

		private Dictionary<int, Vector2> end = new Dictionary<int, Vector2>();

		private Dictionary<int, Vector2> delta = new Dictionary<int, Vector2>();

		private HashSet<int> used = new HashSet<int>();

		public TouchControl()
		{

		}

		public void Clear()
		{
			this.start.Clear();
			this.hold.Clear();
			this.end.Clear();
			this.delta.Clear();
			this.used.Clear();
		}

		public bool CanStart(int count)
		{
			return this.start.Count == count && this.used.Count == 0;
		}

		public void GetStarted(bool useFingers, ref List<int> list)
		{
			if(list == null)
			{
				list = new List<int>();
			}
			else if(list.Count > 0)
			{
				list.Clear();
			}
			foreach(KeyValuePair<int, Vector2> pair in this.start)
			{
				list.Add(pair.Key);
				if(!this.hold.ContainsKey(pair.Key))
				{
					this.hold.Add(pair.Key, pair.Value);
				}
			}
			if(useFingers)
			{
				this.start.Clear();
			}
		}

		public void Use(int fingerID)
		{
			if(!this.used.Contains(fingerID))
			{
				this.used.Add(fingerID);
			}
		}

		public Vector2 GetPosition(int fingerID)
		{
			Vector2 tmp;
			if(this.start.TryGetValue(fingerID, out tmp))
			{
				return tmp;
			}
			else if(this.hold.TryGetValue(fingerID, out tmp))
			{
				return tmp;
			}
			else if(this.end.TryGetValue(fingerID, out tmp))
			{
				return tmp;
			}
			return new Vector2(Mathf.Infinity, Mathf.Infinity);
		}

		public Vector2 GetDelta(int fingerID)
		{
			Vector2 tmp;
			if(this.delta.TryGetValue(fingerID, out tmp))
			{
				return tmp;
			}
			return Vector2.zero;
		}

		public Vector2 GetDelta(List<int> fingerID)
		{
			Vector2 value = Vector2.zero;
			int count = 0;
			for(int i = 0; i < fingerID.Count; i++)
			{
				if(this.delta.ContainsKey(fingerID[i]))
				{
					value += this.delta[fingerID[i]];
					count++;
				}
			}
			if(count > 0)
			{
				value /= count;
			}
			return value;
		}

		public bool HasFingerID(int fingerID)
		{
			return this.start.ContainsKey(fingerID) ||
				this.hold.ContainsKey(fingerID) ||
				this.end.ContainsKey(fingerID);
		}

		public bool IsPhase(int fingerID, InputHandling ih)
		{
			return fingerID != -1 &&
				((InputHandling.Down == ih &&
					this.start.ContainsKey(fingerID)) ||
				(InputHandling.Hold == ih &&
					this.hold.ContainsKey(fingerID)) ||
				(InputHandling.Up == ih &&
					this.end.ContainsKey(fingerID)) ||
				(InputHandling.Any == ih &&
					(this.start.ContainsKey(fingerID) ||
					this.hold.ContainsKey(fingerID) ||
					this.end.ContainsKey(fingerID))));
		}

		public bool IsPhase(List<int> fingerID, InputHandling ih)
		{
			for(int i = 0; i < fingerID.Count; i++)
			{
				if(fingerID[i] != -1 &&
					((InputHandling.Down == ih &&
						this.start.ContainsKey(fingerID[i])) ||
					(InputHandling.Hold == ih &&
						this.hold.ContainsKey(fingerID[i])) ||
					(InputHandling.Up == ih &&
						this.end.ContainsKey(fingerID[i]))) ||
					(InputHandling.Any == ih &&
						(this.start.ContainsKey(fingerID[i]) ||
						this.hold.ContainsKey(fingerID[i]) ||
						this.end.ContainsKey(fingerID[i]))))
				{
					return true;
				}
			}
			return false;
		}

		public void Tick()
		{
			Vector2 tmp;
			foreach(int id in this.used)
			{
				if(this.start.TryGetValue(id, out tmp) &&
					!this.hold.ContainsKey(id))
				{
					this.hold.Add(id, tmp);
				}
			}
			this.used.Clear();
			this.start.Clear();
			this.end.Clear();
			this.delta.Clear();

			// touches
			if(Input.touches.Length > 0)
			{
				for(int i = 0; i < Input.touches.Length; i++)
				{
					Touch touch = Input.GetTouch(i);

					// process existing touches
					if(this.hold.ContainsKey(touch.fingerId))
					{
						if(touch.phase == TouchPhase.Moved)
						{
							this.hold[touch.fingerId] = touch.position;
							this.delta.Add(touch.fingerId, touch.deltaPosition);
						}
						else if(touch.phase == TouchPhase.Ended || touch.phase == TouchPhase.Canceled)
						{
							if(this.hold.ContainsKey(touch.fingerId))
							{
								this.hold.Remove(touch.fingerId);
							}
							this.end.Add(touch.fingerId, touch.position);
						}
					}
					// new touch
					else if(touch.phase == TouchPhase.Began)
					{
						this.start.Add(touch.fingerId, touch.position);
					}
				}
			}
			// mouse
			else
			{
				// process existing clicks
				if(this.hold.ContainsKey(-2))
				{
					if(Input.GetMouseButton(0))
					{
						this.hold[-2] = Input.mousePosition;
					}
					else if(Input.GetMouseButtonUp(0))
					{
						if(this.hold.ContainsKey(-2))
						{
							this.hold.Remove(-2);
						}
						this.end.Add(-2, Input.mousePosition);
					}
				}
				// new click
				else if(Input.GetMouseButtonDown(0))
				{
					this.start.Add(-2, Input.mousePosition);
				}
			}
		}
	}
}
