﻿
using UnityEngine;
using System.Collections.Generic;

namespace GamingIsLove.Makinom
{
	public abstract class BaseFadeFloatSettings : BaseData
	{
		public abstract bool FromCurrent
		{
			get;
		}

		public abstract void SwapValues();
	}

	public class FadeFloatSettings<T> : BaseFadeFloatSettings where T : IObjectSelection, new()
	{
		[EditorHelp("Time (s)", "The time in seconds used for fading.", "")]
		public FloatValue<T> time = new FloatValue<T>(0.25f);

		public Interpolation interpolation = new Interpolation();


		// start value
		[EditorHelp("From Current", "The current float value will be used as start value.\n" +
			"If disabled, a defined value is used.", "")]
		[EditorSeparator]
		public bool fromCurrent = false;

		[EditorHelp("Start Value", "Define the value that will be faded from.", "")]
		[EditorCondition("fromCurrent", false)]
		[EditorEndCondition]
		[EditorCallback("button:fadeswap", EditorCallbackType.InstanceBefore)]
		public FloatValue<T> startValue = new FloatValue<T>();


		// end value
		[EditorHelp("End Value", "Define the value that will be faded to.", "")]
		[EditorSeparator]
		public FloatValue<T> endValue = new FloatValue<T>(1);

		public FadeFloatSettings()
		{

		}

		public FadeFloatSettings(float time, float startValue, float endValue)
		{
			this.time = new FloatValue<T>(time);
			this.startValue = new FloatValue<T>(startValue);
			this.endValue = new FloatValue<T>(endValue);
		}

		public virtual FadeFloat Create(FadeType fadeType, float currentValue,
			SetFloat setValue, GetFloat deltaTime, bool inPause, IDataCall call)
		{
			return this.Create(1, fadeType, currentValue, setValue, deltaTime, inPause, call);
		}

		public virtual FadeFloat Create(float timeFactor, FadeType fadeType, float currentValue,
			SetFloat setValue, GetFloat deltaTime, bool inPause, IDataCall call)
		{
			return new FadeFloat(fadeType,
				this.time.GetValue(call) * timeFactor,
				currentValue,
				this.fromCurrent ? currentValue : this.startValue.GetValue(call),
				this.endValue.GetValue(call),
				this.interpolation, setValue, deltaTime, inPause);
		}

		public override bool FromCurrent
		{
			get { return this.fromCurrent; }
		}

		public override void SwapValues()
		{
			FloatValue<T> tmp = this.startValue;
			this.startValue = this.endValue;
			this.endValue = tmp;
		}
	}
}
