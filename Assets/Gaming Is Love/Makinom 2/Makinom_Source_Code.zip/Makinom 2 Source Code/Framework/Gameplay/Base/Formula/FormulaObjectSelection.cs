
using UnityEngine;
using GamingIsLove.Makinom.Components;
using System.Collections.Generic;

namespace GamingIsLove.Makinom.Formulas
{
	public enum FormulaObjectType
	{
		User, Target, Player,
		SelectedData, SelectedObject,
		GridRoot, GridCell
	}

	[HighlightSettings(4)]
	public class FormulaObjectSelection : BaseData, IObjectSelection
	{
		[EditorHelp("Game Object", "Select the game object that will be used:\n" +
			"- User: The user of the formula.\n" +
			"- Target: The target of the formula.\n" +
			"- Player: The player. If there is no player, no object will be used.\n" +
			"- Selected Data: Game object(s) stored in selected data. If none is found, no object will be used.\n" +
			"- Selected Object: The currently selected object " +
			"(see 'Base/Control > Game Controls > Object Selection' for details).\n" +
			"- Grid Root: The root game object of a grid.\n" +
			"- Grid Cell: The game object(s) of grid cells.", "")]
		public FormulaObjectType type = FormulaObjectType.User;


		// selected data
		[EditorCondition("type", FormulaObjectType.SelectedData)]
		[EditorAutoInit]
		public SelectedData<FormulaObjectSelection> selectedData;

		[EditorHelp("Only Game Objects", "Only use actual stored game objects, " +
			"e.g. game objects of stored components will not be used.", "")]
		[EditorEndCondition]
		public bool selectedOnlyGameObjects = false;


		// grid root
		[EditorHelp("Grid Key", "The key used to store the grid.\n" +
			"You can store multiple grids by using different keys.", "")]
		[EditorCondition("type", FormulaObjectType.GridRoot)]
		[EditorEndCondition]
		[EditorAutoInit]
		public StringValue<FormulaObjectSelection> gridKey;


		// grid cell
		[EditorCondition("type", FormulaObjectType.GridCell)]
		[EditorEndCondition]
		[EditorAutoInit]
		public GridIndex<FormulaObjectSelection> gridIndex;


		// child object
		[EditorHelp("Use Root", "Use the root of the game object (i.e. the uppermost parent game object).\n" +
			"When using 'Child Object' they'll be searched from the root.", "")]
		public bool useRoot = false;

		[EditorHelp("Child Object", "A child object of the selected object will be used (e.g. Path/to/Child).\n" +
			"Leave empty if you don't want to use a child object.", "")]
		[EditorWidth(true)]
		public string childName = "";

		public FormulaObjectSelection()
		{

		}

		public FormulaObjectSelection(FormulaObjectType type)
		{
			this.type = type;

			if(FormulaObjectType.SelectedData == this.type)
			{
				this.selectedData = new SelectedData<FormulaObjectSelection>();
			}
			else if(FormulaObjectType.GridRoot == this.type)
			{
				this.gridKey = new StringValue<FormulaObjectSelection>();
			}
			else if(FormulaObjectType.GridCell == this.type)
			{
				this.gridIndex = new GridIndex<FormulaObjectSelection>();
			}
		}

		public bool Equals(FormulaObjectSelection check)
		{
			if(this.useRoot == check.useRoot &&
				this.childName == check.childName)
			{
				if(FormulaObjectType.SelectedData == this.type)
				{
					return this.selectedOnlyGameObjects == check.selectedOnlyGameObjects &&
						this.selectedData.Equals(check.selectedData);
				}
				else if(FormulaObjectType.GridRoot == this.type)
				{
					return this.gridKey.Equals(check.gridKey);
				}
				else if(FormulaObjectType.GridCell == this.type)
				{
					return this.gridIndex.Equals(check.gridIndex);
				}
				else
				{
					return this.type == check.type;
				}
			}
			return false;
		}


		/*
		============================================================================
		Formula object functions
		============================================================================
		*/
		public object GetFormulaObject(IDataCall call)
		{
			return this.GetFormulaObject(call as FormulaCall);
		}

		public object GetFormulaObject(FormulaCall call)
		{
			if(call != null)
			{
				if(FormulaObjectType.User == this.type)
				{
					return call.User;
				}
				else if(FormulaObjectType.Target == this.type)
				{
					return call.Target;
				}
				else if(FormulaObjectType.Player == this.type)
				{
					return Maki.Game.Player.FormulaObject;
				}
				else
				{
					return this.GetObject(call);
				}
			}
			return null;
		}


		/*
		============================================================================
		Game object functions
		============================================================================
		*/
		public GameObject GetObject(IDataCall call)
		{
			return this.GetObject(call as FormulaCall);
		}

		public GameObject GetObject(FormulaCall call)
		{
			GameObject gameObject = null;
			if(call != null)
			{
				if(FormulaObjectType.User == this.type)
				{
					gameObject = call.UserGameObject;
				}
				else if(FormulaObjectType.Target == this.type)
				{
					gameObject = call.TargetGameObject;
				}
				else if(FormulaObjectType.Player == this.type)
				{
					gameObject = Maki.Game.Player.GameObject;
				}
				else if(FormulaObjectType.SelectedData == this.type)
				{
					List<SelectedDataHandler> handlers = this.selectedData.GetHandlers(call);
					if(handlers.Count > 0)
					{
						string tmpKey = this.selectedData.key.GetValue(call);
						for(int i = 0; i < handlers.Count; i++)
						{
							if(handlers[i] != null)
							{
								gameObject = this.selectedOnlyGameObjects ?
									handlers[i].GetOnlyGameObject(tmpKey) :
									handlers[i].GetGameObject(tmpKey);
								if(gameObject != null)
								{
									break;
								}
							}
						}
					}
					Maki.Pooling.SelectedDataHandlerLists.Add(handlers);
				}
				else if(FormulaObjectType.SelectedObject == this.type)
				{
					if(Maki.Game.Interactions.Selected != null)
					{
						gameObject = Maki.Game.Interactions.Selected.gameObject;
					}
				}
				else if(FormulaObjectType.GridRoot == this.type)
				{
					GameObjectGrid grid = Maki.Game.GetGrid(this.gridKey.GetValue(call));
					if(grid != null)
					{
						gameObject = grid.GameObject;
					}
				}
				else if(FormulaObjectType.GridCell == this.type)
				{
					gameObject = this.gridIndex.GetFirstCellObject(call);
				}

				if(gameObject != null)
				{
					if(this.useRoot)
					{
						gameObject = gameObject.transform.root.gameObject;
					}
					if(this.childName != "")
					{
						gameObject = TransformHelper.GetChildObject(this.childName, gameObject);
					}
				}
			}
			return gameObject;
		}

		public List<GameObject> GetObjects(IDataCall call)
		{
			return this.GetObjects(call as FormulaCall);
		}

		public List<GameObject> GetObjects(FormulaCall call)
		{
			List<GameObject> list = null;
			if(call != null)
			{
				if(FormulaObjectType.User == this.type)
				{
					if(call.UserGameObject != null)
					{
						list = Maki.Pooling.GameObjectLists.Get();
						list.Add(call.UserGameObject);
					}
				}
				else if(FormulaObjectType.Target == this.type)
				{
					if(call.TargetGameObject != null)
					{
						list = Maki.Pooling.GameObjectLists.Get();
						list.Add(call.TargetGameObject);
					}
				}
				else if(FormulaObjectType.Player == this.type)
				{
					if(Maki.Game.Player.GameObject != null)
					{
						list = Maki.Pooling.GameObjectLists.Get();
						list.Add(Maki.Game.Player.GameObject);
					}
				}
				else if(FormulaObjectType.SelectedData == this.type)
				{
					List<SelectedDataHandler> handlers = this.selectedData.GetHandlers(call);
					if(handlers.Count > 0)
					{
						list = Maki.Pooling.GameObjectLists.Get();
						string tmpKey = this.selectedData.key.GetValue(call);
						for(int i = 0; i < handlers.Count; i++)
						{
							if(handlers[i] != null)
							{
								if(this.selectedOnlyGameObjects)
								{
									handlers[i].GetOnlyGameObjects(tmpKey, ref list);
								}
								else
								{
									handlers[i].GetGameObjects(tmpKey, ref list);
								}
							}
						}
					}
					Maki.Pooling.SelectedDataHandlerLists.Add(handlers);
				}
				else if(FormulaObjectType.SelectedObject == this.type)
				{
					if(Maki.Game.Interactions.Selected != null)
					{
						list = Maki.Pooling.GameObjectLists.Get();
						list.Add(Maki.Game.Interactions.Selected.gameObject);
					}
				}
				else if(FormulaObjectType.GridRoot == this.type)
				{
					GameObjectGrid grid = Maki.Game.GetGrid(this.gridKey.GetValue(call));
					if(grid != null && grid.GameObject != null)
					{
						list = Maki.Pooling.GameObjectLists.Get();
						list.Add(grid.GameObject);
					}
				}
				else if(FormulaObjectType.GridCell == this.type)
				{
					list = Maki.Pooling.GameObjectLists.Get();
					this.gridIndex.GetCellObjects(ref list, call);
				}
			}

			if(list == null)
			{
				list = Maki.Pooling.GameObjectLists.Get();
			}
			else if(list.Count > 0)
			{
				if(this.useRoot)
				{
					for(int i = 0; i < list.Count; i++)
					{
						list[i] = list[i].transform.root.gameObject;
					}
				}
				if(this.childName != "")
				{
					for(int i = 0; i < list.Count; i++)
					{
						list[i] = TransformHelper.GetChildObject(this.childName, list[i]);
					}
				}
			}
			return list;
		}


		/*
		============================================================================
		Component functions
		============================================================================
		*/
		public T GetFirstComponent<T>(IDataCall call, ComponentScopeSingle scope) where T : Component
		{
			return this.GetFirstComponent<T>(call as FormulaCall, scope);
		}

		public T GetFirstComponent<T>(FormulaCall call, ComponentScopeSingle scope) where T : Component
		{
			List<GameObject> list = null;
			GameObject gameObject = null;

			if(call != null)
			{
				if(FormulaObjectType.User == this.type)
				{
					if(call.UserGameObject != null)
					{
						gameObject = call.UserGameObject;
					}
				}
				else if(FormulaObjectType.Target == this.type)
				{
					if(call.TargetGameObject != null)
					{
						gameObject = call.TargetGameObject;
					}
				}
				else if(FormulaObjectType.Player == this.type)
				{
					if(Maki.Game.Player.GameObject != null)
					{
						gameObject = Maki.Game.Player.GameObject;
					}
				}
				else if(FormulaObjectType.SelectedData == this.type)
				{
					List<SelectedDataHandler> handlers = this.selectedData.GetHandlers(call);
					if(handlers.Count > 0)
					{
						if(this.selectedOnlyGameObjects)
						{
							list = Maki.Pooling.GameObjectLists.Get();
						}
						string tmpKey = this.selectedData.key.GetValue(call);
						for(int i = 0; i < handlers.Count; i++)
						{
							if(handlers[i] != null)
							{
								if(this.selectedOnlyGameObjects)
								{
									handlers[i].GetOnlyGameObjects(tmpKey, ref list);
								}
								else
								{
									T component = handlers[i].GetComponent<T>(
										tmpKey, ComponentHelper.FromSingleScope(scope));
									if(component != null)
									{
										Maki.Pooling.SelectedDataHandlerLists.Add(handlers);
										return component;
									}
								}
							}
						}
					}
					Maki.Pooling.SelectedDataHandlerLists.Add(handlers);
				}
				else if(FormulaObjectType.SelectedObject == this.type)
				{
					if(Maki.Game.Interactions.Selected != null)
					{
						gameObject = Maki.Game.Interactions.Selected.gameObject;
					}
				}
				else if(FormulaObjectType.GridRoot == this.type)
				{
					GameObjectGrid grid = Maki.Game.GetGrid(this.gridKey.GetValue(call));
					if(grid != null && grid.GameObject != null)
					{
						gameObject = grid.GameObject;
					}
				}
				else if(FormulaObjectType.GridCell == this.type)
				{
					list = Maki.Pooling.GameObjectLists.Get();
					this.gridIndex.GetCellObjects(ref list, call);
				}
			}

			if(gameObject != null)
			{
				if(this.useRoot)
				{
					gameObject = gameObject.transform.root.gameObject;
				}
				if(this.childName != "")
				{
					gameObject = TransformHelper.GetChildObject(this.childName, gameObject);
				}

				T comp = ComponentHelper.Get<T>(gameObject, scope);
				if(comp != null)
				{
					return comp;
				}
			}
			else if(list != null)
			{
				if(list.Count > 0)
				{
					if(this.useRoot)
					{
						for(int i = 0; i < list.Count; i++)
						{
							list[i] = list[i].transform.root.gameObject;
						}
					}
					if(this.childName != "")
					{
						for(int i = 0; i < list.Count; i++)
						{
							list[i] = TransformHelper.GetChildObject(this.childName, list[i]);
						}
					}

					T comp = ComponentHelper.Get<T>(list, scope);
					if(comp != null)
					{
						Maki.Pooling.GameObjectLists.Add(list);
						return comp;
					}
				}
				Maki.Pooling.GameObjectLists.Add(list);
			}
			return null;
		}

		public List<Component> GetAllComponents(FormulaCall call, ComponentScope scope, string componentName)
		{
			List<Component> components = null;
			List<GameObject> list = null;
			GameObject gameObject = null;

			if(FormulaObjectType.User == this.type)
			{
				if(call.UserGameObject != null)
				{
					gameObject = call.UserGameObject;
				}
			}
			else if(FormulaObjectType.Target == this.type)
			{
				if(call.TargetGameObject != null)
				{
					gameObject = call.TargetGameObject;
				}
			}
			else if(FormulaObjectType.Player == this.type)
			{
				if(Maki.Game.Player.GameObject != null)
				{
					gameObject = Maki.Game.Player.GameObject;
				}
			}
			else if(FormulaObjectType.SelectedData == this.type)
			{
				List<SelectedDataHandler> handlers = this.selectedData.GetHandlers(call);
				if(handlers.Count > 0)
				{
					if(this.selectedOnlyGameObjects)
					{
						list = Maki.Pooling.GameObjectLists.Get();
					}
					else
					{
						components = new List<Component>();
					}
					string tmpKey = this.selectedData.key.GetValue(call);
					for(int i = 0; i < handlers.Count; i++)
					{
						if(handlers[i] != null)
						{
							if(this.selectedOnlyGameObjects)
							{
								handlers[i].GetOnlyGameObjects(tmpKey, ref list);
							}
							else
							{
								handlers[i].GetComponents(tmpKey, ref components, scope, componentName);
							}
						}
					}
				}
				Maki.Pooling.SelectedDataHandlerLists.Add(handlers);
			}
			else if(FormulaObjectType.SelectedObject == this.type)
			{
				if(Maki.Game.Interactions.Selected != null)
				{
					gameObject = Maki.Game.Interactions.Selected.gameObject;
				}
			}
			else if(FormulaObjectType.GridRoot == this.type)
			{
				GameObjectGrid grid = Maki.Game.GetGrid(this.gridKey.GetValue(call));
				if(grid != null && grid.GameObject != null)
				{
					gameObject = grid.GameObject;
				}
			}
			else if(FormulaObjectType.GridCell == this.type)
			{
				list = Maki.Pooling.GameObjectLists.Get();
				this.gridIndex.GetCellObjects(ref list, call);
			}

			if(gameObject != null)
			{
				if(this.useRoot)
				{
					gameObject = gameObject.transform.root.gameObject;
				}
				if(this.childName != "")
				{
					gameObject = TransformHelper.GetChildObject(this.childName, gameObject);
				}

				components = new List<Component>();
				if(ComponentHelper.IsSingleScope(scope))
				{
					Component comp = ComponentHelper.GetSingle(gameObject, scope, componentName);
					if(comp != null)
					{
						components.Add(comp);
					}
				}
				else
				{
					Component[] comps = ComponentHelper.GetAll(gameObject, scope, componentName);
					if(comps != null)
					{
						components.AddRange(comps);
					}
				}
			}
			else if(list != null)
			{
				if(list.Count > 0)
				{
					if(this.useRoot)
					{
						for(int i = 0; i < list.Count; i++)
						{
							list[i] = list[i].transform.root.gameObject;
						}
					}
					if(this.childName != "")
					{
						for(int i = 0; i < list.Count; i++)
						{
							list[i] = TransformHelper.GetChildObject(this.childName, list[i]);
						}
					}

					components = ComponentHelper.Get(list, scope, componentName);
				}
				Maki.Pooling.GameObjectLists.Add(list);
			}
			if(components == null)
			{
				components = new List<Component>();
			}
			return components;
		}


		/*
		============================================================================
		Object variables functions
		============================================================================
		*/
		public void GetObjectVariables(IDataCall call, List<VariableHandler> handlers, ComponentScope scope)
		{
			this.GetObjectVariables(call as FormulaCall, handlers, scope);
		}

		public void GetObjectVariables(FormulaCall call, List<VariableHandler> handlers, ComponentScope scope)
		{
			List<GameObject> list = null;
			GameObject gameObject = null;

			if(call != null)
			{
				if(FormulaObjectType.User == this.type)
				{
					if(call.UserGameObject != null)
					{
						gameObject = call.UserGameObject;
					}
					else if(call.User != null)
					{
						VariableHandler handler = ComponentHelper.ToVariableHandler(call.User);
						if(handler != null)
						{
							handlers.Add(handler);
						}
					}
				}
				else if(FormulaObjectType.Target == this.type)
				{
					if(call.TargetGameObject != null)
					{
						gameObject = call.TargetGameObject;
					}
					else if(call.Target != null)
					{
						VariableHandler handler = ComponentHelper.ToVariableHandler(call.Target);
						if(handler != null)
						{
							handlers.Add(handler);
						}
					}
				}
				else if(FormulaObjectType.Player == this.type)
				{
					if(Maki.Game.Player.GameObject != null)
					{
						gameObject = Maki.Game.Player.GameObject;
					}
					else if(Maki.Game.Player.FormulaObject != null)
					{
						VariableHandler handler = ComponentHelper.ToVariableHandler(Maki.Game.Player.FormulaObject);
						if(handler != null)
						{
							handlers.Add(handler);
						}
					}
				}
				else if(FormulaObjectType.SelectedData == this.type)
				{
					List<SelectedDataHandler> tmp = this.selectedData.GetHandlers(call);
					if(tmp.Count > 0)
					{
						if(this.selectedOnlyGameObjects)
						{
							list = Maki.Pooling.GameObjectLists.Get();
						}
						string tmpKey = this.selectedData.key.GetValue(call);
						for(int i = 0; i < tmp.Count; i++)
						{
							if(tmp[i] != null)
							{
								if(this.selectedOnlyGameObjects)
								{
									tmp[i].GetOnlyGameObjects(tmpKey, ref list);
								}
								else
								{
									tmp[i].GetVariableHandlers(tmpKey, ref handlers, scope);
								}
							}
						}
					}
					Maki.Pooling.SelectedDataHandlerLists.Add(tmp);
				}
				else if(FormulaObjectType.SelectedObject == this.type)
				{
					if(Maki.Game.Interactions.Selected != null)
					{
						gameObject = Maki.Game.Interactions.Selected.gameObject;
					}
				}
				else if(FormulaObjectType.GridRoot == this.type)
				{
					GameObjectGrid grid = Maki.Game.GetGrid(this.gridKey.GetValue(call));
					if(grid != null && grid.GameObject != null)
					{
						gameObject = grid.GameObject;
					}
				}
				else if(FormulaObjectType.GridCell == this.type)
				{
					list = Maki.Pooling.GameObjectLists.Get();
					this.gridIndex.GetCellObjects(ref list, call);
				}
			}

			if(gameObject != null)
			{
				if(this.useRoot)
				{
					gameObject = gameObject.transform.root.gameObject;
				}
				if(this.childName != "")
				{
					gameObject = TransformHelper.GetChildObject(this.childName, gameObject);
				}

				if(ComponentHelper.IsSingleScope(scope))
				{
					ObjectVariablesComponent comp = ComponentHelper.
						GetSingle<ObjectVariablesComponent>(gameObject, scope);
					if(comp != null &&
						!handlers.Contains(comp.Handler))
					{
						handlers.Add(comp.Handler);
					}
				}
				else
				{
					ObjectVariablesComponent[] comps = ComponentHelper.
						GetAll<ObjectVariablesComponent>(gameObject, scope);
					if(comps != null)
					{
						for(int j = 0; j < comps.Length; j++)
						{
							if(!handlers.Contains(comps[j].Handler))
							{
								handlers.Add(comps[j].Handler);
							}
						}
					}
				}
			}
			else if(list != null)
			{
				if(list.Count > 0)
				{
					if(this.useRoot)
					{
						for(int i = 0; i < list.Count; i++)
						{
							list[i] = list[i].transform.root.gameObject;
						}
					}
					if(this.childName != "")
					{
						for(int i = 0; i < list.Count; i++)
						{
							list[i] = TransformHelper.GetChildObject(this.childName, list[i]);
						}
					}

					if(ComponentHelper.IsSingleScope(scope))
					{
						for(int i = 0; i < list.Count; i++)
						{
							ObjectVariablesComponent comp = ComponentHelper.
								GetSingle<ObjectVariablesComponent>(list[i], scope);
							if(comp != null &&
								!handlers.Contains(comp.Handler))
							{
								handlers.Add(comp.Handler);
							}
						}
					}
					else
					{
						for(int i = 0; i < list.Count; i++)
						{
							ObjectVariablesComponent[] comps = ComponentHelper.
								GetAll<ObjectVariablesComponent>(list[i], scope);
							if(comps != null)
							{
								for(int j = 0; j < comps.Length; j++)
								{
									if(!handlers.Contains(comps[j].Handler))
									{
										handlers.Add(comps[j].Handler);
									}
								}
							}
						}
					}
				}
				Maki.Pooling.GameObjectLists.Add(list);
			}
		}

		public void GetSelectedData(IDataCall call, List<SelectedDataHandler> handlers, ComponentScope scope)
		{
			this.GetSelectedData(call as FormulaCall, handlers, scope);
		}

		public void GetSelectedData(FormulaCall call, List<SelectedDataHandler> handlers, ComponentScope scope)
		{
			List<GameObject> list = null;
			GameObject gameObject = null;

			if(call != null)
			{
				if(FormulaObjectType.User == this.type)
				{
					if(call.UserGameObject != null)
					{
						gameObject = call.UserGameObject;
					}
				}
				else if(FormulaObjectType.Target == this.type)
				{
					if(call.TargetGameObject != null)
					{
						gameObject = call.TargetGameObject;
					}
				}
				else if(FormulaObjectType.Player == this.type)
				{
					if(Maki.Game.Player.GameObject != null)
					{
						gameObject = Maki.Game.Player.GameObject;
					}
				}
				else if(FormulaObjectType.SelectedData == this.type)
				{
					List<SelectedDataHandler> tmp = this.selectedData.GetHandlers(call);
					if(tmp.Count > 0)
					{
						list = Maki.Pooling.GameObjectLists.Get();
						string tmpKey = this.selectedData.key.GetValue(call);
						for(int i = 0; i < tmp.Count; i++)
						{
							if(tmp[i] != null)
							{
								if(this.selectedOnlyGameObjects)
								{
									tmp[i].GetOnlyGameObjects(tmpKey, ref list);
								}
								else
								{
									tmp[i].GetGameObjects(tmpKey, ref list);
								}
							}
						}
					}
					Maki.Pooling.SelectedDataHandlerLists.Add(tmp);
				}
				else if(FormulaObjectType.SelectedObject == this.type)
				{
					if(Maki.Game.Interactions.Selected != null)
					{
						gameObject = Maki.Game.Interactions.Selected.gameObject;
					}
				}
				else if(FormulaObjectType.GridRoot == this.type)
				{
					GameObjectGrid grid = Maki.Game.GetGrid(this.gridKey.GetValue(call));
					if(grid != null && grid.GameObject != null)
					{
						gameObject = grid.GameObject;
					}
				}
				else if(FormulaObjectType.GridCell == this.type)
				{
					list = Maki.Pooling.GameObjectLists.Get();
					this.gridIndex.GetCellObjects(ref list, call);
				}
			}

			if(gameObject != null)
			{
				if(this.useRoot)
				{
					gameObject = gameObject.transform.root.gameObject;
				}
				if(this.childName != "")
				{
					gameObject = TransformHelper.GetChildObject(this.childName, gameObject);
				}

				if(ComponentHelper.IsSingleScope(scope))
				{
					ObjectVariablesComponent comp = ComponentHelper.
						GetSingle<ObjectVariablesComponent>(gameObject, scope);
					if(comp != null &&
						!handlers.Contains(comp.SelectedData))
					{
						handlers.Add(comp.SelectedData);
					}
				}
				else
				{
					ObjectVariablesComponent[] comps = ComponentHelper.
						GetAll<ObjectVariablesComponent>(gameObject, scope);
					if(comps != null)
					{
						for(int j = 0; j < comps.Length; j++)
						{
							if(!handlers.Contains(comps[j].SelectedData))
							{
								handlers.Add(comps[j].SelectedData);
							}
						}
					}
				}
			}
			else if(list != null)
			{
				if(list.Count > 0)
				{
					if(this.useRoot)
					{
						for(int i = 0; i < list.Count; i++)
						{
							list[i] = list[i].transform.root.gameObject;
						}
					}
					if(this.childName != "")
					{
						for(int i = 0; i < list.Count; i++)
						{
							list[i] = TransformHelper.GetChildObject(this.childName, list[i]);
						}
					}

					if(ComponentHelper.IsSingleScope(scope))
					{
						for(int i = 0; i < list.Count; i++)
						{
							ObjectVariablesComponent comp = ComponentHelper.
								GetSingle<ObjectVariablesComponent>(list[i], scope);
							if(comp != null &&
								!handlers.Contains(comp.SelectedData))
							{
								handlers.Add(comp.SelectedData);
							}
						}
					}
					else
					{
						for(int i = 0; i < list.Count; i++)
						{
							ObjectVariablesComponent[] comps = ComponentHelper.
								GetAll<ObjectVariablesComponent>(list[i], scope);
							if(comps != null)
							{
								for(int j = 0; j < comps.Length; j++)
								{
									if(!handlers.Contains(comps[j].SelectedData))
									{
										handlers.Add(comps[j].SelectedData);
									}
								}
							}
						}
					}
				}
				Maki.Pooling.GameObjectLists.Add(list);
			}
		}


		/*
		============================================================================
		Editor functions
		============================================================================
		*/
		public override string ToString()
		{
			if(FormulaObjectType.SelectedData == this.type)
			{
				return this.selectedData.ToString();
			}
			else if(FormulaObjectType.GridRoot == this.type)
			{
				return "Grid Root(" + this.gridKey.ToString() + ")";
			}
			else if(FormulaObjectType.GridCell == this.type)
			{
				return "Grid Cell(" + this.gridIndex.gridKey.ToString() + ")";
			}
			else
			{
				return this.type.ToString();
			}
		}
	}
}
