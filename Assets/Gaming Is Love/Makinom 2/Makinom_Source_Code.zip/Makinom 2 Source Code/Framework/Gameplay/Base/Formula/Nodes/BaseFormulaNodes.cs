
using UnityEngine;
using System.Collections.Generic;

namespace GamingIsLove.Makinom.Formulas.Nodes
{
	[EditorHelp("Layer Gate", "Connects two layers.", "")]
	[NodeInfo("Base")]
	public class FormulaGateNode : BaseFormulaNode
	{
		[EditorHide]
		public int toLayer = 0;

		[EditorHide]
		public Vector2 nodePosition2 = new Vector2(38, 38);

		[EditorHide]
		public int nodeGroup2 = -1;

		public FormulaGateNode()
		{

		}

		public FormulaGateNode(int toLayer)
		{
			this.toLayer = toLayer;
		}

		public override int Calculate(FormulaCall call)
		{
			return this.next;
		}

		public override bool IsConnectable(int layer)
		{
			return this.nodeLayer == layer;
		}


		/*
		============================================================================
		Node name functions
		============================================================================
		*/
		public override string GetNodeDetails()
		{
			return this.toLayer.ToString();
		}

		public override Color EditorColor
		{
			get { return Maki.EditorSettings.layerGateNodeColor; }
		}


		/*
		============================================================================
		Position functions
		============================================================================
		*/
		public override void SetPosition(int layer, Vector2 position)
		{
			if(this.nodeLayer == layer)
			{
				this.nodePosition = position;
			}
			if(this.toLayer == layer)
			{
				this.nodePosition2 = position;
			}
		}

		public override Vector2 GetPosition(int layer)
		{
			if(this.toLayer == layer)
			{
				return this.nodePosition2;
			}
			else
			{
				return this.nodePosition;
			}
		}


		/*
		============================================================================
		Node group functions
		============================================================================
		*/
		public override void SetNodeGroup(int layer, int index)
		{
			if(this.nodeLayer == layer)
			{
				this.nodeGroup = index;
			}
			if(this.toLayer == layer)
			{
				this.nodeGroup2 = index;
			}
		}

		public override int GetNodeGroup(int layer)
		{
			if(this.toLayer == layer)
			{
				return this.nodeGroup2;
			}
			else
			{
				return this.nodeGroup;
			}
		}

		public override void GroupRemoved(int index)
		{
			if(index <= this.nodeGroup)
			{
				this.nodeGroup--;
			}
			if(index <= this.nodeGroup2)
			{
				this.nodeGroup2--;
			}
		}


		/*
		============================================================================
		Layer functions
		============================================================================
		*/
		public override bool IsOnLayer(int layer)
		{
			return this.nodeLayer == layer ||
				this.toLayer == layer;
		}

		public override bool RemoveLayer(int layer)
		{
			if(this.nodeLayer == layer ||
				this.toLayer == layer)
			{
				return true;
			}
			if(this.nodeLayer > layer)
			{
				this.nodeLayer--;
			}
			if(this.toLayer > layer)
			{
				this.toLayer--;
			}
			return false;
		}
	}

	[EditorHelp("Empty", "This is an empty node.\n" +
		"This node being empty can be the result of a " +
		"custom node script not being found (e.g. removed from the project).", "")]
	[NodeInfo("Base")]
	public class EmptyNode : BaseFormulaNode
	{
		private DataObject data;

		public EmptyNode()
		{

		}

		public override void SetData(DataObject data)
		{
			base.SetData(data);
			this.data = data;
		}

		public override DataObject GetData()
		{
			if(this.data == null)
			{
				return base.GetData();
			}
			else
			{
				return this.data;
			}
		}

		public override int Calculate(FormulaCall call)
		{
			return this.next;
		}

		public override Color EditorColor
		{
			get { return Maki.EditorSettings.baseNodeColor; }
		}
	}

	[EditorHelp("Random", "Randomly executes a next node out of a list of defined nodes.", "")]
	[NodeInfo("Base")]
	public class RandomNode : BaseFormulaNode
	{
		[EditorHide]
		[EditorCallback("buttons:randomnode", EditorCallbackType.InstanceBefore)]
		public int[] random = new int[] { -1 };

		public RandomNode()
		{

		}

		public override int Calculate(FormulaCall call)
		{
			return this.random[UnityWrapper.Range(0, this.random.Length)];
		}


		/*
		============================================================================
		Node next functions
		============================================================================
		*/
		public override string GetNextName(int index)
		{
			return "Random " + index;
		}

		public override int GetNextCount()
		{
			return this.random.Length;
		}

		public override int GetNext(int index)
		{
			return this.random[index];
		}

		public override void SetNext(int index, int next)
		{
			this.random[index] = next;
		}

		public override Color EditorColor
		{
			get { return Maki.EditorSettings.baseNodeColor; }
		}
	}

	[EditorHelp("Comment", "Leave a comment in your formula.\n" +
		"This node does nothing and is only for commentary purposes.", "")]
	[NodeInfo("Base")]
	public class CommentNode : BaseFormulaNode
	{
		[EditorHelp("Comment", "The comment.", "")]
		public TextContent comment = new TextContent();

		public CommentNode()
		{

		}

		public override int Calculate(FormulaCall call)
		{
			return this.next;
		}


		/*
		============================================================================
		Node name functions
		============================================================================
		*/
		public override string GetNodeDetails()
		{
			return this.comment.ToString();
		}

		public override Color EditorColor
		{
			get { return Maki.EditorSettings.baseNodeColor; }
		}
	}

	[EditorHelp("Chance", "Which node will be executed next is decided by chance.\n" +
		"The chance is checked against a random number between two values (default 0 and 100, " +
		"you can change this in the game settings).\n" +
		"The next node of the first defined value range, that includes the chance, will be executed.\n" +
		"If no range contains the chance, 'Failed' will be executed.", "")]
	[NodeInfo("Base", "Check")]
	public class ChanceNode : BaseFormulaNode
	{
		[EditorArray("Add Range", "Adds a range for the chance check.", "",
			"Remove", "Removes this range.", "", isCopy = true, isMove = true, noRemoveCount = 1,
			foldout = true, foldoutText = new string[] {
				"Range", "Define the minimum and maximum value of the range.\n" +
				"If the random chance value is within the range (i.e. minimum <= chance <= maximum), " +
				"this range's next node will be executed.", ""
		})]
		public ChanceNextNode<FormulaObjectSelection>[] range = new ChanceNextNode<FormulaObjectSelection>[] {
			new ChanceNextNode<FormulaObjectSelection>()
		};

		public ChanceNode()
		{

		}

		public override int Calculate(FormulaCall call)
		{
			int check = this.next;

			float chance = Maki.GameSettings.GetRandom();

			for(int i = 0; i < this.range.Length; i++)
			{
				if(this.range[i].Contains(chance, call))
				{
					check = this.range[i].next;
					break;
				}
			}

			return check;
		}


		/*
		============================================================================
		Name functions
		============================================================================
		*/
		public override string GetNextName(int index)
		{
			if(index == 0)
			{
				return "Failed";
			}
			else if(index > 0)
			{
				return (index - 1).ToString() + ": " +
					this.range[index - 1].ToString();
			}
			return "";
		}

		public override int GetNextCount()
		{
			return this.range.Length + 1;
		}

		public override int GetNext(int index)
		{
			if(index == 0)
			{
				return this.next;
			}
			else if(index > 0)
			{
				return this.range[index - 1].next;
			}
			return -1;
		}

		public override void SetNext(int index, int next)
		{
			if(index == 0)
			{
				this.next = next;
			}
			else if(index > 0)
			{
				this.range[index - 1].next = next;
			}
		}

		public override Color EditorColor
		{
			get { return Maki.EditorSettings.baseNodeColor; }
		}
	}

	[EditorHelp("Loop", "Increases an int variable by one until it reaches a defined maximum value.\n" +
		"Use this node to easily loop nodes for a number of times before continuing with the rest of the formula.\n" +
		"If the loop finished (i.e. the int variable being max count or larger), 'Finished' will be executed next, otherwise 'Loop'.", "")]
	[NodeInfo("Base")]
	public class LoopNode : BaseFormulaCheckNode
	{
		[EditorHelp("Max Count", "The maximum the loop count can reach.\n" +
			"When the used variable reaches this value, the 'Finished' next slot will be used.", "")]
		public FloatValue<FormulaObjectSelection> maxCount = new FloatValue<FormulaObjectSelection>();


		[EditorTitleLabel("Variable Settings (Counter)")]
		[EditorSeparator]
		[EditorHelp("Reset", "Resets the variable to 0 when the loop finished (i.e. reached the max count).\n" +
			"This will make the loop ready for the next time in case it's reused.", "")]
		public bool reset = true;

		public Variable<FormulaObjectSelection> variable = new Variable<FormulaObjectSelection>(VariableOrigin.Local);

		public LoopNode()
		{

		}

		public override int Calculate(FormulaCall call)
		{
			int tmpCount = 0;
			string key = this.variable.key.GetValue(call);
			List<VariableHandler> list = this.variable.GetHandlers(call);
			for(int i = 0; i < list.Count; i++)
			{
				if(list[i] != null)
				{
					int count = list[i].GetInt(key);
					count++;
					list[i].Set(key, count);

					if(tmpCount < count)
					{
						tmpCount = count;
					}
				}
			}

			if(tmpCount >= this.maxCount.GetValue(call))
			{
				if(this.reset)
				{
					for(int i = 0; i < list.Count; i++)
					{
						if(list[i] != null)
						{
							list[i].Set(key, 0);
						}
					}
				}
				Maki.Pooling.VariableHandlerLists.Add(list);
				return this.next;
			}
			else
			{
				Maki.Pooling.VariableHandlerLists.Add(list);
				return this.nextFail;
			}
		}


		/*
		============================================================================
		Name functions
		============================================================================
		*/
		public override string GetNodeDetails()
		{
			return this.variable.ToString() + ": " + this.maxCount.ToString();
		}

		public override Color EditorColor
		{
			get { return Maki.EditorSettings.baseNodeColor; }
		}

		public override string GetNextName(int index)
		{
			if(index == 0)
			{
				return "Finished";
			}
			else if(index == 1)
			{
				return "Loop";
			}
			return "";
		}
	}

	[EditorHelp("Math Function", "Uses a Mathf function on the current value of the formula.", "")]
	[NodeInfo("Base")]
	public class MathFunctionNode : BaseFormulaNode
	{
		public MathFunction mathFunction = new MathFunction();

		public MathFunctionNode()
		{

		}

		public override void SetData(DataObject data)
		{
			base.SetData(data);
			this.mathFunction.OldDataUpgrade(data, "mathType");
		}

		public override int Calculate(FormulaCall call)
		{
			call.result = this.mathFunction.Use(call.result);
			return this.next;
		}


		/*
		============================================================================
		Node name functions
		============================================================================
		*/
		public override string GetNodeDetails()
		{
			return this.mathFunction.ToString();
		}

		public override Color EditorColor
		{
			get { return Maki.EditorSettings.baseNodeColor; }
		}
	}

	[EditorHelp("Unity Console", "Prints a text to the Unity console using 'Debug.Log()'.", "")]
	[NodeInfo("Base")]
	public class UnityConsoleNode : BaseFormulaNode
	{
		[EditorHelp("Debug Type", "Select the debug type will be used:\n" +
			"- Log: Printed to 'Debug.Log'.\n" +
			"- Warning: Printed to 'Debug.LogWarning'.\n" +
			"- Error: Printed to 'Debug.LogError'.", "")]
		public DebugType type = DebugType.Log;

		[EditorHelp("Value Format", "Define the format the formula value will be printed with.", "")]
		public string format = "0.00";

		[EditorSeparator]
		public VariableOrigin<FormulaObjectSelection> variable = new VariableOrigin<FormulaObjectSelection>();

		[EditorHelp("Text", "The text that will be printed to the Unity console.", "")]
		[EditorSeparator]
		[EditorTitleLabel("Console Output")]
		[EditorLabel("<user> = user name, <target> = target name, <value> = current formula value")]
		public TextContent text = new TextContent();

		public UnityConsoleNode()
		{

		}

		public override int Calculate(FormulaCall call)
		{
			UIText content = new UIText(this.text, null, null, this.variable.GetFirstHandler(call));
			content.Replace("<user>", call.User.ToString());
			content.Replace("<target>", call.Target.ToString());
			content.Replace("<value>", call.result.ToString(this.format));
			if(DebugType.Log == this.type)
			{
				Debug.Log(content.Text);
			}
			else if(DebugType.Warning == this.type)
			{
				Debug.LogWarning(content.Text);
			}
			else if(DebugType.Error == this.type)
			{
				Debug.LogError(content.Text);
			}
			return this.next;
		}


		/*
		============================================================================
		Node name functions
		============================================================================
		*/
		public override string GetNodeDetails()
		{
			return this.text.ToString();
		}

		public override Color EditorColor
		{
			get { return Maki.EditorSettings.baseNodeColor; }
		}
	}

	[EditorHelp("Begin Sub Calculation", "Starts a new calculation as part of the formula (i.e. used as 'left parenthesis').\n" +
		"Everything within a sub calculation will be calculated until it's corresponding 'End Sub Calculation' node " +
		"and added to the previous formula value using the defined operator.\n" +
		"Any open sub calculation will be closed at the end of the formula's calculation, before using the formula's min/max value limits.", "")]
	[NodeInfo("Base")]
	public class BeginSubCalculationNode : BaseFormulaNode
	{
		// operator
		public FloatOperator formulaOperator = new FloatOperator();

		[EditorHelp("Initial Value", "The initial value of the sub calculation.", "")]
		[EditorSeparator]
		public FloatValue<FormulaObjectSelection> value = new FloatValue<FormulaObjectSelection>();

		public BeginSubCalculationNode()
		{

		}

		public override int Calculate(FormulaCall call)
		{
			call.BeginSubCalculation(this.formulaOperator, this.value.GetValue(call));
			return this.next;
		}


		/*
		============================================================================
		Node name functions
		============================================================================
		*/
		public override string GetNodeDetails()
		{
			return this.formulaOperator.ToString() + " (" + this.value.ToString();
		}

		public override Color EditorColor
		{
			get { return Maki.EditorSettings.baseNodeColor; }
		}
	}

	[EditorHelp("End Sub Calculation", "Closes the last opened sub calculation (i.e. used as 'right parenthesis').\n" +
		"The sub calculation's current value (result) will be used to change the previous formula value using it's corresponding 'Begin Sub Calculation' node's operator.", "")]
	[NodeInfo("Base")]
	public class EndSubCalculationNode : BaseFormulaNode
	{
		public EndSubCalculationNode()
		{

		}

		public override int Calculate(FormulaCall call)
		{
			call.EndSubCalculation();
			return this.next;
		}


		/*
		============================================================================
		Node name functions
		============================================================================
		*/
		public override string GetNodeDetails()
		{
			return ")";
		}

		public override Color EditorColor
		{
			get { return Maki.EditorSettings.baseNodeColor; }
		}
	}
}
