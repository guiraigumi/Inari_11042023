
using UnityEngine;
using GamingIsLove.Makinom.Reflection;
using System.Collections.Generic;
using System.Reflection;

namespace GamingIsLove.Makinom.Formulas.Nodes
{
	[EditorHelp("Value", "A single value is used.", "")]
	[NodeInfo("Value")]
	public class ValueNode : BaseFormulaNode
	{
		// operator
		public FloatOperator formulaOperator = new FloatOperator();

		[EditorHelp("Value", "The value that will be used.", "")]
		[EditorSeparator]
		public FloatValue<FormulaObjectSelection> value = new FloatValue<FormulaObjectSelection>();

		public ValueNode()
		{

		}

		public override void SetData(DataObject data)
		{
			base.SetData(data);
			this.formulaOperator.OldDataUpgrade(data, "formulaOperator");
		}

		public override int Calculate(FormulaCall call)
		{
			this.formulaOperator.Use(ref call.result, this.value.GetValue(call));
			return this.next;
		}


		/*
		============================================================================
		Name functions
		============================================================================
		*/
		public override string GetNodeDetails()
		{
			return this.formulaOperator.ToString() + " " + this.value.ToString();
		}

		public override Color EditorColor
		{
			get { return Maki.EditorSettings.valueNodeColor; }
		}
	}

	[EditorHelp("Random Value", "A random value between two values is used.", "")]
	[NodeInfo("Value")]
	public class RandomValueNode : BaseFormulaNode
	{
		// operator
		public FloatOperator formulaOperator = new FloatOperator();

		[EditorHelp("As Int", "The random value will be used as an integer (i.e. whole number).\n" +
			"When generating a random integer, 'Value 2' will be used exclusive.\n" +
			"If disabled, the random value will be a float.", "")]
		public bool asInt = false;

		[EditorHelp("Minimum Value", "The minimum value that will be used.", "")]
		[EditorSeparator]
		public FloatValue<FormulaObjectSelection> min = new FloatValue<FormulaObjectSelection>();

		[EditorHelp("Maximum Value", "The maximum value that will be used.", "")]
		[EditorSeparator]
		public FloatValue<FormulaObjectSelection> max = new FloatValue<FormulaObjectSelection>();

		public RandomValueNode()
		{

		}

		public override void SetData(DataObject data)
		{
			base.SetData(data);
			this.formulaOperator.OldDataUpgrade(data, "formulaOperator");
		}

		public override int Calculate(FormulaCall call)
		{
			float v1 = this.min.GetValue(call);
			float v2 = this.max.GetValue(call);
			if(v1 < v2)
			{
				this.formulaOperator.Use(ref call.result,
					this.asInt ? UnityWrapper.Range((int)v1, (int)v2) : UnityWrapper.Range(v1, v2));
			}
			else if(v1 > v2)
			{
				this.formulaOperator.Use(ref call.result,
					this.asInt ? UnityWrapper.Range((int)v2, (int)v1) : UnityWrapper.Range(v2, v1));
			}
			else
			{
				this.formulaOperator.Use(ref call.result,
					this.asInt ? (int)v1 : v1);
			}
			return this.next;
		}


		/*
		============================================================================
		Name functions
		============================================================================
		*/
		public override string GetNodeDetails()
		{
			return this.formulaOperator.ToString() + " " +
				this.min.ToString() + " ~ " + this.max.ToString();
		}

		public override Color EditorColor
		{
			get { return Maki.EditorSettings.valueNodeColor; }
		}
	}

	[EditorHelp("Minimum Value", "The smaller value of two values is used.", "")]
	[NodeInfo("Value")]
	public class MinimumValueNode : BaseFormulaNode
	{
		// operator
		public FloatOperator formulaOperator = new FloatOperator();

		[EditorHelp("Value 1", "The first value that will be used.", "")]
		[EditorSeparator]
		public FloatValue<FormulaObjectSelection> min = new FloatValue<FormulaObjectSelection>();

		[EditorHelp("Value 2", "The 2nd value that will be used.", "")]
		[EditorSeparator]
		public FloatValue<FormulaObjectSelection> max = new FloatValue<FormulaObjectSelection>();

		public MinimumValueNode()
		{

		}

		public override void SetData(DataObject data)
		{
			base.SetData(data);
			this.formulaOperator.OldDataUpgrade(data, "formulaOperator");
		}

		public override int Calculate(FormulaCall call)
		{
			this.formulaOperator.Use(ref call.result,
				Mathf.Min(this.min.GetValue(call), this.max.GetValue(call)));
			return this.next;
		}


		/*
		============================================================================
		Name functions
		============================================================================
		*/
		public override string GetNodeDetails()
		{
			return this.formulaOperator.ToString() + " min(" +
				this.min.ToString() + ", " + this.max.ToString() + ")";
		}

		public override Color EditorColor
		{
			get { return Maki.EditorSettings.valueNodeColor; }
		}
	}

	[EditorHelp("Maximum Value", "The bigger value of two values is used.", "")]
	[NodeInfo("Value")]
	public class MaximumValueNode : BaseFormulaNode
	{
		// operator
		public FloatOperator formulaOperator = new FloatOperator();

		[EditorHelp("Value 1", "The first value that will be used.", "")]
		[EditorSeparator]
		public FloatValue<FormulaObjectSelection> min = new FloatValue<FormulaObjectSelection>();

		[EditorHelp("Value 2", "The 2nd value that will be used.", "")]
		[EditorSeparator]
		public FloatValue<FormulaObjectSelection> max = new FloatValue<FormulaObjectSelection>();

		public MaximumValueNode()
		{

		}

		public override void SetData(DataObject data)
		{
			base.SetData(data);
			this.formulaOperator.OldDataUpgrade(data, "formulaOperator");
		}

		public override int Calculate(FormulaCall call)
		{
			this.formulaOperator.Use(ref call.result,
				Mathf.Max(this.min.GetValue(call), this.max.GetValue(call)));
			return this.next;
		}


		/*
		============================================================================
		Name functions
		============================================================================
		*/
		public override string GetNodeDetails()
		{
			return this.formulaOperator.ToString() + " max(" +
				this.min.ToString() + ", " + this.max.ToString() + ")";
		}

		public override Color EditorColor
		{
			get { return Maki.EditorSettings.valueNodeColor; }
		}
	}

	[EditorHelp("Check Value", "A value (e.g. the current value of the formula will be checked with a defined value.\n" +
		"If the check is true, 'Success' will be executed next, otherwise 'Failed'.", "")]
	[NodeInfo("Value", "Check")]
	public class CheckValueNode : BaseFormulaCheckNode
	{
		[EditorHelp("Value", "The value that will be checked.", "")]
		public FloatValue<FormulaObjectSelection> value = new FloatValue<FormulaObjectSelection>();

		[EditorHelp("Check Type", "Checks if the value is equal, not equal, less or greater than a defined value.\n" +
			"Range inclusive checks if the value is between two defined values, including the values.\n" +
			"Range exclusive checks if the value is between two defined values, excluding the values.\n" +
			"Approximately checks if the value is similar to the defined value.", "")]
		[EditorSeparator]
		public ValueCheck<FormulaObjectSelection> check = new ValueCheck<FormulaObjectSelection>();

		public CheckValueNode()
		{

		}

		public override int Calculate(FormulaCall call)
		{
			if(this.check.Check(this.value.GetValue(call), call))
			{
				return this.next;
			}
			else
			{
				return this.nextFail;
			}
		}


		/*
		============================================================================
		Name functions
		============================================================================
		*/
		public override string GetNodeDetails()
		{
			return this.value.ToString() + " " + this.check.ToString();
		}

		public override Color EditorColor
		{
			get { return Maki.EditorSettings.valueNodeColor; }
		}
	}

	[EditorHelp("Limit Value", "The current value of the formula will be limited.", "")]
	[NodeInfo("Value")]
	public class LimitValueNode : BaseFormulaNode
	{
		[EditorHelp("Use Minimum", "The current value will be limited by a minimum value.", "")]
		[EditorTitleLabel("Min/Max Value")]
		public bool useMin = false;

		[EditorHelp("Minimum Value", "The value will have at least this value.", "")]
		[EditorCondition("useMin", true)]
		[EditorEndCondition]
		public FloatValue<FormulaObjectSelection> minValue = new FloatValue<FormulaObjectSelection>();

		[EditorHelp("Use Maximum", "The current value will be limited by a maximum value.", "")]
		[EditorSeparator]
		public bool useMax = false;

		[EditorHelp("Maximum Value", "The value will have this value at most.", "")]
		[EditorCondition("useMax", true)]
		[EditorEndCondition]
		public FloatValue<FormulaObjectSelection> maxValue = new FloatValue<FormulaObjectSelection>();

		public LimitValueNode()
		{

		}

		public override int Calculate(FormulaCall call)
		{
			if(this.useMin)
			{
				float min = this.minValue.GetValue(call);
				if(call.result < min)
				{
					call.result = min;
				}
			}
			if(this.useMax)
			{
				float max = this.maxValue.GetValue(call);
				if(call.result > max)
				{
					call.result = max;
				}
			}
			return this.next;
		}


		/*
		============================================================================
		Name functions
		============================================================================
		*/
		public override string GetNodeDetails()
		{
			return (this.useMin ? this.minValue.ToString() : "X") + " - " + (this.useMax ? this.maxValue.ToString() : "X");
		}

		public override Color EditorColor
		{
			get { return Maki.EditorSettings.valueNodeColor; }
		}
	}

	[EditorHelp("Store Formula Value", "Stores the current value of the formula into a float variable.", "")]
	[NodeInfo("Variable", "Value")]
	public class StoreFormulaValueNode : BaseFormulaNode
	{
		public VariableSet<FormulaObjectSelection> variable = new VariableSet<FormulaObjectSelection>();

		[EditorSeparator]
		public FloatOperator floatOperator = new FloatOperator();

		public StoreFormulaValueNode()
		{

		}

		public override void SetData(DataObject data)
		{
			base.SetData(data);
			this.floatOperator.OldDataUpgrade(data, "floatOperator");
		}

		public override int Calculate(FormulaCall call)
		{
			string tmpKey = this.variable.key.GetValue(call);

			List<VariableHandler> handlers = this.variable.GetHandlers(call);
			for(int i = 0; i < handlers.Count; i++)
			{
				this.variable.ChangeFloat(call, handlers[i], tmpKey,
					call.result, this.floatOperator);
			}
			Maki.Pooling.VariableHandlerLists.Add(handlers);

			return this.next;
		}


		/*
		============================================================================
		Name functions
		============================================================================
		*/
		public override string GetNodeDetails()
		{
			return this.variable.ToString() + " " +
				this.floatOperator.ToString();
		}

		public override Color EditorColor
		{
			get { return Maki.EditorSettings.valueNodeColor; }
		}
	}

	[EditorHelp("Function Value", "The return value of a called function is used.\n" +
		"Requires a function that takes a 'FormulaCall' as parameter, which gives you access to " +
		"the user/target of the formula, current value and local variables/selected data, e.g.:\n" +
		"public float YourFunction(FormulaCall call)", "")]
	[NodeInfo("Value")]
	public class FunctionValueNode : BaseFormulaNode
	{
		// operator
		public FloatOperator formulaOperator = new FloatOperator();

		// field settings
		[EditorHelp("Class Origin", "Select where the defined function comes from:\n" +
			"- Component: A component on a defined combatant's game object.\n" +
			"- Static: A static function of the class.\n" +
			"- Selected Data: A class instance stored in selected data.", "")]
		[EditorSeparator]
		[EditorTitleLabel("Field Settings")]
		public ReflectionClassOrigin classOrigin = ReflectionClassOrigin.Static;

		// component
		[EditorCondition("classOrigin", ReflectionClassOrigin.Component)]
		[EditorAutoInit]
		[EditorEndCondition]
		public FormulaObjectSelection origin;

		// selected data
		[EditorCondition("classOrigin", ReflectionClassOrigin.SelectedData)]
		[EditorAutoInit]
		[EditorEndCondition]
		public SelectedData<FormulaObjectSelection> selectedData;

		// class
		[EditorHelp("Class Name", "The name of the class that contains the static function.", "")]
		[EditorSeparator]
		[EditorWidth(true)]
		[EditorReflectionField(EditorReflectionFieldType.Class, typeof(Component))]
		public string className = "";

		[EditorHelp("Function Name", "The name of the static function that will be called.\n" +
			"Requires a function that takes a 'FormulaCall' as parameter, which gives you access to " +
			"the user/target of the formula, current value and local variables/selected data, e.g.:\n" +
			"public float YourFunction(FormulaCall call)\n" +
			"Or for static functions:\n" +
			"public static float YourFunction(FormulaCall call)", "")]
		[EditorWidth(true)]
		[EditorReflectionField(EditorReflectionFieldType.Function, typeof(Component), "className")]
		public string functionName = "";

		public FunctionValueNode()
		{

		}

		public override void SetData(DataObject data)
		{
			base.SetData(data);
			this.formulaOperator.OldDataUpgrade(data, "formulaOperator");
		}

		public override int Calculate(FormulaCall call)
		{
			if(this.className != "" && this.functionName != "")
			{
				if(ReflectionClassOrigin.Component == this.classOrigin)
				{
					GameObject gameObject = this.origin.GetObject(call);
					if(gameObject != null)
					{
						Component comp = ComponentHelper.Get(gameObject, this.className);
						if(comp != null)
						{
							object tmp = this.GetValue(comp, call);
							if(tmp is float)
							{
								this.formulaOperator.Use(ref call.result, (float)tmp);
							}
							else if(tmp is int)
							{
								this.formulaOperator.Use(ref call.result, (int)tmp);
							}
						}
					}
				}
				else if(ReflectionClassOrigin.Static == this.classOrigin)
				{
					object tmp = this.GetValue(null, call);
					if(tmp is float)
					{
						this.formulaOperator.Use(ref call.result, (float)tmp);
					}
					else if(tmp is int)
					{
						this.formulaOperator.Use(ref call.result, (int)tmp);
					}
				}
				else if(ReflectionClassOrigin.SelectedData == this.classOrigin)
				{
					List<object> list = SelectedDataHelper.GetClass(this.selectedData.GetSelectedData(call), this.className);

					for(int i = 0; i < list.Count; i++)
					{
						if(list[i] != null)
						{
							object tmp = this.GetValue(list[i], call);
							if(tmp is float)
							{
								this.formulaOperator.Use(ref call.result, (float)tmp);
							}
							else if(tmp is int)
							{
								this.formulaOperator.Use(ref call.result, (int)tmp);
							}
						}
					}
				}
			}

			return this.next;
		}

		protected virtual object GetValue(object instance, FormulaCall call)
		{
			if(instance != null || ReflectionClassOrigin.Static == this.classOrigin)
			{
				System.Type classType = ReflectionClassOrigin.Component == this.classOrigin ?
					Maki.ReflectionHandler.GetTypeOrInterface(this.className, typeof(Component)) :
					Maki.ReflectionHandler.GetType(this.className);
				if(classType != null)
				{
					System.Type[] types = new System.Type[] { typeof(FormulaCall) };
					object[] values = new object[] { call };

					MethodInfo methodInfo = classType.GetMethod(this.functionName, types);
					if(methodInfo != null)
					{
						try
						{
							return methodInfo.Invoke(ReflectionClassOrigin.Static == this.classOrigin ? null : instance, values);
						}
						catch(System.Exception ex)
						{
							Debug.LogWarning("Method call failed (" + classType + "): " +
								this.functionName + "\n" + ex.Message + "\n" + ex.StackTrace);
						}
					}
					else
					{
						Debug.LogWarning("Method not found (" + classType + "): " + this.functionName);
					}
				}
				else
				{
					Debug.LogWarning("Class not found: " + this.className);
				}
			}
			return null;
		}


		/*
		============================================================================
		Name functions
		============================================================================
		*/
		public override string GetNodeDetails()
		{
			return this.formulaOperator.ToString() + " " + this.className + "." + this.functionName;
		}

		public override Color EditorColor
		{
			get { return Maki.EditorSettings.valueNodeColor; }
		}
	}



	[EditorHelp("Field Value", "The value of an int or float field/property is used.", "")]
	[NodeInfo("Value")]
	public class FieldValueNode : BaseFormulaNode
	{
		// operator
		public FloatOperator formulaOperator = new FloatOperator();

		// field settings
		[EditorHelp("Class Origin", "Select where the defined function comes from:\n" +
			"- Component: A component on a defined combatant's game object.\n" +
			"- Static: A static function of the class.\n" +
			"- Selected Data: A class instance stored in selected data.", "")]
		[EditorSeparator]
		[EditorTitleLabel("Field Settings")]
		public ReflectionClassOrigin classOrigin = ReflectionClassOrigin.Static;

		// component
		[EditorCondition("classOrigin", ReflectionClassOrigin.Component)]
		[EditorAutoInit]
		[EditorEndCondition]
		public FormulaObjectSelection origin;

		// selected data
		[EditorCondition("classOrigin", ReflectionClassOrigin.SelectedData)]
		[EditorAutoInit]
		[EditorEndCondition]
		public SelectedData<FormulaObjectSelection> selectedData;

		// class
		[EditorSeparator]
		public GetFieldValue<FormulaObjectSelection> field = new GetFieldValue<FormulaObjectSelection>();

		public FieldValueNode()
		{

		}

		public override void SetData(DataObject data)
		{
			base.SetData(data);
			this.formulaOperator.OldDataUpgrade(data, "formulaOperator");
		}

		public override int Calculate(FormulaCall call)
		{
			if(this.field.className != "" && this.field.fieldName != "")
			{
				if(ReflectionClassOrigin.Component == this.classOrigin)
				{
					GameObject gameObject = this.origin.GetObject(call);
					if(gameObject != null)
					{
						Component comp = ComponentHelper.Get(gameObject, this.field.className);
						if(comp != null)
						{
							object tmp = this.field.GetValue(comp, false, call);
							if(tmp is float)
							{
								this.formulaOperator.Use(ref call.result, (float)tmp);
							}
							else if(tmp is int)
							{
								this.formulaOperator.Use(ref call.result, (int)tmp);
							}
						}
					}
				}
				else if(ReflectionClassOrigin.Static == this.classOrigin)
				{
					object tmp = this.field.GetValue(null, true, call);
					if(tmp is float)
					{
						this.formulaOperator.Use(ref call.result, (float)tmp);
					}
					else if(tmp is int)
					{
						this.formulaOperator.Use(ref call.result, (int)tmp);
					}
				}
				else if(ReflectionClassOrigin.SelectedData == this.classOrigin)
				{
					List<object> list = SelectedDataHelper.GetClass(this.selectedData.GetSelectedData(call), this.field.className);

					for(int i = 0; i < list.Count; i++)
					{
						if(list[i] != null)
						{
							object tmp = this.field.GetValue(list[i], false, call);
							if(tmp is float)
							{
								this.formulaOperator.Use(ref call.result, (float)tmp);
							}
							else if(tmp is int)
							{
								this.formulaOperator.Use(ref call.result, (int)tmp);
							}
						}
					}
				}
			}

			return this.next;
		}


		/*
		============================================================================
		Name functions
		============================================================================
		*/
		public override string GetNodeDetails()
		{
			return this.formulaOperator.ToString() + " " + this.field.ToString();
		}

		public override Color EditorColor
		{
			get { return Maki.EditorSettings.valueNodeColor; }
		}
	}
}
