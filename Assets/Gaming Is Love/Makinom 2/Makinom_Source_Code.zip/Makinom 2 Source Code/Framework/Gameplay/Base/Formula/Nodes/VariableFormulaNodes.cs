
using UnityEngine;
using GamingIsLove.Makinom.Components;
using GamingIsLove.Makinom.Reflection;
using System.Collections.Generic;

namespace GamingIsLove.Makinom.Formulas.Nodes
{
	[EditorHelp("Change Variables", "Changes variables.", "")]
	[NodeInfo("Variable")]
	public class ChangeVariablesNode : BaseFormulaNode
	{
		// variables
		public VariableSetter<FormulaObjectSelection> change = new VariableSetter<FormulaObjectSelection>();

		public ChangeVariablesNode()
		{

		}

		public override int Calculate(FormulaCall call)
		{
			this.change.SetVariables(call);
			return this.next;
		}


		/*
		============================================================================
		Name functions
		============================================================================
		*/
		public override string GetNodeDetails()
		{
			return this.change.ToString();
		}

		public override Color EditorColor
		{
			get { return Maki.EditorSettings.valueNodeColor; }
		}
	}

	[EditorHelp("Check Variables", "Checks if variables have certain values.\n" +
		"If the check is true, 'Success' will be executed, otherwise 'Failed'.", "")]
	[NodeInfo("Variable", "Check")]
	public class CheckVariablesNode : BaseFormulaCheckNode
	{
		// variables
		public VariableCondition<FormulaObjectSelection> condition = new VariableCondition<FormulaObjectSelection>();

		public CheckVariablesNode()
		{

		}

		public override int Calculate(FormulaCall call)
		{
			if(this.condition.CheckVariables(call))
			{
				return this.next;
			}
			else
			{
				return this.nextFail;
			}
		}


		/*
		============================================================================
		Name functions
		============================================================================
		*/
		public override string GetNodeDetails()
		{
			return this.condition.ToString();
		}

		public override Color EditorColor
		{
			get { return Maki.EditorSettings.valueNodeColor; }
		}
	}

	[EditorHelp("Variable Fork", "Checks if a single variable for certain values.\n" +
		"If a variable condition is valid, it's next node will be executed.\n" +
		"If no variable condition is valid, 'Failed' will be executed.", "")]
	[NodeInfo("Variable", "Check")]
	public class VariableForkNode : BaseFormulaCheckNode
	{
		[EditorTitleLabel("Variable Settings")]
		public VariableGet<FormulaObjectSelection> variable = new VariableGet<FormulaObjectSelection>();

		[EditorArray("Add Condition", "Adds a new variable condition.", "",
			"Remove", "Removes the variable condition.", "", isMove=true, isCopy=true,
			noRemoveCount=1, foldout=true, foldoutText=new string[] {
				"Variable Condition", "Define the variable condition that must be valid.", ""
		})]
		public CheckVariableNextNode<FormulaObjectSelection>[] condition = new CheckVariableNextNode<FormulaObjectSelection>[] {
			new CheckVariableNextNode<FormulaObjectSelection>()
		};

		public VariableForkNode()
		{

		}

		public override int Calculate(FormulaCall call)
		{
			int check = this.next;

			string tmpKey = this.variable.key.GetValue(call);

			List<VariableHandler> handlers = this.variable.GetHandlers(call);
			for(int i = 0; i < handlers.Count; i++)
			{
				if(this.Check(ref check, tmpKey, handlers[i], call))
				{
					break;
				}
			}
			Maki.Pooling.VariableHandlerLists.Add(handlers);

			return check;
		}

		private bool Check(ref int check, string varKey, VariableHandler handler, FormulaCall call)
		{
			for(int i = 0; i < this.condition.Length; i++)
			{
				if(this.condition[i].Check(varKey, this.variable, handler, call))
				{
					check = this.condition[i].next;
					return true;
				}
			}
			return false;
		}


		/*
		============================================================================
		Name functions
		============================================================================
		*/
		public override string GetNodeDetails()
		{
			return this.variable.ToString();
		}

		public override string GetNextName(int index)
		{
			if(index == 0)
			{
				return "Failed";
			}
			else if(index > 0)
			{
				return (index - 1) + ": " + this.condition[index - 1].ToString();
			}
			return "";
		}

		public override int GetNextCount()
		{
			return this.condition.Length + 1;
		}

		public override int GetNext(int index)
		{
			if(index == 0)
			{
				return this.next;
			}
			else if(index > 0)
			{
				return this.condition[index - 1].next;
			}
			return -1;
		}

		public override void SetNext(int index, int next)
		{
			if(index == 0)
			{
				this.next = next;
			}
			else if(index > 0)
			{
				this.condition[index - 1].next = next;
			}
		}

		public override Color EditorColor
		{
			get { return Maki.EditorSettings.valueNodeColor; }
		}
	}

	[EditorHelp("Clear Variables", "Removes all variables and variable lists.", "")]
	[NodeInfo("Variable")]
	public class ClearVariablesNode : BaseFormulaNode
	{
		public VariableOrigin<FormulaObjectSelection> variable = new VariableOrigin<FormulaObjectSelection>();

		public ClearVariablesNode()
		{

		}

		public override int Calculate(FormulaCall call)
		{
			List<VariableHandler> handlers = this.variable.GetHandlers(call);
			for(int i = 0; i < handlers.Count; i++)
			{
				handlers[i].Clear();
			}
			Maki.Pooling.VariableHandlerLists.Add(handlers);

			return this.next;
		}


		/*
		============================================================================
		Name functions
		============================================================================
		*/
		public override string GetNodeDetails()
		{
			return this.variable.ToString();
		}

		public override Color EditorColor
		{
			get { return Maki.EditorSettings.valueNodeColor; }
		}
	}

	[EditorHelp("Store Function Result", "Stores the return value of a function into a variable.\n" +
		"Supports string, bool, int/float and Vector3 return values.\n" +
		"If a variable is changed, 'Success' will be executed, otherwise 'Failed'.", "")]
	[NodeInfo("Variable")]
	public class StoreFunctionResultNode : BaseFormulaCheckNode
	{
		// variable settings
		[EditorTitleLabel("Variable Settings")]
		public VariableSet<FormulaObjectSelection> variable = new VariableSet<FormulaObjectSelection>();


		// function
		[EditorHelp("Class Origin", "Select where the defined class/function comes from:\n" +
			"- Component: A component on a defined game object.\n" +
			"- Static: A static function of the class.\n" +
			"- Selected Data: A class instance stored in selected data.", "")]
		[EditorSeparator]
		[EditorTitleLabel("Function Settings")]
		public ReflectionClassOrigin classOrigin = ReflectionClassOrigin.Component;

		public CallFunction<FormulaObjectSelection> method = new CallFunction<FormulaObjectSelection>();


		// selected data
		[EditorSeparator]
		[EditorTitleLabel("Selected Data")]
		[EditorCondition("classOrigin", ReflectionClassOrigin.SelectedData)]
		[EditorEndCondition]
		public SelectedData<FormulaObjectSelection> selectedData = new SelectedData<FormulaObjectSelection>();


		// object
		[EditorSeparator]
		[EditorTitleLabel("Function Object")]
		[EditorCondition("classOrigin", ReflectionClassOrigin.Component)]
		[EditorEndCondition]
		public FormulaObjectSelection usedObject = new FormulaObjectSelection();

		public StoreFunctionResultNode()
		{

		}

		public override int Calculate(FormulaCall call)
		{
			bool isSet = false;
			string tmpKey = this.variable.key.GetValue(call);

			if(ReflectionClassOrigin.Component == this.classOrigin)
			{
				if(this.variable.IsSameObject(this.usedObject))
				{
					List<GameObject> list = this.usedObject.GetObjects(call);
					for(int i = 0; i < list.Count; i++)
					{
						if(list[i] != null)
						{
							ObjectVariablesComponent comp = list[i].GetComponentInChildren<ObjectVariablesComponent>();
							if(comp != null)
							{
								object instance = ComponentHelper.Get(list[i],
									ComponentScopeSingle.InObject, this.method.className);
								if(instance != null)
								{
									object value = this.method.GetReturnValue(instance, call, false);
									if(value is Quaternion)
									{
										value = ((Quaternion)value).eulerAngles;
									}

									this.SetValue(call, tmpKey, comp.Handler, value, ref isSet);
								}
							}
						}
					}
					Maki.Pooling.GameObjectLists.Add(list);
				}
				else
				{
					GameObject gameObject = this.usedObject.GetObject(call);

					if(gameObject != null)
					{
						object instance = ComponentHelper.Get(gameObject,
							ComponentScopeSingle.InObject, this.method.className);
						if(instance != null)
						{
							object value = this.method.GetReturnValue(instance, call, false);
							if(value is Quaternion)
							{
								value = ((Quaternion)value).eulerAngles;
							}

							if(value is string || value is bool || value is int ||
								value is float || value is Vector2 || value is Vector3)
							{
								List<VariableHandler> handlers = this.variable.GetHandlers(call);
								for(int i = 0; i < handlers.Count; i++)
								{
									this.SetValue(call, tmpKey, handlers[i], value, ref isSet);
								}
								Maki.Pooling.VariableHandlerLists.Add(handlers);
							}
						}
					}
				}
			}
			else if(ReflectionClassOrigin.Static == this.classOrigin)
			{
				object value = this.method.GetReturnValue(null, call, true);
				if(value is Quaternion)
				{
					value = ((Quaternion)value).eulerAngles;
				}

				if(value is string || value is bool || value is int ||
					value is float || value is Vector2 || value is Vector3)
				{
					List<VariableHandler> handlers = this.variable.GetHandlers(call);
					for(int i = 0; i < handlers.Count; i++)
					{
						this.SetValue(call, tmpKey, handlers[i], value, ref isSet);
					}
					Maki.Pooling.VariableHandlerLists.Add(handlers);
				}
			}
			else if(ReflectionClassOrigin.SelectedData == this.classOrigin)
			{
				List<VariableHandler> handlers = this.variable.GetHandlers(call);
				List<object> list = SelectedDataHelper.GetClass(
					this.selectedData.GetSelectedData(call), this.method.className);
				for(int i = 0; i < list.Count; i++)
				{
					if(list[i] != null)
					{
						object value = this.method.GetReturnValue(list[i], call, false);
						if(value is Quaternion)
						{
							value = ((Quaternion)value).eulerAngles;
						}

						if(value is string || value is bool || value is int ||
							value is float || value is Vector2 || value is Vector3)
						{
							for(int j = 0; j < handlers.Count; j++)
							{
								this.SetValue(call, tmpKey, handlers[i], value, ref isSet);
							}
						}
					}
				}
				Maki.Pooling.VariableHandlerLists.Add(handlers);
			}

			return isSet ? this.next : this.next;
		}

		private void SetValue(FormulaCall call, string tmpKey,
			VariableHandler handler, object value, ref bool isSet)
		{
			if(value is string)
			{
				isSet = true;
				this.variable.ChangeString(call, handler, tmpKey,
					(string)value, StringOperator.Set, "");
			}
			else if(value is bool)
			{
				isSet = true;
				this.variable.ChangeBool(call, handler, tmpKey, (bool)value);
			}
			else if(value is int)
			{
				isSet = true;
				this.variable.ChangeInt(call, handler, tmpKey,
					(int)value, FloatOperator.Set);
			}
			else if(value is float)
			{
				isSet = true;
				this.variable.ChangeFloat(call, handler, tmpKey,
					(float)value, FloatOperator.Set);
			}
			else if(value is Vector2)
			{
				isSet = true;
				this.variable.ChangeVector3(call, handler, tmpKey,
					(Vector2)value, Vector3Operator.Set, false);
			}
			else if(value is Vector3)
			{
				isSet = true;
				this.variable.ChangeVector3(call, handler, tmpKey,
					(Vector3)value, Vector3Operator.Set, false);
			}
		}


		/*
		============================================================================
		Name functions
		============================================================================
		*/
		public override string GetNodeDetails()
		{
			return this.variable.ToString() + " = " + this.classOrigin +
				" " + this.method.ToString();
		}

		public override Color EditorColor
		{
			get { return Maki.EditorSettings.valueNodeColor; }
		}
	}

	[EditorHelp("Store Field", "Stores the value of a field or property into a variable.\n" +
		"Supports string, bool, int/float and Vector2/Vector3 values.\n" +
		"If a variable is changed, 'Success' will be executed, otherwise 'Failed'.", "")]
	[NodeInfo("Variable")]
	public class StoreFieldNode : BaseFormulaCheckNode
	{
		// variable settings
		[EditorTitleLabel("Variable Settings")]
		public VariableSet<FormulaObjectSelection> variable = new VariableSet<FormulaObjectSelection>();


		// field
		[EditorHelp("Class Origin", "Select where the defined class/field/property comes from:\n" +
			"- Component: A component on a defined game object.\n" +
			"- Static: A static field/property of the class.\n" +
			"- Selected Data: A class instance stored in selected data.", "")]
		[EditorSeparator]
		[EditorTitleLabel("Field Settings")]
		public ReflectionClassOrigin classOrigin = ReflectionClassOrigin.Component;

		public GetFieldValue<FormulaObjectSelection> field = new GetFieldValue<FormulaObjectSelection>();


		// selected data
		[EditorSeparator]
		[EditorTitleLabel("Selected Data")]
		[EditorCondition("classOrigin", ReflectionClassOrigin.SelectedData)]
		[EditorEndCondition]
		public SelectedData<FormulaObjectSelection> selectedData = new SelectedData<FormulaObjectSelection>();


		// object
		[EditorSeparator]
		[EditorTitleLabel("Field Object")]
		[EditorCondition("classOrigin", ReflectionClassOrigin.Component)]
		[EditorEndCondition]
		public FormulaObjectSelection usedObject = new FormulaObjectSelection();

		public StoreFieldNode()
		{

		}

		public override int Calculate(FormulaCall call)
		{
			bool isSet = false;
			string tmpKey = this.variable.key.GetValue(call);

			if(ReflectionClassOrigin.Component == this.classOrigin)
			{
				if(this.variable.IsSameObject(this.usedObject))
				{
					List<GameObject> list = this.usedObject.GetObjects(call);
					for(int i = 0; i < list.Count; i++)
					{
						if(list[i] != null)
						{
							ObjectVariablesComponent comp = list[i].GetComponentInChildren<ObjectVariablesComponent>();
							if(comp != null)
							{
								object instance = ComponentHelper.Get(list[i],
									ComponentScopeSingle.InObject, this.field.className);
								if(instance != null)
								{
									object value = this.field.GetValue(list[i], false, call);
									if(value is Quaternion)
									{
										value = ((Quaternion)value).eulerAngles;
									}

									this.SetValue(call, tmpKey, comp.Handler, value, ref isSet);
								}
							}
						}
					}
					Maki.Pooling.GameObjectLists.Add(list);
				}
				else
				{
					GameObject gameObject = this.usedObject.GetObject(call);

					if(gameObject != null)
					{
						object instance = ComponentHelper.Get(gameObject,
							ComponentScopeSingle.InObject, this.field.className);
						if(instance != null)
						{
							object value = this.field.GetValue(gameObject, false, call);
							if(value is Quaternion)
							{
								value = ((Quaternion)value).eulerAngles;
							}

							if(value is string || value is bool || value is int ||
								value is float || value is Vector2 || value is Vector3)
							{
								List<VariableHandler> handlers = this.variable.GetHandlers(call);
								for(int i = 0; i < handlers.Count; i++)
								{
									this.SetValue(call, tmpKey, handlers[i], value, ref isSet);
								}
								Maki.Pooling.VariableHandlerLists.Add(handlers);
							}
						}
					}
				}
			}
			else if(ReflectionClassOrigin.Static == this.classOrigin)
			{
				object value = this.field.GetValue(null, true, call);
				if(value is Quaternion)
				{
					value = ((Quaternion)value).eulerAngles;
				}

				if(value is string || value is bool || value is int ||
					value is float || value is Vector2 || value is Vector3)
				{
					List<VariableHandler> handlers = this.variable.GetHandlers(call);
					for(int i = 0; i < handlers.Count; i++)
					{
						this.SetValue(call, tmpKey, handlers[i], value, ref isSet);
					}
					Maki.Pooling.VariableHandlerLists.Add(handlers);
				}
			}
			else if(ReflectionClassOrigin.SelectedData == this.classOrigin)
			{
				List<VariableHandler> handlers = this.variable.GetHandlers(call);
				List<object> list = SelectedDataHelper.GetClass(
					this.selectedData.GetSelectedData(call), this.field.className);
				for(int i = 0; i < list.Count; i++)
				{
					if(list[i] != null)
					{
						object value = this.field.GetValue(list[i], false, call);
						if(value is Quaternion)
						{
							value = ((Quaternion)value).eulerAngles;
						}

						if(value is string || value is bool || value is int ||
							value is float || value is Vector2 || value is Vector3)
						{
							for(int j = 0; j < handlers.Count; j++)
							{
								this.SetValue(call, tmpKey, handlers[i], value, ref isSet);
							}
						}
					}
				}
				Maki.Pooling.VariableHandlerLists.Add(handlers);
			}

			return isSet ? this.next : this.nextFail;
		}

		private void SetValue(FormulaCall call, string tmpKey,
			VariableHandler handler, object value, ref bool isSet)
		{
			if(value is string)
			{
				isSet = true;
				this.variable.ChangeString(call, handler, tmpKey,
					(string)value, StringOperator.Set, "");
			}
			else if(value is bool)
			{
				isSet = true;
				this.variable.ChangeBool(call, handler, tmpKey, (bool)value);
			}
			else if(value is int)
			{
				isSet = true;
				this.variable.ChangeInt(call, handler, tmpKey,
					(int)value, FloatOperator.Set);
			}
			else if(value is float)
			{
				isSet = true;
				this.variable.ChangeFloat(call, handler, tmpKey,
					(float)value, FloatOperator.Set);
			}
			else if(value is Vector2)
			{
				isSet = true;
				this.variable.ChangeVector3(call, handler, tmpKey,
					(Vector2)value, Vector3Operator.Set, false);
			}
			else if(value is Vector3)
			{
				isSet = true;
				this.variable.ChangeVector3(call, handler, tmpKey,
					(Vector3)value, Vector3Operator.Set, false);
			}
		}


		/*
		============================================================================
		Name functions
		============================================================================
		*/
		public override string GetNodeDetails()
		{
			return this.variable.ToString() + " = " + this.classOrigin +
				" " + this.field.ToString();
		}

		public override Color EditorColor
		{
			get { return Maki.EditorSettings.valueNodeColor; }
		}
	}

	[EditorHelp("Variable Transfer", "Transfers all variables and variable lists " +
		"from one origin to another (local, global and object).", "")]
	[NodeInfo("Variable")]
	public class VariableTransferNode : BaseFormulaNode
	{
		// source variable settings
		[EditorTitleLabel("Source Variable Settings")]
		public VariableOrigin<FormulaObjectSelection> sourceVariable = new VariableOrigin<FormulaObjectSelection>();

		[EditorHelp("Clear Source", "Remove all variables in the source after " +
			"transfering them to the target.", "")]
		public bool clearSource = false;


		// target variable settings
		[EditorTitleLabel("Target Variable Settings")]
		[EditorSeparator]
		public VariableOrigin<FormulaObjectSelection> targetVariable = new VariableOrigin<FormulaObjectSelection>();

		[EditorHelp("Clear Target", "Remove all variables in the target before transfering.", "")]
		public bool clearTarget = false;

		public VariableTransferNode()
		{

		}

		public override int Calculate(FormulaCall call)
		{
			VariableHandler sourceHandler = this.sourceVariable.GetFirstHandler(call);
			if(sourceHandler != null)
			{
				List<VariableHandler> targetHandlers = this.targetVariable.GetHandlers(call);
				for(int i = 0; i < targetHandlers.Count; i++)
				{
					if(this.clearTarget)
					{
						targetHandlers[i].Clear();
					}
					targetHandlers[i].Transfer(sourceHandler);
				}
				Maki.Pooling.VariableHandlerLists.Add(targetHandlers);
			}
			if(this.clearSource)
			{
				sourceHandler.Clear();
			}

			return this.next;
		}


		/*
		============================================================================
		Name functions
		============================================================================
		*/
		public override string GetNodeDetails()
		{
			return this.sourceVariable.ToString() +
				(this.clearSource ? "(clear) to " : " to ") +
				this.targetVariable.ToString() +
				(this.clearTarget ? "(clear)" : "");
		}

		public override Color EditorColor
		{
			get { return Maki.EditorSettings.valueNodeColor; }
		}
	}

	[EditorHelp("Variable Exists", "Checks if a variable exists (i.e it has been set).\n" +
		"If the check is valid, 'Success' will be executed, otherwise 'Failed'.", "")]
	[NodeInfo("Variable", "Check")]
	public class VariableExistsNode : BaseFormulaCheckNode
	{
		public Variable<FormulaObjectSelection> variable = new Variable<FormulaObjectSelection>();

		[EditorHelp("Is List", "Checks if a variable list exists.", "")]
		public bool isList = false;

		[EditorHelp("Type", "Select the type of the variable:\n" +
			"- String: A string variable.\n" +
			"- Bool: A bool variable.\n" +
			"- Float: A float variable.\n" +
			"- Vector3: A Vector3 variable.\n" +
			"- Axis Vector3: A single axis of a Vector3 variable.", "")]
		public VariableType type = VariableType.String;

		public VariableExistsNode()
		{

		}

		public override int Calculate(FormulaCall call)
		{
			List<VariableHandler> handlers = this.variable.GetHandlers(call);
			if(this.DoCheck(this.variable.key.GetValue(call), handlers))
			{
				Maki.Pooling.VariableHandlerLists.Add(handlers);
				return this.next;
			}
			else
			{
				Maki.Pooling.VariableHandlerLists.Add(handlers);
				return this.nextFail;
			}
		}

		private bool DoCheck(string key, List<VariableHandler> handlers)
		{
			for(int i = 0; i < handlers.Count; i++)
			{
				if(this.isList)
				{
					if(handlers[i].HasLists &&
						handlers[i].Lists.KeyExists(key, this.type))
					{
						return true;
					}
				}
				else if(handlers[i].KeyExists(key, this.type))
				{
					return true;
				}
			}

			return false;
		}


		/*
		============================================================================
		Name functions
		============================================================================
		*/
		public override string GetNodeDetails()
		{
			return this.type.ToString() + " " + this.variable.ToString();
		}

		public override Color EditorColor
		{
			get { return Maki.EditorSettings.valueNodeColor; }
		}
	}
}
