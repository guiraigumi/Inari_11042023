﻿
using UnityEngine;
using GamingIsLove.Makinom.Components;
using System.Collections.Generic;

namespace GamingIsLove.Makinom
{
	public class SaveGameObjectSettings : BaseData
	{
		[EditorHelp("Save Position", "Save the position of this game object.")]
		public bool savePosition = true;

		[EditorHelp("Save Rotation", "Save the rotation of this game object.")]
		public bool saveRotation = true;

		[EditorHelp("Save Scale", "Save the scale of this game object.")]
		public bool saveScale = true;

		[EditorHelp("Save Local Variables", "Save data from an 'Object Variables' component with 'Local Variables' enabled.\n" +
			"When 'Local Variables' is disabled, the variables will be saved based on their 'Object ID'.\n" +
			"The 'Object Variables' component has to be attached to this game object.")]
		public bool saveLocalVariables = false;


		// child objects
		[EditorHelp("Save Child Positions", "Save the position of child game objects.")]
		[EditorSeparator]
		public bool saveChildPositions = false;

		[EditorHelp("Save Child Rotations", "Save the rotation of child game objects.")]
		public bool saveChildRotations = false;

		[EditorHelp("Save Child Scales", "Save the scale of child game objects.")]
		public bool saveChildScales = false;

		[EditorHelp("Save Child Local Variables", "Save data from an 'Object Variables' component with 'Local Variables' enabled on child objects.\n" +
			"When 'Local Variables' is disabled, the variables will be saved based on their 'Object ID'.")]
		public bool saveChildLocalVariables = false;

		public SaveGameObjectSettings()
		{

		}

		public virtual bool SaveChildData
		{
			get
			{
				return this.saveChildPositions ||
					this.saveChildRotations ||
					this.saveChildScales ||
					this.saveChildLocalVariables;
			}
		}


		/*
		============================================================================
		Game object functions
		============================================================================
		*/
		public virtual DataObject SaveGame(GameObject gameObject)
		{
			DataObject data = new DataObject();

			// game object
			if(this.savePosition)
			{
				data.Set("position", gameObject.transform.position);
			}
			if(this.saveRotation)
			{
				data.Set("rotation", gameObject.transform.eulerAngles);
			}
			if(this.saveScale)
			{
				data.Set("scale", gameObject.transform.localScale);
			}
			if(this.saveLocalVariables)
			{
				ObjectVariablesComponent variables = gameObject.GetComponent<ObjectVariablesComponent>();
				if(variables != null &&
					variables.settings.isLocal &&
					variables.HandlerExists())
				{
					data.Set("variables", variables.Handler.SaveGame());
				}
			}

			// child objects
			if(gameObject.transform.childCount > 0 &&
				this.SaveChildData)
			{
				DataObject[] childData = new DataObject[gameObject.transform.childCount];
				for(int i = 0; i < childData.Length; i++)
				{
					childData[i] = this.ChildSaveGame(gameObject.transform.GetChild(i));
				}
				data.Set("childs", childData);
			}

			// component data
			IComponentSaveData[] comp = gameObject.GetComponentsInChildren<IComponentSaveData>();
			if(comp != null &&
				comp.Length > 0)
			{
				DataObject componentData = new DataObject();
				for(int i = 0; i < comp.Length; i++)
				{
					if(comp[i] != null)
					{
						componentData.Set(comp[i].GetSaveKey(), comp[i].SaveGame());
					}
				}
				data.Set("components", componentData);
			}

			return data;
		}

		public virtual void LoadGame(GameObject gameObject, DataObject data)
		{
			if(data != null)
			{
				Vector3 tmpValue = Vector3.zero;

				// game object
				if(this.savePosition)
				{
					tmpValue = gameObject.transform.position;
					data.Get("position", ref tmpValue);
					gameObject.transform.position = tmpValue;
				}
				if(this.saveRotation)
				{
					tmpValue = gameObject.transform.eulerAngles;
					data.Get("rotation", ref tmpValue);
					gameObject.transform.eulerAngles = tmpValue;
				}
				if(this.saveScale)
				{
					tmpValue = gameObject.transform.localScale;
					data.Get("scale", ref tmpValue);
					gameObject.transform.localScale = tmpValue;
				}
				if(this.saveLocalVariables)
				{
					DataObject variableData = data.GetFile("variables");
					if(variableData != null)
					{
						ObjectVariablesComponent variables = gameObject.GetComponent<ObjectVariablesComponent>();
						if(variables != null &&
							variables.settings.isLocal)
						{
							variables.Handler.LoadGame(variableData);
						}
					}
				}

				// child objects
				if(gameObject.transform.childCount > 0 &&
					this.SaveChildData)
				{
					DataObject[] childData = data.GetFileArray("childs");
					if(childData != null)
					{
						for(int i = 0; i < childData.Length; i++)
						{
							if(i < gameObject.transform.childCount)
							{
								this.ChildLoadGame(gameObject.transform.GetChild(i), childData[i]);
							}
						}
					}
				}

				// component data
				DataObject componentData = data.GetFile("components");
				if(componentData != null)
				{
					IComponentSaveData[] comp = gameObject.GetComponentsInChildren<IComponentSaveData>();
					if(comp != null &&
						comp.Length > 0)
					{
						for(int i = 0; i < comp.Length; i++)
						{
							if(comp[i] != null)
							{
								DataObject tmpData = componentData.GetFile(comp[i].GetSaveKey());
								if(tmpData != null)
								{
									comp[i].LoadGame(tmpData);
								}
							}
						}
					}
				}
			}
		}


		/*
		============================================================================
		Child object functions
		============================================================================
		*/
		protected virtual DataObject ChildSaveGame(Transform transform)
		{
			DataObject data = new DataObject();
			if(this.saveChildPositions)
			{
				data.Set("position", transform.position);
			}
			if(this.saveChildRotations)
			{
				data.Set("rotation", transform.eulerAngles);
			}
			if(this.saveChildScales)
			{
				data.Set("scale", transform.localScale);
			}
			if(this.saveChildLocalVariables)
			{
				ObjectVariablesComponent variables = transform.GetComponent<ObjectVariablesComponent>();
				if(variables != null &&
					variables.settings.isLocal &&
					variables.HandlerExists())
				{
					data.Set("variables", variables.Handler.SaveGame());
				}
			}
			if(transform.childCount > 0)
			{
				DataObject[] childData = new DataObject[transform.childCount];
				for(int i = 0; i < childData.Length; i++)
				{
					childData[i] = this.ChildSaveGame(transform.GetChild(i));
				}
				data.Set("childs", childData);
			}
			return data;
		}

		protected virtual void ChildLoadGame(Transform transform, DataObject data)
		{
			if(data != null)
			{
				Vector3 tmpValue = Vector3.zero;
				if(this.saveChildPositions)
				{
					tmpValue = transform.position;
					data.Get("position", ref tmpValue);
					transform.position = tmpValue;
				}
				if(this.saveChildRotations)
				{
					tmpValue = transform.eulerAngles;
					data.Get("rotation", ref tmpValue);
					transform.eulerAngles = tmpValue;
				}
				if(this.saveChildScales)
				{
					tmpValue = transform.localScale;
					data.Get("scale", ref tmpValue);
					transform.localScale = tmpValue;
				}
				if(this.saveChildLocalVariables)
				{
					DataObject variableData = data.GetFile("variables");
					if(variableData != null)
					{
						ObjectVariablesComponent variables = transform.GetComponent<ObjectVariablesComponent>();
						if(variables != null &&
							variables.settings.isLocal)
						{
							variables.Handler.LoadGame(variableData);
						}
					}
				}
				if(transform.childCount > 0)
				{
					DataObject[] childData = data.GetFileArray("childs");
					if(childData != null)
					{
						for(int i = 0; i < childData.Length; i++)
						{
							if(i < transform.childCount)
							{
								this.ChildLoadGame(transform.GetChild(i), childData[i]);
							}
						}
					}
				}
			}
		}
	}
}
