
using UnityEngine;
using System.Collections.Generic;

namespace GamingIsLove.Makinom
{
	public class GameStateChange : BaseData
	{
		[EditorHelp("Game State", "Select the game state that will be changed.", "")]
		public AssetSelection<GameStateAsset> state = new AssetSelection<GameStateAsset>();

		[EditorHelp("Set State", "Select if the game state is set active or inactive.", "")]
		public ActiveType change = ActiveType.Active;

		public GameStateChange()
		{

		}

		public void Change()
		{
			if(this.state.StoredAsset != null)
			{
				this.state.StoredAsset.Settings.IsActive = (ActiveType.Active == this.change);
			}
		}

		public override string ToString()
		{
			return this.state.ToString() + " = " + this.change;
		}
	}
}
