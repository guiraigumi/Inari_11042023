
using UnityEngine;
using System.Collections.Generic;
using System.Text;

namespace GamingIsLove.Makinom
{
	public class SimpleGameStateCondition : BaseData
	{
		[EditorHelp("Needed", "Either all or only one game states must be valid.", "")]
		public Needed needed = Needed.One;

		[EditorArray("Add Game State", "Adds a game state that must be valid.", "",
			"Remove", "Removes this game state.", "",
			removeCheckField="state",
			foldout=true, foldoutText=new string[] {
				"Game State", "Define the game state that will be checked.", ""
		})]
		public GameStateCheck[] gameState = new GameStateCheck[0];

		public SimpleGameStateCondition()
		{

		}

		public bool Check()
		{
			if(this.gameState.Length > 0)
			{
				for(int i = 0; i < this.gameState.Length; i++)
				{
					if(this.gameState[i].Check())
					{
						if(Needed.One == this.needed)
						{
							return true;
						}
					}
					else if(Needed.All == this.needed)
					{
						return false;
					}
				}
				return Needed.All == this.needed;
			}
			return true;
		}

		public override string ToString()
		{
			StringBuilder builder = new StringBuilder();
			for(int i = 0; i < this.gameState.Length; i++)
			{
				if(builder.Length > 0)
				{
					builder.Append(", ");
				}
				builder.Append(this.gameState[i].ToString());
			}
			return builder.ToString();
		}
	}
}
