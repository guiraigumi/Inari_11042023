﻿
using UnityEngine;
using System.Collections.Generic;

namespace GamingIsLove.Makinom
{
	public abstract class BaseGameStateChangeType : BaseTypeData
	{
		public abstract void Register(Notify notify);
	}
}
