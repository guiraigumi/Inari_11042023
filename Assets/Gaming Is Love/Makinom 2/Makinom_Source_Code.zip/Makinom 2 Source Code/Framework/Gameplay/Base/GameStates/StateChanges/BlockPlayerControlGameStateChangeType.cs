﻿
using UnityEngine;
using System.Collections.Generic;

namespace GamingIsLove.Makinom
{
	[EditorSettingInfo("Block Player Control", "When the player control is blocked.")]
	public class BlockPlayerControlGameStateChangeType : BaseGameStateChangeType
	{
		public BlockPlayerControlGameStateChangeType()
		{

		}

		public override void Register(Notify notify)
		{
			Maki.Control.BlockPlayerControlCalled += notify;
		}
	}
}
