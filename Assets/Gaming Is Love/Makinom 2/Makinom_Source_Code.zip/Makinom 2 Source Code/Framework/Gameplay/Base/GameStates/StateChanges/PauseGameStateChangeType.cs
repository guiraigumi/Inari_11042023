﻿
using UnityEngine;
using System.Collections.Generic;

namespace GamingIsLove.Makinom
{
	[EditorSettingInfo("Pause Game", "When the game is paused.")]
	public class PauseGameStateChangeType : BaseGameStateChangeType
	{
		public PauseGameStateChangeType()
		{

		}

		public override void Register(Notify notify)
		{
			Maki.Game.GamePaused += notify;
		}
	}
}
