﻿
using UnityEngine;
using System.Collections.Generic;

namespace GamingIsLove.Makinom
{
	public class GameObjectGrid
	{
		private GameObject gameObject;

		private GridCell[,,] grid;

		private Vector3 cellPosition = Vector3.one;

		public GameObjectGrid()
		{

		}

		public GameObjectGrid(string key, int xSize, int ySize, int zSize,
			Vector3 position, Vector3 rotation, Vector3 cellPosition)
		{
			this.cellPosition = cellPosition;

			this.gameObject = new GameObject(key != "" ? key : "[Grid]");
			this.gameObject.transform.SetPositionAndRotation(
				position, Quaternion.Euler(rotation));

			if(xSize < 1)
			{
				xSize = 1;
			}
			if(ySize < 1)
			{
				ySize = 1;
			}
			if(zSize < 1)
			{
				zSize = 1;
			}

			this.grid = new GridCell[xSize, ySize, zSize];

			for(int x = 0; x < xSize; x++)
			{
				for(int y = 0; y < ySize; y++)
				{
					for(int z = 0; z < zSize; z++)
					{
						this.grid[x, y, z] = new GridCell(x, y, z,
							new Vector3(
								x * this.cellPosition.x,
								y * this.cellPosition.y,
								z * this.cellPosition.z));
					}
				}
			}
		}

		public GameObjectGrid GetCopy()
		{
			GameObjectGrid copy = new GameObjectGrid();
			copy.gameObject = this.gameObject;
			copy.cellPosition = this.cellPosition;

			int xSize = this.grid.GetLength(0);
			int ySize = this.grid.GetLength(1);
			int zSize = this.grid.GetLength(2);
			copy.grid = new GridCell[xSize, ySize, zSize];

			for(int x = 0; x < xSize; x++)
			{
				for(int y = 0; y < ySize; y++)
				{
					for(int z = 0; z < zSize; z++)
					{
						copy.grid[x, y, z] = this.grid[x, y, z].GetCopy();
					}
				}
			}
			return copy;
		}

		public GameObject GameObject
		{
			get { return this.gameObject; }
		}

		public void ChangeSize(int xSize, int ySize, int zSize, bool destroyCells)
		{
			if(xSize < 1)
			{
				xSize = 1;
			}
			if(ySize < 1)
			{
				ySize = 1;
			}
			if(zSize < 1)
			{
				zSize = 1;
			}

			GridCell[,,] tmpGrid = this.grid;
			this.grid = new GridCell[xSize, ySize, zSize];

			for(int x = 0; x < xSize; x++)
			{
				for(int y = 0; y < ySize; y++)
				{
					for(int z = 0; z < zSize; z++)
					{
						if(x < tmpGrid.GetLength(0) &&
							y < tmpGrid.GetLength(1) &&
							z < tmpGrid.GetLength(2))
						{
							this.grid[x, y, z] = tmpGrid[x, y, z];
							tmpGrid[x, y, z] = null;
						}
						else
						{
							this.grid[x, y, z] = new GridCell(x, y, z,
								new Vector3(
									x * this.cellPosition.x,
									y * this.cellPosition.y,
									z * this.cellPosition.z));
						}
					}
				}
			}

			// clear old grid
			for(int x = 0; x < tmpGrid.GetLength(0); x++)
			{
				for(int y = 0; y < tmpGrid.GetLength(1); y++)
				{
					for(int z = 0; z < tmpGrid.GetLength(2); z++)
					{
						if(tmpGrid[x, y, z] != null &&
							tmpGrid[x, y, z].GameObject != null)
						{
							if(destroyCells)
							{
								UnityWrapper.Destroy(tmpGrid[x, y, z].GameObject);
							}
							else if(this.gameObject != null &&
								tmpGrid[x, y, z].GameObject.transform.parent == this.gameObject.transform)
							{
								tmpGrid[x, y, z].GameObject.transform.SetParent(this.gameObject.transform);
							}
						}
					}
				}
			}
		}

		public void Destroy(bool destroyCells)
		{
			if(destroyCells)
			{
				for(int x = 0; x < this.grid.GetLength(0); x++)
				{
					for(int y = 0; y < this.grid.GetLength(1); y++)
					{
						for(int z = 0; z < this.grid.GetLength(2); z++)
						{
							if(this.grid[x, y, z].GameObject != null)
							{
								UnityWrapper.Destroy(this.grid[x, y, z].GameObject);
							}
						}
					}
				}
			}
			else
			{
				for(int x = 0; x < this.grid.GetLength(0); x++)
				{
					for(int y = 0; y < this.grid.GetLength(1); y++)
					{
						for(int z = 0; z < this.grid.GetLength(2); z++)
						{
							if(this.grid[x, y, z].GameObject != null &&
								this.grid[x, y, z].GameObject.transform.parent == this.gameObject.transform)
							{
								this.grid[x, y, z].GameObject.transform.SetParent(null);
							}
						}
					}
				}
			}

			UnityWrapper.Destroy(this.gameObject);
		}


		/*
		============================================================================
		Index functions
		============================================================================
		*/
		public int LengthX
		{
			get { return this.grid.GetLength(0); }
		}

		public int LengthY
		{
			get { return this.grid.GetLength(1); }
		}

		public int LengthZ
		{
			get { return this.grid.GetLength(2); }
		}

		public bool HasIndex(int x, int y, int z)
		{
			return x >= 0 && x < this.grid.GetLength(0) &&
				y >= 0 && y < this.grid.GetLength(1) &&
				z >= 0 && z < this.grid.GetLength(2);
		}

		public void GetIndexes(ref int x, ref int y, ref int z)
		{
			// x
			if(x == -1 ||
				x >= this.grid.GetLength(0))
			{
				x = this.grid.GetLength(0) - 1;
			}
			else if(x < 0)
			{
				x = 0;
			}
			// y
			if(y == -1 ||
				y >= this.grid.GetLength(1))
			{
				y = this.grid.GetLength(1) - 1;
			}
			else if(y < 0)
			{
				y = 0;
			}
			// z
			if(z == -1 ||
				z >= this.grid.GetLength(2))
			{
				z = this.grid.GetLength(2) - 1;
			}
			else if(z < 0)
			{
				z = 0;
			}
		}

		public void LoopX(ref int x)
		{
			int max = this.LengthX;
			while(x < 0)
			{
				x += max;
			}
			while(x >= max)
			{
				x -= max;
			}
		}

		public void LoopY(ref int y)
		{
			int max = this.LengthY;
			while(y < 0)
			{
				y += max;
			}
			while(y >= max)
			{
				y -= max;
			}
		}

		public void LoopZ(ref int z)
		{
			int max = this.LengthZ;
			while(z < 0)
			{
				z += max;
			}
			while(z >= max)
			{
				z -= max;
			}
		}


		/*
		============================================================================
		Grid object functions
		============================================================================
		*/
		public GridCell Get(int x, int y, int z)
		{
			if(this.HasIndex(x, y, z))
			{
				return this.grid[x, y, z];
			}
			return null;
		}

		public Vector3 GetObjectIndex(List<GameObject> checkObject)
		{
			if(checkObject != null && checkObject.Count > 0)
			{
				for(int x = 0; x < this.grid.GetLength(0); x++)
				{
					for(int y = 0; y < this.grid.GetLength(1); y++)
					{
						for(int z = 0; z < this.grid.GetLength(2); z++)
						{
							for(int i = 0; i < checkObject.Count; i++)
							{
								if(this.grid[x, y, z].GameObject == checkObject[i])
								{
									return new Vector3(x, y, z);
								}
							}
						}
					}
				}
			}
			return -Vector3.one;
		}
	}
}
