﻿
using UnityEngine;
using System.Collections.Generic;

namespace GamingIsLove.Makinom
{
	public class GridCell
	{
		// index
		private int x = 0;

		private int y = 0;

		private int z = 0;


		// grid object
		private GameObject gameObject;

		private Vector3 position = Vector3.zero;

		private Vector3 rotation = Vector3.zero;


		// options
		private bool isBlocked = false;

		private bool isHidden = false;

		public GridCell()
		{

		}

		public GridCell(int x, int y, int z, Vector3 position)
		{
			this.x = x;
			this.y = y;
			this.z = z;
			this.position = position;
		}

		public GridCell(int x, int y, int z, Vector3 position, Vector3 rotation)
		{
			this.x = x;
			this.y = y;
			this.z = z;
			this.position = position;
			this.rotation = rotation;
		}

		public GridCell GetCopy()
		{
			GridCell copy = new GridCell(this.x, this.y, this.z, this.position, this.rotation);
			copy.gameObject = this.gameObject;
			copy.isBlocked = this.isBlocked;
			copy.isHidden = this.isHidden;
			return copy;
		}


		/*
		============================================================================
		Properties functions
		============================================================================
		*/
		public int X
		{
			get { return this.x; }
		}

		public int Y
		{
			get { return this.y; }
		}

		public int Z
		{
			get { return this.z; }
		}

		public GameObject GameObject
		{
			get { return this.gameObject; }
			set
			{
				if(!this.isBlocked)
				{
					this.gameObject = value;
					if(this.gameObject != null &&
						this.gameObject.activeSelf == this.isHidden)
					{
						this.gameObject.SetActive(!this.isHidden);
					}
				}
			}
		}

		public Vector3 Position
		{
			get { return this.position; }
		}

		public Vector3 Rotation
		{
			get { return this.rotation; }
		}

		public bool Blocked
		{
			get { return this.isBlocked; }
			set { this.isBlocked = value; }
		}

		public bool Hidden
		{
			get { return this.isHidden; }
			set
			{
				this.isHidden = value;
				if(this.gameObject != null &&
					this.gameObject.activeSelf == this.isHidden)
				{
					this.gameObject.SetActive(!this.isHidden);
				}
			}
		}


		/*
		============================================================================
		Tool functions
		============================================================================
		*/
		public bool IsMode(GridCellMode mode)
		{
			return GridCellMode.All == mode ||
				(GridCellMode.Empty == mode && this.gameObject == null) ||
				(GridCellMode.Assigned == mode && this.gameObject != null);
		}

		public override string ToString()
		{
			return this.x + "," + this.y + "," + this.z +
				(this.gameObject != null ? this.gameObject.name : " empty") +
				(this.isBlocked ? " blocked" : "") +
				(this.isHidden ? " hidden" : "");
		}
	}
}
