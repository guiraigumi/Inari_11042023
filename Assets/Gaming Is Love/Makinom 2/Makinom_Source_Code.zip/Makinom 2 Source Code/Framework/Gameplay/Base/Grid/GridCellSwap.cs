﻿
using UnityEngine;
using System.Collections.Generic;
using System.Collections;

namespace GamingIsLove.Makinom
{
	public class GridCellSwap
	{
		private GameObjectGrid grid;

		private GridCell cell;

		private GameObjectGrid grid2;

		private GridCell cell2;

		private bool setPosition = true;

		private bool setRotation = true;

		private bool mount = true;

		public GridCellSwap()
		{

		}

		public GridCellSwap(GameObjectGrid grid, GridCell cell, GameObjectGrid grid2, GridCell cell2,
			bool setPosition, bool setRotation, bool mount)
		{
			this.grid = grid;
			this.cell = cell;
			this.grid2 = grid2;
			this.cell2 = cell2;
			this.setPosition = setPosition;
			this.setRotation = setRotation;
			this.mount = mount;
		}

		public IEnumerator SwapAfter(float time)
		{
			yield return new WaitForSeconds(time);
			this.Swap();
		}

		public void Swap()
		{
			GameObject tmpObject = this.cell.GameObject;
			this.cell.GameObject = this.cell2.GameObject;
			this.cell2.GameObject = tmpObject;

			if(this.setPosition)
			{
				if(this.cell.GameObject != null)
				{
					this.cell.GameObject.transform.position =
						this.grid.GameObject.transform.TransformPoint(this.cell.Position);
				}
				if(this.cell2.GameObject != null)
				{
					this.cell2.GameObject.transform.position =
						this.grid2.GameObject.transform.TransformPoint(this.cell2.Position);
				}
			}
			if(this.setRotation)
			{
				if(this.cell.GameObject != null)
				{
					this.cell.GameObject.transform.eulerAngles =
						this.grid.GameObject.transform.eulerAngles + this.cell.Rotation;
				}
				if(this.cell2.GameObject != null)
				{
					this.cell2.GameObject.transform.eulerAngles =
						this.grid2.GameObject.transform.eulerAngles + this.cell2.Rotation;
				}
			}
			if(this.mount)
			{
				if(this.cell.GameObject != null)
				{
					this.cell.GameObject.transform.SetParent(this.grid.GameObject.transform);
				}
				if(this.cell2.GameObject != null)
				{
					this.cell2.GameObject.transform.SetParent(this.grid2.GameObject.transform);
				}
			}
		}
	}
}
