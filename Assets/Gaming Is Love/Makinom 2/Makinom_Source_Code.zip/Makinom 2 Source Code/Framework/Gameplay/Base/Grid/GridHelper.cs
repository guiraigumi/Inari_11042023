﻿
using UnityEngine;
using System.Collections.Generic;

namespace GamingIsLove.Makinom
{
	public delegate bool CheckGridIndex(int x, int y, int z);

	public static class GridHelper
	{
		/*
		============================================================================
		First cell tier functions
		============================================================================
		*/
		public static GridCell GetFirstCell(AxisSortType sequence, GameObjectGrid grid,
			CheckGridIndex checkIndex, int[] tierStart, int[] tierEnd)
		{
			if(tierStart[0] <= tierEnd[0])
			{
				for(int tier0 = tierStart[0]; tier0 <= tierEnd[0]; tier0++)
				{
					GridCell cell = GridHelper.Tier1First(sequence, grid, checkIndex, tier0, tierStart, tierEnd);
					if(cell != null)
					{
						return cell;
					}
				}
			}
			else
			{
				for(int tier0 = tierStart[0]; tier0 >= tierEnd[0]; tier0--)
				{
					GridCell cell = GridHelper.Tier1First(sequence, grid, checkIndex, tier0, tierStart, tierEnd);
					if(cell != null)
					{
						return cell;
					}
				}
			}
			return null;
		}

		private static GridCell Tier1First(AxisSortType sequence, GameObjectGrid grid,
			CheckGridIndex checkIndex, int tier0, int[] tierStart, int[] tierEnd)
		{
			if(tierStart[1] <= tierEnd[1])
			{
				for(int tier1 = tierStart[1]; tier1 <= tierEnd[1]; tier1++)
				{
					GridCell cell = GridHelper.Tier2First(sequence, grid, checkIndex, tier0, tier1, tierStart, tierEnd);
					if(cell != null)
					{
						return cell;
					}
				}
			}
			else
			{
				for(int tier1 = tierStart[1]; tier1 >= tierEnd[1]; tier1--)
				{
					GridCell cell = GridHelper.Tier2First(sequence, grid, checkIndex, tier0, tier1, tierStart, tierEnd);
					if(cell != null)
					{
						return cell;
					}
				}
			}
			return null;
		}

		private static GridCell Tier2First(AxisSortType sequence, GameObjectGrid grid,
			CheckGridIndex checkIndex, int tier0, int tier1, int[] tierStart, int[] tierEnd)
		{
			if(tierStart[2] <= tierEnd[2])
			{
				for(int tier2 = tierStart[2]; tier2 <= tierEnd[2]; tier2++)
				{
					GridCell cell = GridHelper.GetFirstCell(sequence, grid, checkIndex, tier0, tier1, tier2);
					if(cell != null)
					{
						return cell;
					}
				}
			}
			else
			{
				for(int tier2 = tierStart[2]; tier2 >= tierEnd[2]; tier2--)
				{
					GridCell cell = GridHelper.GetFirstCell(sequence, grid, checkIndex, tier0, tier1, tier2);
					if(cell != null)
					{
						return cell;
					}
				}
			}
			return null;
		}

		private static GridCell GetFirstCell(AxisSortType sequence, GameObjectGrid grid,
			CheckGridIndex checkIndex, int tier0, int tier1, int tier2)
		{
			int x = -1;
			int y = -1;
			int z = -1;
			GridHelper.GetSequenceIndex(sequence, ref x, ref y, ref z, tier0, tier1, tier2);

			if(checkIndex(x, y, z))
			{
				return grid.Get(x, y, z);
			}
			return null;
		}


		/*
		============================================================================
		First cell object tier functions
		============================================================================
		*/
		public static GameObject GetFirstCellObject(AxisSortType sequence, GameObjectGrid grid,
			CheckGridIndex checkIndex, int[] tierStart, int[] tierEnd)
		{
			if(tierStart[0] <= tierEnd[0])
			{
				for(int tier0 = tierStart[0]; tier0 <= tierEnd[0]; tier0++)
				{
					GameObject obj = GridHelper.Tier1FirstObject(sequence, grid, checkIndex, tier0, tierStart, tierEnd);
					if(obj != null)
					{
						return obj;
					}
				}
			}
			else
			{
				for(int tier0 = tierStart[0]; tier0 >= tierEnd[0]; tier0--)
				{
					GameObject obj = GridHelper.Tier1FirstObject(sequence, grid, checkIndex, tier0, tierStart, tierEnd);
					if(obj != null)
					{
						return obj;
					}
				}
			}
			return null;
		}

		private static GameObject Tier1FirstObject(AxisSortType sequence, GameObjectGrid grid,
			CheckGridIndex checkIndex, int tier0, int[] tierStart, int[] tierEnd)
		{
			if(tierStart[1] <= tierEnd[1])
			{
				for(int tier1 = tierStart[1]; tier1 <= tierEnd[1]; tier1++)
				{
					GameObject obj = GridHelper.Tier2FirstObject(sequence, grid, checkIndex, tier0, tier1, tierStart, tierEnd);
					if(obj != null)
					{
						return obj;
					}
				}
			}
			else
			{
				for(int tier1 = tierStart[1]; tier1 >= tierEnd[1]; tier1--)
				{
					GameObject obj = GridHelper.Tier2FirstObject(sequence, grid, checkIndex, tier0, tier1, tierStart, tierEnd);
					if(obj != null)
					{
						return obj;
					}
				}
			}
			return null;
		}

		private static GameObject Tier2FirstObject(AxisSortType sequence, GameObjectGrid grid,
			CheckGridIndex checkIndex, int tier0, int tier1, int[] tierStart, int[] tierEnd)
		{
			if(tierStart[2] <= tierEnd[2])
			{
				for(int tier2 = tierStart[2]; tier2 <= tierEnd[2]; tier2++)
				{
					GameObject obj = GridHelper.GetFirstCellObject(sequence, grid, checkIndex, tier0, tier1, tier2);
					if(obj != null)
					{
						return obj;
					}
				}
			}
			else
			{
				for(int tier2 = tierStart[2]; tier2 >= tierEnd[2]; tier2--)
				{
					GameObject obj = GridHelper.GetFirstCellObject(sequence, grid, checkIndex, tier0, tier1, tier2);
					if(obj != null)
					{
						return obj;
					}
				}
			}
			return null;
		}

		private static GameObject GetFirstCellObject(AxisSortType sequence, GameObjectGrid grid,
			CheckGridIndex checkIndex, int tier0, int tier1, int tier2)
		{
			int x = -1;
			int y = -1;
			int z = -1;
			GridHelper.GetSequenceIndex(sequence, ref x, ref y, ref z, tier0, tier1, tier2);

			if(checkIndex(x, y, z))
			{
				GridCell cell = grid.Get(x, y, z);
				if(cell != null && cell.GameObject != null)
				{
					return cell.GameObject;
				}
			}
			return null;
		}


		/*
		============================================================================
		Tier functions
		============================================================================
		*/
		public static void GetCells(AxisSortType sequence, GameObjectGrid grid, ref List<GridCell> list,
			CheckGridIndex checkIndex, int[] tierStart, int[] tierEnd)
		{
			if(tierStart[0] <= tierEnd[0])
			{
				for(int tier0 = tierStart[0]; tier0 <= tierEnd[0]; tier0++)
				{
					GridHelper.Tier1(sequence, grid, ref list, checkIndex, tier0, tierStart, tierEnd);
				}
			}
			else
			{
				for(int tier0 = tierStart[0]; tier0 >= tierEnd[0]; tier0--)
				{
					GridHelper.Tier1(sequence, grid, ref list, checkIndex, tier0, tierStart, tierEnd);
				}
			}
		}

		private static void Tier1(AxisSortType sequence, GameObjectGrid grid, ref List<GridCell> list,
			CheckGridIndex checkIndex, int tier0, int[] tierStart, int[] tierEnd)
		{
			if(tierStart[1] <= tierEnd[1])
			{
				for(int tier1 = tierStart[1]; tier1 <= tierEnd[1]; tier1++)
				{
					GridHelper.Tier2(sequence, grid, ref list, checkIndex, tier0, tier1, tierStart, tierEnd);
				}
			}
			else
			{
				for(int tier1 = tierStart[1]; tier1 >= tierEnd[1]; tier1--)
				{
					GridHelper.Tier2(sequence, grid, ref list, checkIndex, tier0, tier1, tierStart, tierEnd);
				}
			}
		}

		private static void Tier2(AxisSortType sequence, GameObjectGrid grid, ref List<GridCell> list,
			CheckGridIndex checkIndex, int tier0, int tier1, int[] tierStart, int[] tierEnd)
		{
			if(tierStart[2] <= tierEnd[2])
			{
				for(int tier2 = tierStart[2]; tier2 <= tierEnd[2]; tier2++)
				{
					GridHelper.AddCell(sequence, grid, ref list, checkIndex, tier0, tier1, tier2);
				}
			}
			else
			{
				for(int tier2 = tierStart[2]; tier2 >= tierEnd[2]; tier2--)
				{
					GridHelper.AddCell(sequence, grid, ref list, checkIndex, tier0, tier1, tier2);
				}
			}
		}

		private static void AddCell(AxisSortType sequence, GameObjectGrid grid, ref List<GridCell> list,
			CheckGridIndex checkIndex, int tier0, int tier1, int tier2)
		{
			int x = -1;
			int y = -1;
			int z = -1;
			GridHelper.GetSequenceIndex(sequence, ref x, ref y, ref z, tier0, tier1, tier2);

			if(checkIndex(x, y, z))
			{
				GridCell cell = grid.Get(x, y, z);
				if(cell != null)
				{
					list.Add(cell);
				}
			}
		}


		/*
		============================================================================
		Tier game object functions
		============================================================================
		*/
		public static void GetCellObjects(AxisSortType sequence, GameObjectGrid grid, ref List<GameObject> list,
			CheckGridIndex checkIndex, int[] tierStart, int[] tierEnd)
		{
			if(tierStart[0] <= tierEnd[0])
			{
				for(int tier0 = tierStart[0]; tier0 <= tierEnd[0]; tier0++)
				{
					GridHelper.Tier1Objects(sequence, grid, ref list, checkIndex, tier0, tierStart, tierEnd);
				}
			}
			else
			{
				for(int tier0 = tierStart[0]; tier0 >= tierEnd[0]; tier0--)
				{
					GridHelper.Tier1Objects(sequence, grid, ref list, checkIndex, tier0, tierStart, tierEnd);
				}
			}
		}

		private static void Tier1Objects(AxisSortType sequence, GameObjectGrid grid, ref List<GameObject> list,
			CheckGridIndex checkIndex, int tier0, int[] tierStart, int[] tierEnd)
		{
			if(tierStart[1] <= tierEnd[1])
			{
				for(int tier1 = tierStart[1]; tier1 <= tierEnd[1]; tier1++)
				{
					GridHelper.Tier2Objects(sequence, grid, ref list, checkIndex, tier0, tier1, tierStart, tierEnd);
				}
			}
			else
			{
				for(int tier1 = tierStart[1]; tier1 >= tierEnd[1]; tier1--)
				{
					GridHelper.Tier2Objects(sequence, grid, ref list, checkIndex, tier0, tier1, tierStart, tierEnd);
				}
			}
		}

		private static void Tier2Objects(AxisSortType sequence, GameObjectGrid grid, ref List<GameObject> list,
			CheckGridIndex checkIndex, int tier0, int tier1, int[] tierStart, int[] tierEnd)
		{
			if(tierStart[2] <= tierEnd[2])
			{
				for(int tier2 = tierStart[2]; tier2 <= tierEnd[2]; tier2++)
				{
					GridHelper.AddCellObject(sequence, grid, ref list, checkIndex, tier0, tier1, tier2);
				}
			}
			else
			{
				for(int tier2 = tierStart[2]; tier2 >= tierEnd[2]; tier2--)
				{
					GridHelper.AddCellObject(sequence, grid, ref list, checkIndex, tier0, tier1, tier2);
				}
			}
		}

		private static void AddCellObject(AxisSortType sequence, GameObjectGrid grid, ref List<GameObject> list,
			CheckGridIndex checkIndex, int tier0, int tier1, int tier2)
		{
			int x = -1;
			int y = -1;
			int z = -1;
			GridHelper.GetSequenceIndex(sequence, ref x, ref y, ref z, tier0, tier1, tier2);

			if(checkIndex(x, y, z))
			{
				GridCell cell = grid.Get(x, y, z);
				if(cell != null && cell.GameObject != null)
				{
					list.Add(cell.GameObject);
				}
			}
		}


		/*
		============================================================================
		Sequence functions
		============================================================================
		*/
		public static void GetSequence(AxisSortType sequence,
			ref int[] tierStart, ref int[] tierEnd,
			int xStart, int xEnd, int yStart, int yEnd, int zStart, int zEnd)
		{
			if(AxisSortType.XYZ == sequence)
			{
				tierStart[2] = xStart;
				tierEnd[2] = xEnd;
				tierStart[1] = yStart;
				tierEnd[1] = yEnd;
				tierStart[0] = zStart;
				tierEnd[0] = zEnd;
			}
			else if(AxisSortType.XZY == sequence)
			{
				tierStart[2] = xStart;
				tierEnd[2] = xEnd;
				tierStart[0] = yStart;
				tierEnd[0] = yEnd;
				tierStart[1] = zStart;
				tierEnd[1] = zEnd;
			}
			else if(AxisSortType.YXZ == sequence)
			{
				tierStart[1] = xStart;
				tierEnd[1] = xEnd;
				tierStart[2] = yStart;
				tierEnd[2] = yEnd;
				tierStart[0] = zStart;
				tierEnd[0] = zEnd;
			}
			else if(AxisSortType.YZX == sequence)
			{
				tierStart[0] = xStart;
				tierEnd[0] = xEnd;
				tierStart[2] = yStart;
				tierEnd[2] = yEnd;
				tierStart[1] = zStart;
				tierEnd[1] = zEnd;
			}
			else if(AxisSortType.ZXY == sequence)
			{
				tierStart[1] = xStart;
				tierEnd[1] = xEnd;
				tierStart[0] = yStart;
				tierEnd[0] = yEnd;
				tierStart[2] = zStart;
				tierEnd[2] = zEnd;
			}
			else if(AxisSortType.ZYX == sequence)
			{
				tierStart[0] = xStart;
				tierEnd[0] = xEnd;
				tierStart[1] = yStart;
				tierEnd[1] = yEnd;
				tierStart[2] = zStart;
				tierEnd[2] = zEnd;
			}
		}

		public static void GetSequenceIndex(AxisSortType sequence,
			ref int x, ref int y, ref int z,
			int tier0, int tier1, int tier2)
		{
			if(AxisSortType.XYZ == sequence)
			{
				x = tier2;
				y = tier1;
				z = tier0;
			}
			else if(AxisSortType.XZY == sequence)
			{
				x = tier2;
				y = tier0;
				z = tier1;
			}
			else if(AxisSortType.YXZ == sequence)
			{
				x = tier1;
				y = tier2;
				z = tier0;
			}
			else if(AxisSortType.YZX == sequence)
			{
				x = tier0;
				y = tier2;
				z = tier1;
			}
			else if(AxisSortType.ZXY == sequence)
			{
				x = tier1;
				y = tier0;
				z = tier2;
			}
			else if(AxisSortType.ZYX == sequence)
			{
				x = tier0;
				y = tier1;
				z = tier2;
			}
		}
	}
}
