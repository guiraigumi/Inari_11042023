﻿
using UnityEngine;
using System.Collections.Generic;

namespace GamingIsLove.Makinom
{
	public interface ICustomTextCodes
	{
		void ReplaceCustomTextCodes(ref string text);
	}
}
