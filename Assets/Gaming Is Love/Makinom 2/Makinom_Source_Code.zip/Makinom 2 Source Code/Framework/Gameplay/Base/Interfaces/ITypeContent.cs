﻿
using UnityEngine;
using System.Collections.Generic;

namespace GamingIsLove.Makinom
{
	public interface ITypeContent
	{
		IContent GetTypeContent();
	}

	public interface ITypeData<T> where T : BaseIndexData
	{
		bool HasType
		{
			get;
		}

		T TypeData
		{
			get;
		}
	}

	public interface ITypeAsset<T> where T : IMakinomGenericAsset
	{
		T TypeAsset
		{
			get;
		}
	}

	public static class TypeContentHelper
	{
		public static IContent Get(object content)
		{
			if(content is ITypeContent)
			{
				return ((ITypeContent)content).GetTypeContent();
			}
			return null;
		}
	}
}
