﻿
using UnityEngine;
using GamingIsLove.Makinom.Schematics;
using System.Collections.Generic;

namespace GamingIsLove.Makinom.UI
{
	public class ContentButton : BaseData
	{
		[EditorHelp("Add Tooltip", "Hovering the cursor over this button will show a tooltip.\n" +
			"The tooltip will use the content and description defined here.")]
		public bool addTooltip = false;


		// content
		public Content content = new Content();


		// description
		[EditorHelp("Add Description", "Add a description to the button.", "")]
		[EditorFoldout("Description", "Optionally add a description to the button.", "")]
		public bool addDescription = false;

		[EditorHelp("Description Content", "The description content of this button.", "")]
		[EditorEndFoldout]
		[EditorCondition("addDescription", true)]
		[EditorEndCondition]
		[EditorAutoInit]
		[EditorLanguageExport("Description")]
		public LanguageData<TextImageContent> description;

		public ContentButton()
		{

		}

		public ContentButton(string name)
		{
			this.content.mainContent.data.text.text = name;
		}

		public virtual UIButtonInputContent GetContent()
		{
			UIButtonInputContent content = this.content.GetContent<UIButtonInputContent>();
			if(this.addDescription)
			{
				content.Description = this.description.Current;
			}
			if(this.addTooltip)
			{
				content.Tooltip = new TooltipContent(content.mainContent.text, "",
					content.Description != null ? content.Description.text : "",
					content.mainContent.sprite, content.mainContent.texture);
			}
			return content;
		}

		public virtual UIButtonInputContent GetContent(Schematic schematic, int actorID, VariableHandler handler)
		{
			UIButtonInputContent content = this.content.GetContent<UIButtonInputContent>(schematic, actorID, handler);
			if(this.addDescription)
			{
				content.Description = this.description.Current;
			}
			if(this.addTooltip)
			{
				content.Tooltip = new TooltipContent(content.mainContent.text, "",
					content.Description != null ? content.Description.text : "",
					content.mainContent.sprite, content.mainContent.texture);
			}
			return content;
		}
	}
}
