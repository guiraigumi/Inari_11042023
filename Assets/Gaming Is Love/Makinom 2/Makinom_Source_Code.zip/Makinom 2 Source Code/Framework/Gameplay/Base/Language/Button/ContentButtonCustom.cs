﻿
using UnityEngine;
using GamingIsLove.Makinom.Schematics;
using System.Collections.Generic;

namespace GamingIsLove.Makinom.UI
{
	public class ContentButtonCustom : ContentButton
	{
		public UICustomInputSettings customInput = new UICustomInputSettings();

		public ContentButtonCustom()
		{

		}

		public ContentButtonCustom(string name) : base(name)
		{

		}

		public override UIButtonInputContent GetContent()
		{
			UIButtonInputContent content = base.GetContent();
			this.customInput.Use(content);
			return content;
		}

		public override UIButtonInputContent GetContent(Schematic schematic, int actorID, VariableHandler handler)
		{
			UIButtonInputContent content = base.GetContent(schematic, actorID, handler);
			this.customInput.Use(content);
			return content;
		}
	}
}
