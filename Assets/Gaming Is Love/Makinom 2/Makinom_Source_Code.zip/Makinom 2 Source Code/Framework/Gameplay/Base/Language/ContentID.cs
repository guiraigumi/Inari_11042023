﻿
using UnityEngine;
using System.Collections.Generic;

namespace GamingIsLove.Makinom
{
	public class ContentID<T> : BaseData where T : IBaseData, new()
	{
		[EditorHelp("Content ID", "Define the content ID that identifies this content.\n" +
			"UI boxes will display this content in content components with matching IDs.", "")]
		[EditorWidth(true)]
		public string contentID = "";

		[EditorLanguageExport("ContentID.AdditionalContent")]
		public T content = new T();

		public ContentID()
		{

		}

		public ContentID(string contentID, T content)
		{
			this.contentID = contentID;
			this.content = content;
		}
	}
}
