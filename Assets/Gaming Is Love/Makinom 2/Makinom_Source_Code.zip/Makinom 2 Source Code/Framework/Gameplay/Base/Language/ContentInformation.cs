﻿
using UnityEngine;
using System.Collections.Generic;

namespace GamingIsLove.Makinom
{
	public class ContentInformation : BaseData
	{
		[EditorHelp("Name", "Define the name.")]
		[EditorLanguageExport("Name")]
		[EditorCallback("textcodes:name", EditorCallbackType.Before)]
		public TextContent name = new TextContent();

		[EditorSeparator]
		[EditorHelp("Short Name", "Define the short name.\n" +
			"The name is used if no short name is defined.")]
		[EditorLanguageExport("ShortName")]
		[EditorCallback("textcodes:shortname", EditorCallbackType.Before)]
		public TextContent shortName = new TextContent();

		[EditorSeparator]
		[EditorHelp("Description", "Define the description.")]
		[EditorLanguageExport("Description")]
		[EditorCallback("textcodes:description", EditorCallbackType.Before)]
		public TextContent description = new TextContent();

		[EditorFoldout("Icon", "Define the icon (sprite and/or texture) and text code used to display the icon in texts.")]
		[EditorEndFoldout]
		public IconContent icon = new IconContent();

		public ContentInformation()
		{

		}

		public ContentInformation(string name)
		{
			this.name.text = name;
		}

		public string ShortName
		{
			get { return this.shortName.text == "" ? this.name : this.shortName; }
		}
	}
}
