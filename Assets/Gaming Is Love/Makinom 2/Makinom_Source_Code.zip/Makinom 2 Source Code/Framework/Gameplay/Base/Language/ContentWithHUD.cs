﻿
using UnityEngine;
using GamingIsLove.Makinom.Schematics;
using System.Collections.Generic;

namespace GamingIsLove.Makinom.UI
{
	public class ContentWithHUD : BaseData
	{
		[EditorLanguageExport("MainContent")]
		public TextImageContentWithHUD mainContent = new TextImageContentWithHUD();

		[EditorArray("Add Additional Content", "Adds an additional content, identified by a content ID.\n" +
			"Additional content is displayed by UI boxes in content components with matching IDs.", "",
			"Remove", "Removes this additional content.", "", isCopy=true, isMove=true,
			foldout=true, foldoutText=new string[] {
				"Additional Content", "Additional content is displayed by UI boxes in content components with matching IDs.", ""
			})]
		public ContentID<TextImageContentWithHUD>[] additionalContent = new ContentID<TextImageContentWithHUD>[0];

		public ContentWithHUD()
		{

		}

		public ContentWithHUD(string text)
		{
			this.mainContent.content.data = new TextImageContent(text);
		}

		public ContentWithHUD(string contentID, string contentText)
		{
			this.additionalContent = new ContentID<TextImageContentWithHUD>[]
			{
				new ContentID<TextImageContentWithHUD>(contentID,
					new TextImageContentWithHUD(contentText))
			};
		}

		public ContentWithHUD(string[] contentID, string[] contentText)
		{
			this.additionalContent = new ContentID<TextImageContentWithHUD>[contentID.Length];
			for(int i = 0; i < this.additionalContent.Length; i++)
			{
				this.additionalContent[i] = new ContentID<TextImageContentWithHUD>(contentID[i],
					new TextImageContentWithHUD(i < contentText.Length ? contentText[i] : ""));
			}
		}

		public override string ToString()
		{
			return this.mainContent.content.Current.text.text;
		}

		public UIContent GetContent(object hudUser)
		{
			return this.GetContent<UIContent>(hudUser);
		}

		public UIContent GetContent(object hudUser, Schematic schematic, int actorID, VariableHandler handler)
		{
			return this.GetContent<UIContent>(hudUser, schematic, actorID, handler);
		}

		public T GetContent<T>(object hudUser) where T : UIContent, new()
		{
			T content = new T();
			content.mainContent = this.mainContent.GetContent(hudUser);
			for(int i = 0; i < this.additionalContent.Length; i++)
			{
				content.AddAdditionalContent(
					this.additionalContent[i].contentID,
					this.additionalContent[i].content.GetContent(hudUser));
			}
			return content;
		}

		public T GetContent<T>(object hudUser, Schematic schematic, int actorID, VariableHandler handler) where T : UIContent, new()
		{
			T content = new T();
			content.mainContent = this.mainContent.GetContent(hudUser, schematic, actorID, handler);
			for(int i = 0; i < this.additionalContent.Length; i++)
			{
				content.AddAdditionalContent(
					this.additionalContent[i].contentID,
					new UIText(this.additionalContent[i].content.GetContent(
						hudUser, schematic, actorID, handler)));
			}
			return content;
		}
	}
}
