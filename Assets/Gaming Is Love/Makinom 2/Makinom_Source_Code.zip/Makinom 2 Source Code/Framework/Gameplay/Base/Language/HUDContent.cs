﻿
using UnityEngine;
using System.Collections.Generic;

namespace GamingIsLove.Makinom.UI
{
	public class HUDContent : BaseData
	{
		[EditorHelp("Add HUD Content", "Add HUDs to the displayed content.")]
		public bool addHUD = false;

		[EditorHelp("Main Content HUD", "HUD added to the main content.\n" +
			"Select no HUD to only use the displaying UI's HUD.")]
		[EditorCondition("addHUD", true)]
		[EditorAutoInit]
		public AssetSelection<HUDAsset> mainContent;

		[EditorArray("Add Additional Content", "Adds an additional content, identified by a content ID.\n" +
			"Additional content is displayed by UI boxes in content components with matching IDs.", "",
			"Remove", "Removes this additional content.", "", isCopy=true, isMove=true,
			foldout=true, foldoutText=new string[] {
				"Additional Content", "Additional content is displayed by UI boxes in content components with matching IDs.", ""
			})]
		[EditorEndCondition]
		[EditorAutoInit]
		public ContentID<AdditionalHUDContent>[] additionalContent;

		public HUDContent()
		{

		}

		public void UpdateContent(UIContent content, object user)
		{
			if(this.addHUD)
			{
				content.mainContent.hud = new UIHUD(this.mainContent.StoredAsset, user);
				for(int i = 0; i < this.additionalContent.Length; i++)
				{
					content.GetAdditionalContent(this.additionalContent[i].contentID).hud =
						new UIHUD(this.additionalContent[i].content.hud.StoredAsset, user);
				}
			}
		}
	}
}
