﻿
using UnityEngine;
using System.Collections.Generic;

namespace GamingIsLove.Makinom
{
	public class IconContent : BaseData
	{
		public ImageContent image = new ImageContent();

		[EditorHelp("Icon Text Code", "Define the text code that will be used to display the icon in text.\n" +
			"E.g. in TextMesh Pro use the sprite tag, like '<sprite index=1>'.")]
		[EditorWidth(true)]
		[EditorCallback("button:findicontextcode", EditorCallbackType.InstanceBefore)]
		public string textCode = "";

		public IconContent()
		{

		}
	}
}
